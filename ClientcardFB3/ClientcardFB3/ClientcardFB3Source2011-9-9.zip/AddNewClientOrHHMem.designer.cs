﻿namespace ClientcardFB3
{
    partial class AddNewClientOrHHMem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFName = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbBirthDate = new System.Windows.Forms.TextBox();
            this.lblBDay = new System.Windows.Forms.Label();
            this.lblSex = new System.Windows.Forms.Label();
            this.tbSex = new System.Windows.Forms.TextBox();
            this.btnAddNewMem = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lvwPeople = new System.Windows.Forms.ListView();
            this.colLastName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colFirstName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colBirthDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAge = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHholdId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHHMInactive = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeadHH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.tbAge = new System.Windows.Forms.TextBox();
            this.chkEnterAge = new System.Windows.Forms.CheckBox();
            this.cboSpecialLang = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbeState = new System.Windows.Forms.TextBox();
            this.chkInCityLimits = new System.Windows.Forms.CheckBox();
            this.chkHomeless = new System.Windows.Forms.CheckBox();
            this.tbeZipCode = new System.Windows.Forms.TextBox();
            this.cboClientType = new System.Windows.Forms.ComboBox();
            this.tbeCity = new System.Windows.Forms.TextBox();
            this.tbeAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lvwHHMByBirthdate = new System.Windows.Forms.ListView();
            this.clmLastName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmFirstName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmHHMInactive = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmHHName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmCity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmZip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmHHId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmHHInactive = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlHH = new System.Windows.Forms.Panel();
            this.cboPhoneType = new System.Windows.Forms.ComboBox();
            this.tbPhone = new System.Windows.Forms.TextBox();
            this.lblPhoneType = new System.Windows.Forms.Label();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.cboIDType = new System.Windows.Forms.ComboBox();
            this.lblVerifyMethod = new System.Windows.Forms.Label();
            this.tbBabySvcDescr = new System.Windows.Forms.TextBox();
            this.chkBabyServices = new System.Windows.Forms.CheckBox();
            this.chkSingleHeadHH = new System.Windows.Forms.CheckBox();
            this.tbeApt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.spltcontMain = new System.Windows.Forms.SplitContainer();
            this.lblDupHHMError = new System.Windows.Forms.Label();
            this.lblDupHHError = new System.Windows.Forms.Label();
            this.lblDateError = new System.Windows.Forms.Label();
            this.spltcontLists = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpgSameBirthDate = new System.Windows.Forms.TabPage();
            this.tpgSameHouseNbr = new System.Windows.Forms.TabPage();
            this.lvwSameHouseNbr = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAptNbr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlHH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spltcontMain)).BeginInit();
            this.spltcontMain.Panel1.SuspendLayout();
            this.spltcontMain.Panel2.SuspendLayout();
            this.spltcontMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spltcontLists)).BeginInit();
            this.spltcontLists.Panel1.SuspendLayout();
            this.spltcontLists.Panel2.SuspendLayout();
            this.spltcontLists.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpgSameBirthDate.SuspendLayout();
            this.tpgSameHouseNbr.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(10, 48);
            this.lblFName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 16);
            this.lblFName.TabIndex = 2;
            this.lblFName.Text = "First Name:";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(10, 14);
            this.lblLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 16);
            this.lblLName.TabIndex = 0;
            this.lblLName.Text = "Last Name:";
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(88, 45);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(240, 22);
            this.tbFirstName.TabIndex = 3;
            this.tbFirstName.Tag = "FirstName";
            this.tbFirstName.Leave += new System.EventHandler(this.tbFirstName_Leave);
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(87, 13);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(240, 22);
            this.tbLastName.TabIndex = 1;
            this.tbLastName.Tag = "LastName";
            this.tbLastName.Text = "123456789012345678901234567890";
            this.tbLastName.Leave += new System.EventHandler(this.tbLastName_Leave);
            // 
            // tbBirthDate
            // 
            this.tbBirthDate.Location = new System.Drawing.Point(88, 103);
            this.tbBirthDate.Name = "tbBirthDate";
            this.tbBirthDate.Size = new System.Drawing.Size(126, 22);
            this.tbBirthDate.TabIndex = 6;
            this.tbBirthDate.Tag = "Birthdate";
            this.tbBirthDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbBirthDate.Leave += new System.EventHandler(this.tbBirthDate_Leave);
            // 
            // lblBDay
            // 
            this.lblBDay.AutoSize = true;
            this.lblBDay.Location = new System.Drawing.Point(17, 106);
            this.lblBDay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBDay.Name = "lblBDay";
            this.lblBDay.Size = new System.Drawing.Size(69, 16);
            this.lblBDay.TabIndex = 5;
            this.lblBDay.Tag = "Birthdate";
            this.lblBDay.Text = "Birth Date:";
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Location = new System.Drawing.Point(346, 106);
            this.lblSex.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(34, 16);
            this.lblSex.TabIndex = 9;
            this.lblSex.Tag = "Sex";
            this.lblSex.Text = "Sex:";
            // 
            // tbSex
            // 
            this.tbSex.Location = new System.Drawing.Point(387, 104);
            this.tbSex.MaxLength = 1;
            this.tbSex.Name = "tbSex";
            this.tbSex.Size = new System.Drawing.Size(27, 22);
            this.tbSex.TabIndex = 10;
            this.tbSex.Tag = "Sex";
            this.tbSex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbSex.Leave += new System.EventHandler(this.tbSex_Leave);
            // 
            // btnAddNewMem
            // 
            this.btnAddNewMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewMem.Location = new System.Drawing.Point(268, 155);
            this.btnAddNewMem.Name = "btnAddNewMem";
            this.btnAddNewMem.Size = new System.Drawing.Size(168, 28);
            this.btnAddNewMem.TabIndex = 26;
            this.btnAddNewMem.Text = "&Add New Household Member";
            this.btnAddNewMem.UseVisualStyleBackColor = true;
            this.btnAddNewMem.Click += new System.EventHandler(this.btnAddNewMem_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(951, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(50, 27);
            this.btnCancel.TabIndex = 27;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.tbCancel_Click);
            // 
            // lvwPeople
            // 
            this.lvwPeople.BackColor = System.Drawing.Color.Cornsilk;
            this.lvwPeople.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvwPeople.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colLastName,
            this.colFirstName,
            this.colBirthDate,
            this.colAge,
            this.colHholdId,
            this.colHHMInactive,
            this.colHeadHH});
            this.lvwPeople.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwPeople.FullRowSelect = true;
            this.lvwPeople.GridLines = true;
            this.lvwPeople.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwPeople.Location = new System.Drawing.Point(0, 0);
            this.lvwPeople.Name = "lvwPeople";
            this.lvwPeople.Size = new System.Drawing.Size(1008, 168);
            this.lvwPeople.TabIndex = 15;
            this.lvwPeople.TabStop = false;
            this.lvwPeople.UseCompatibleStateImageBehavior = false;
            this.lvwPeople.View = System.Windows.Forms.View.Details;
            // 
            // colLastName
            // 
            this.colLastName.Text = "Last Name";
            this.colLastName.Width = 240;
            // 
            // colFirstName
            // 
            this.colFirstName.Text = "First Name";
            this.colFirstName.Width = 150;
            // 
            // colBirthDate
            // 
            this.colBirthDate.Text = "Birth Date";
            this.colBirthDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colBirthDate.Width = 100;
            // 
            // colAge
            // 
            this.colAge.Text = "Age";
            this.colAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colAge.Width = 45;
            // 
            // colHholdId
            // 
            this.colHholdId.Text = "HHID";
            this.colHholdId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colHholdId.Width = 80;
            // 
            // colHHMInactive
            // 
            this.colHHMInactive.Text = "Inactive";
            this.colHHMInactive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colHHMInactive.Width = 70;
            // 
            // colHeadHH
            // 
            this.colHeadHH.Text = "";
            this.colHeadHH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colHeadHH.Width = 70;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(243, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Age:";
            // 
            // tbAge
            // 
            this.tbAge.Enabled = false;
            this.tbAge.Location = new System.Drawing.Point(286, 103);
            this.tbAge.Name = "tbAge";
            this.tbAge.Size = new System.Drawing.Size(42, 22);
            this.tbAge.TabIndex = 8;
            this.tbAge.Tag = "Age";
            this.tbAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbAge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbAge_KeyDown);
            this.tbAge.Leave += new System.EventHandler(this.tbAge_Leave);
            // 
            // chkEnterAge
            // 
            this.chkEnterAge.AutoSize = true;
            this.chkEnterAge.Location = new System.Drawing.Point(88, 77);
            this.chkEnterAge.Name = "chkEnterAge";
            this.chkEnterAge.Size = new System.Drawing.Size(166, 20);
            this.chkEnterAge.TabIndex = 4;
            this.chkEnterAge.Tag = "UseAge";
            this.chkEnterAge.Text = "Enter Age Not Birthdate";
            this.chkEnterAge.UseVisualStyleBackColor = true;
            this.chkEnterAge.CheckedChanged += new System.EventHandler(this.chkEnterAge_CheckedChanged);
            // 
            // cboSpecialLang
            // 
            this.cboSpecialLang.BackColor = System.Drawing.Color.White;
            this.cboSpecialLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSpecialLang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSpecialLang.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSpecialLang.FormattingEnabled = true;
            this.cboSpecialLang.Location = new System.Drawing.Point(71, 94);
            this.cboSpecialLang.Margin = new System.Windows.Forms.Padding(4);
            this.cboSpecialLang.Name = "cboSpecialLang";
            this.cboSpecialLang.Size = new System.Drawing.Size(122, 22);
            this.cboSpecialLang.TabIndex = 17;
            this.cboSpecialLang.Tag = "EthnicSpeaking";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1, 97);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 13);
            this.label11.TabIndex = 124;
            this.label11.Text = "Language:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbeState
            // 
            this.tbeState.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeState.Location = new System.Drawing.Point(315, 38);
            this.tbeState.Margin = new System.Windows.Forms.Padding(4);
            this.tbeState.Name = "tbeState";
            this.tbeState.Size = new System.Drawing.Size(40, 21);
            this.tbeState.TabIndex = 14;
            this.tbeState.Tag = "State";
            this.tbeState.Text = "WW";
            this.tbeState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chkInCityLimits
            // 
            this.chkInCityLimits.AutoSize = true;
            this.chkInCityLimits.Location = new System.Drawing.Point(315, 71);
            this.chkInCityLimits.Margin = new System.Windows.Forms.Padding(4);
            this.chkInCityLimits.Name = "chkInCityLimits";
            this.chkInCityLimits.Size = new System.Drawing.Size(99, 20);
            this.chkInCityLimits.TabIndex = 19;
            this.chkInCityLimits.Tag = "InCityLimits";
            this.chkInCityLimits.Text = "In City Limits";
            this.chkInCityLimits.UseVisualStyleBackColor = true;
            // 
            // chkHomeless
            // 
            this.chkHomeless.AutoSize = true;
            this.chkHomeless.Location = new System.Drawing.Point(315, 92);
            this.chkHomeless.Margin = new System.Windows.Forms.Padding(4);
            this.chkHomeless.Name = "chkHomeless";
            this.chkHomeless.Size = new System.Drawing.Size(89, 20);
            this.chkHomeless.TabIndex = 20;
            this.chkHomeless.Tag = "Homeless";
            this.chkHomeless.Text = "Homeless";
            this.chkHomeless.UseVisualStyleBackColor = true;
            // 
            // tbeZipCode
            // 
            this.tbeZipCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeZipCode.Location = new System.Drawing.Point(401, 36);
            this.tbeZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.tbeZipCode.Name = "tbeZipCode";
            this.tbeZipCode.Size = new System.Drawing.Size(75, 20);
            this.tbeZipCode.TabIndex = 15;
            this.tbeZipCode.Tag = "Zipcode";
            this.tbeZipCode.Text = "98072";
            this.tbeZipCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbeZipCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbeZipCode_KeyDown);
            // 
            // cboClientType
            // 
            this.cboClientType.BackColor = System.Drawing.Color.White;
            this.cboClientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientType.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboClientType.FormattingEnabled = true;
            this.cboClientType.ItemHeight = 13;
            this.cboClientType.Location = new System.Drawing.Point(71, 69);
            this.cboClientType.Margin = new System.Windows.Forms.Padding(4);
            this.cboClientType.Name = "cboClientType";
            this.cboClientType.Size = new System.Drawing.Size(215, 21);
            this.cboClientType.TabIndex = 16;
            this.cboClientType.Tag = "ClientType";
            // 
            // tbeCity
            // 
            this.tbeCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeCity.Location = new System.Drawing.Point(71, 40);
            this.tbeCity.Margin = new System.Windows.Forms.Padding(4);
            this.tbeCity.Name = "tbeCity";
            this.tbeCity.Size = new System.Drawing.Size(215, 20);
            this.tbeCity.TabIndex = 13;
            this.tbeCity.Tag = "City";
            this.tbeCity.Text = "123456789012345678901234567890";
            this.tbeCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbeCity_KeyDown);
            // 
            // tbeAddress
            // 
            this.tbeAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeAddress.Location = new System.Drawing.Point(71, 11);
            this.tbeAddress.Margin = new System.Windows.Forms.Padding(4);
            this.tbeAddress.Name = "tbeAddress";
            this.tbeAddress.Size = new System.Drawing.Size(329, 20);
            this.tbeAddress.TabIndex = 11;
            this.tbeAddress.Tag = "Address";
            this.tbeAddress.Text = "12345678901234567890123456789012345678901234567890";
            this.tbeAddress.Leave += new System.EventHandler(this.tbeAddress_Leave);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 69);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 21);
            this.label8.TabIndex = 123;
            this.label8.Text = "Category:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(363, 43);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 120;
            this.label6.Text = "Zip:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(287, 43);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 119;
            this.label5.Text = "St:";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 42);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 18);
            this.label4.TabIndex = 118;
            this.label4.Text = "City:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 18);
            this.label3.TabIndex = 117;
            this.label3.Text = "Address:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lvwHHMByBirthdate
            // 
            this.lvwHHMByBirthdate.BackColor = System.Drawing.Color.Gainsboro;
            this.lvwHHMByBirthdate.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmLastName,
            this.clmFirstName,
            this.clmHHMInactive,
            this.clmHHName,
            this.clmAddress,
            this.clmCity,
            this.clmZip,
            this.clmHHId,
            this.clmHHInactive});
            this.lvwHHMByBirthdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwHHMByBirthdate.FullRowSelect = true;
            this.lvwHHMByBirthdate.GridLines = true;
            this.lvwHHMByBirthdate.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwHHMByBirthdate.Location = new System.Drawing.Point(3, 3);
            this.lvwHHMByBirthdate.Name = "lvwHHMByBirthdate";
            this.lvwHHMByBirthdate.Size = new System.Drawing.Size(994, 230);
            this.lvwHHMByBirthdate.TabIndex = 16;
            this.lvwHHMByBirthdate.TabStop = false;
            this.lvwHHMByBirthdate.UseCompatibleStateImageBehavior = false;
            this.lvwHHMByBirthdate.View = System.Windows.Forms.View.Details;
            // 
            // clmLastName
            // 
            this.clmLastName.Text = "Last Name";
            this.clmLastName.Width = 150;
            // 
            // clmFirstName
            // 
            this.clmFirstName.Text = "First Name";
            this.clmFirstName.Width = 120;
            // 
            // clmHHMInactive
            // 
            this.clmHHMInactive.Text = "HHM Ina";
            this.clmHHMInactive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmHHMInactive.Width = 70;
            // 
            // clmHHName
            // 
            this.clmHHName.Text = "HH Name";
            this.clmHHName.Width = 150;
            // 
            // clmAddress
            // 
            this.clmAddress.Text = "Address";
            this.clmAddress.Width = 180;
            // 
            // clmCity
            // 
            this.clmCity.Text = "City";
            this.clmCity.Width = 90;
            // 
            // clmZip
            // 
            this.clmZip.Text = "Zip";
            this.clmZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // clmHHId
            // 
            this.clmHHId.Text = "HHID";
            this.clmHHId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmHHId.Width = 80;
            // 
            // clmHHInactive
            // 
            this.clmHHInactive.Text = "HH Ina";
            this.clmHHInactive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlHH
            // 
            this.pnlHH.BackColor = System.Drawing.Color.PaleGreen;
            this.pnlHH.Controls.Add(this.cboPhoneType);
            this.pnlHH.Controls.Add(this.tbPhone);
            this.pnlHH.Controls.Add(this.lblPhoneType);
            this.pnlHH.Controls.Add(this.lblPhoneNum);
            this.pnlHH.Controls.Add(this.cboIDType);
            this.pnlHH.Controls.Add(this.lblVerifyMethod);
            this.pnlHH.Controls.Add(this.tbBabySvcDescr);
            this.pnlHH.Controls.Add(this.chkBabyServices);
            this.pnlHH.Controls.Add(this.chkSingleHeadHH);
            this.pnlHH.Controls.Add(this.tbeApt);
            this.pnlHH.Controls.Add(this.label7);
            this.pnlHH.Controls.Add(this.tbeAddress);
            this.pnlHH.Controls.Add(this.label3);
            this.pnlHH.Controls.Add(this.cboSpecialLang);
            this.pnlHH.Controls.Add(this.label4);
            this.pnlHH.Controls.Add(this.label11);
            this.pnlHH.Controls.Add(this.label5);
            this.pnlHH.Controls.Add(this.tbeState);
            this.pnlHH.Controls.Add(this.label6);
            this.pnlHH.Controls.Add(this.label8);
            this.pnlHH.Controls.Add(this.chkInCityLimits);
            this.pnlHH.Controls.Add(this.tbeCity);
            this.pnlHH.Controls.Add(this.cboClientType);
            this.pnlHH.Controls.Add(this.chkHomeless);
            this.pnlHH.Controls.Add(this.tbeZipCode);
            this.pnlHH.Location = new System.Drawing.Point(448, 4);
            this.pnlHH.Name = "pnlHH";
            this.pnlHH.Size = new System.Drawing.Size(486, 241);
            this.pnlHH.TabIndex = 11;
            this.pnlHH.Visible = false;
            // 
            // cboPhoneType
            // 
            this.cboPhoneType.BackColor = System.Drawing.Color.White;
            this.cboPhoneType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhoneType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPhoneType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPhoneType.FormattingEnabled = true;
            this.cboPhoneType.Location = new System.Drawing.Point(120, 208);
            this.cboPhoneType.Margin = new System.Windows.Forms.Padding(4);
            this.cboPhoneType.Name = "cboPhoneType";
            this.cboPhoneType.Size = new System.Drawing.Size(166, 22);
            this.cboPhoneType.TabIndex = 25;
            this.cboPhoneType.Tag = "PhoneType";
            // 
            // tbPhone
            // 
            this.tbPhone.AccessibleName = "Phone";
            this.tbPhone.BackColor = System.Drawing.Color.White;
            this.tbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPhone.Location = new System.Drawing.Point(120, 185);
            this.tbPhone.Margin = new System.Windows.Forms.Padding(4);
            this.tbPhone.MaxLength = 30;
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(166, 20);
            this.tbPhone.TabIndex = 24;
            this.tbPhone.Tag = "Phone";
            this.tbPhone.Text = "425-485-2079";
            // 
            // lblPhoneType
            // 
            this.lblPhoneType.AutoSize = true;
            this.lblPhoneType.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneType.Location = new System.Drawing.Point(11, 213);
            this.lblPhoneType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneType.Name = "lblPhoneType";
            this.lblPhoneType.Size = new System.Drawing.Size(86, 14);
            this.lblPhoneType.TabIndex = 139;
            this.lblPhoneType.Text = "Phone Type:";
            this.lblPhoneType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneNum.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNum.Location = new System.Drawing.Point(11, 189);
            this.lblPhoneNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(84, 14);
            this.lblPhoneNum.TabIndex = 136;
            this.lblPhoneNum.Text = "Phone Num:";
            this.lblPhoneNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboIDType
            // 
            this.cboIDType.BackColor = System.Drawing.Color.White;
            this.cboIDType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIDType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboIDType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboIDType.FormattingEnabled = true;
            this.cboIDType.Location = new System.Drawing.Point(120, 155);
            this.cboIDType.Margin = new System.Windows.Forms.Padding(4);
            this.cboIDType.Name = "cboIDType";
            this.cboIDType.Size = new System.Drawing.Size(166, 22);
            this.cboIDType.TabIndex = 23;
            this.cboIDType.Tag = "IdType";
            this.cboIDType.SelectedValueChanged += new System.EventHandler(this.cboIDType_SelectedValueChanged);
            // 
            // lblVerifyMethod
            // 
            this.lblVerifyMethod.AutoSize = true;
            this.lblVerifyMethod.BackColor = System.Drawing.Color.Transparent;
            this.lblVerifyMethod.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVerifyMethod.Location = new System.Drawing.Point(9, 160);
            this.lblVerifyMethod.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVerifyMethod.Name = "lblVerifyMethod";
            this.lblVerifyMethod.Size = new System.Drawing.Size(91, 13);
            this.lblVerifyMethod.TabIndex = 135;
            this.lblVerifyMethod.Text = "Verify Method:";
            // 
            // tbBabySvcDescr
            // 
            this.tbBabySvcDescr.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBabySvcDescr.Location = new System.Drawing.Point(315, 136);
            this.tbBabySvcDescr.Name = "tbBabySvcDescr";
            this.tbBabySvcDescr.Size = new System.Drawing.Size(161, 20);
            this.tbBabySvcDescr.TabIndex = 22;
            this.tbBabySvcDescr.Tag = "BabySvcDescr";
            // 
            // chkBabyServices
            // 
            this.chkBabyServices.AutoSize = true;
            this.chkBabyServices.Location = new System.Drawing.Point(315, 116);
            this.chkBabyServices.Margin = new System.Windows.Forms.Padding(4);
            this.chkBabyServices.Name = "chkBabyServices";
            this.chkBabyServices.Size = new System.Drawing.Size(115, 20);
            this.chkBabyServices.TabIndex = 21;
            this.chkBabyServices.Tag = "BabyServices";
            this.chkBabyServices.Text = "Baby Services";
            this.chkBabyServices.UseVisualStyleBackColor = true;
            // 
            // chkSingleHeadHH
            // 
            this.chkSingleHeadHH.AutoSize = true;
            this.chkSingleHeadHH.Location = new System.Drawing.Point(71, 127);
            this.chkSingleHeadHH.Margin = new System.Windows.Forms.Padding(4);
            this.chkSingleHeadHH.Name = "chkSingleHeadHH";
            this.chkSingleHeadHH.Size = new System.Drawing.Size(176, 20);
            this.chkSingleHeadHH.TabIndex = 18;
            this.chkSingleHeadHH.Tag = "SingleHeadHh";
            this.chkSingleHeadHH.Text = "Single Parent Household";
            this.chkSingleHeadHH.UseVisualStyleBackColor = true;
            // 
            // tbeApt
            // 
            this.tbeApt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeApt.Location = new System.Drawing.Point(428, 11);
            this.tbeApt.Margin = new System.Windows.Forms.Padding(4);
            this.tbeApt.Name = "tbeApt";
            this.tbeApt.Size = new System.Drawing.Size(48, 20);
            this.tbeApt.TabIndex = 12;
            this.tbeApt.Tag = "AptNbr";
            this.tbeApt.Text = "123456789";
            this.tbeApt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(400, 14);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 12);
            this.label7.TabIndex = 128;
            this.label7.Text = "Apt#";
            // 
            // spltcontMain
            // 
            this.spltcontMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltcontMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spltcontMain.IsSplitterFixed = true;
            this.spltcontMain.Location = new System.Drawing.Point(0, 0);
            this.spltcontMain.Name = "spltcontMain";
            this.spltcontMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltcontMain.Panel1
            // 
            this.spltcontMain.Panel1.BackColor = System.Drawing.Color.LightGreen;
            this.spltcontMain.Panel1.Controls.Add(this.lblDupHHMError);
            this.spltcontMain.Panel1.Controls.Add(this.lblDupHHError);
            this.spltcontMain.Panel1.Controls.Add(this.lblDateError);
            this.spltcontMain.Panel1.Controls.Add(this.lblLName);
            this.spltcontMain.Panel1.Controls.Add(this.pnlHH);
            this.spltcontMain.Panel1.Controls.Add(this.lblFName);
            this.spltcontMain.Panel1.Controls.Add(this.tbFirstName);
            this.spltcontMain.Panel1.Controls.Add(this.label1);
            this.spltcontMain.Panel1.Controls.Add(this.tbLastName);
            this.spltcontMain.Panel1.Controls.Add(this.tbAge);
            this.spltcontMain.Panel1.Controls.Add(this.tbBirthDate);
            this.spltcontMain.Panel1.Controls.Add(this.chkEnterAge);
            this.spltcontMain.Panel1.Controls.Add(this.lblBDay);
            this.spltcontMain.Panel1.Controls.Add(this.tbSex);
            this.spltcontMain.Panel1.Controls.Add(this.btnCancel);
            this.spltcontMain.Panel1.Controls.Add(this.lblSex);
            this.spltcontMain.Panel1.Controls.Add(this.btnAddNewMem);
            // 
            // spltcontMain.Panel2
            // 
            this.spltcontMain.Panel2.BackColor = System.Drawing.Color.Chocolate;
            this.spltcontMain.Panel2.Controls.Add(this.spltcontLists);
            this.spltcontMain.Size = new System.Drawing.Size(1008, 692);
            this.spltcontMain.SplitterDistance = 250;
            this.spltcontMain.SplitterWidth = 1;
            this.spltcontMain.TabIndex = 135;
            // 
            // lblDupHHMError
            // 
            this.lblDupHHMError.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.lblDupHHMError.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDupHHMError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDupHHMError.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDupHHMError.Location = new System.Drawing.Point(60, 155);
            this.lblDupHHMError.Name = "lblDupHHMError";
            this.lblDupHHMError.Size = new System.Drawing.Size(194, 65);
            this.lblDupHHMError.TabIndex = 131;
            this.lblDupHHMError.Text = "Duplicate Member Name with Same Birth Date          IS NOT ALLOWED";
            this.lblDupHHMError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDupHHMError.Visible = false;
            // 
            // lblDupHHError
            // 
            this.lblDupHHError.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.lblDupHHError.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDupHHError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDupHHError.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDupHHError.Location = new System.Drawing.Point(339, 9);
            this.lblDupHHError.Name = "lblDupHHError";
            this.lblDupHHError.Size = new System.Drawing.Size(97, 65);
            this.lblDupHHError.TabIndex = 130;
            this.lblDupHHError.Text = "DUPLICATE NAME IS NOT ALLOWED";
            this.lblDupHHError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDupHHError.Visible = false;
            // 
            // lblDateError
            // 
            this.lblDateError.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.lblDateError.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDateError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateError.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDateError.Location = new System.Drawing.Point(78, 127);
            this.lblDateError.Name = "lblDateError";
            this.lblDateError.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDateError.Size = new System.Drawing.Size(148, 24);
            this.lblDateError.TabIndex = 129;
            this.lblDateError.Text = "INVALID BIRTHDATE";
            this.lblDateError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDateError.Visible = false;
            // 
            // spltcontLists
            // 
            this.spltcontLists.BackColor = System.Drawing.Color.Tan;
            this.spltcontLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltcontLists.Location = new System.Drawing.Point(0, 0);
            this.spltcontLists.Name = "spltcontLists";
            this.spltcontLists.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltcontLists.Panel1
            // 
            this.spltcontLists.Panel1.Controls.Add(this.lvwPeople);
            // 
            // spltcontLists.Panel2
            // 
            this.spltcontLists.Panel2.BackColor = System.Drawing.Color.Wheat;
            this.spltcontLists.Panel2.Controls.Add(this.tabControl1);
            this.spltcontLists.Size = new System.Drawing.Size(1008, 441);
            this.spltcontLists.SplitterDistance = 168;
            this.spltcontLists.TabIndex = 0;
            this.spltcontLists.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpgSameBirthDate);
            this.tabControl1.Controls.Add(this.tpgSameHouseNbr);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(150, 25);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(0, 5);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1008, 269);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 21;
            this.tabControl1.TabStop = false;
            // 
            // tpgSameBirthDate
            // 
            this.tpgSameBirthDate.BackColor = System.Drawing.Color.Tan;
            this.tpgSameBirthDate.Controls.Add(this.lvwHHMByBirthdate);
            this.tpgSameBirthDate.Location = new System.Drawing.Point(4, 29);
            this.tpgSameBirthDate.Margin = new System.Windows.Forms.Padding(0);
            this.tpgSameBirthDate.Name = "tpgSameBirthDate";
            this.tpgSameBirthDate.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSameBirthDate.Size = new System.Drawing.Size(1000, 236);
            this.tpgSameBirthDate.TabIndex = 0;
            this.tpgSameBirthDate.Text = " Same Birth Date  ";
            // 
            // tpgSameHouseNbr
            // 
            this.tpgSameHouseNbr.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.tpgSameHouseNbr.Controls.Add(this.lvwSameHouseNbr);
            this.tpgSameHouseNbr.Location = new System.Drawing.Point(4, 29);
            this.tpgSameHouseNbr.Name = "tpgSameHouseNbr";
            this.tpgSameHouseNbr.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSameHouseNbr.Size = new System.Drawing.Size(1000, 236);
            this.tpgSameHouseNbr.TabIndex = 1;
            this.tpgSameHouseNbr.Text = "[22]  Same House Nbr  .";
            // 
            // lvwSameHouseNbr
            // 
            this.lvwSameHouseNbr.BackColor = System.Drawing.Color.Gainsboro;
            this.lvwSameHouseNbr.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.colAddress,
            this.colAptNbr,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lvwSameHouseNbr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwSameHouseNbr.FullRowSelect = true;
            this.lvwSameHouseNbr.GridLines = true;
            this.lvwSameHouseNbr.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwSameHouseNbr.LabelWrap = false;
            this.lvwSameHouseNbr.Location = new System.Drawing.Point(3, 3);
            this.lvwSameHouseNbr.Name = "lvwSameHouseNbr";
            this.lvwSameHouseNbr.Size = new System.Drawing.Size(994, 230);
            this.lvwSameHouseNbr.TabIndex = 15;
            this.lvwSameHouseNbr.TabStop = false;
            this.lvwSameHouseNbr.UseCompatibleStateImageBehavior = false;
            this.lvwSameHouseNbr.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 220;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Inactive";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 70;
            // 
            // colAddress
            // 
            this.colAddress.Text = "Address";
            this.colAddress.Width = 240;
            // 
            // colAptNbr
            // 
            this.colAptNbr.Text = "Apt Nbr";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "City, State Zipcode";
            this.columnHeader4.Width = 200;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "# Trx";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "HH ID";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 80;
            // 
            // AddNewClientOrHHMem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(1008, 692);
            this.Controls.Add(this.spltcontMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddNewClientOrHHMem";
            this.Text = "AddHHMem";
            this.pnlHH.ResumeLayout(false);
            this.pnlHH.PerformLayout();
            this.spltcontMain.Panel1.ResumeLayout(false);
            this.spltcontMain.Panel1.PerformLayout();
            this.spltcontMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltcontMain)).EndInit();
            this.spltcontMain.ResumeLayout(false);
            this.spltcontLists.Panel1.ResumeLayout(false);
            this.spltcontLists.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltcontLists)).EndInit();
            this.spltcontLists.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpgSameBirthDate.ResumeLayout(false);
            this.tpgSameHouseNbr.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbBirthDate;
        private System.Windows.Forms.Label lblBDay;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.TextBox tbSex;
        private System.Windows.Forms.Button btnAddNewMem;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbAge;
        private System.Windows.Forms.CheckBox chkEnterAge;
        private System.Windows.Forms.ListView lvwPeople;
        private System.Windows.Forms.ColumnHeader colLastName;
        private System.Windows.Forms.ColumnHeader colBirthDate;
        private System.Windows.Forms.ColumnHeader colHholdId;
        private System.Windows.Forms.ColumnHeader colFirstName;
        private System.Windows.Forms.ColumnHeader colAge;
        private System.Windows.Forms.ColumnHeader colHHMInactive;
        private System.Windows.Forms.ComboBox cboSpecialLang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbeState;
        private System.Windows.Forms.CheckBox chkInCityLimits;
        private System.Windows.Forms.CheckBox chkHomeless;
        private System.Windows.Forms.TextBox tbeZipCode;
        private System.Windows.Forms.ComboBox cboClientType;
        private System.Windows.Forms.TextBox tbeCity;
        private System.Windows.Forms.TextBox tbeAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvwHHMByBirthdate;
        private System.Windows.Forms.ColumnHeader clmLastName;
        private System.Windows.Forms.ColumnHeader clmFirstName;
        private System.Windows.Forms.ColumnHeader clmHHId;
        private System.Windows.Forms.ColumnHeader clmHHMInactive;
        private System.Windows.Forms.ColumnHeader clmHHName;
        private System.Windows.Forms.ColumnHeader clmAddress;
        private System.Windows.Forms.ColumnHeader clmCity;
        private System.Windows.Forms.ColumnHeader clmZip;
        private System.Windows.Forms.ColumnHeader clmHHInactive;
        private System.Windows.Forms.Panel pnlHH;
        private System.Windows.Forms.SplitContainer spltcontMain;
        private System.Windows.Forms.SplitContainer spltcontLists;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpgSameBirthDate;
        private System.Windows.Forms.TabPage tpgSameHouseNbr;
        private System.Windows.Forms.ListView lvwSameHouseNbr;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader colAddress;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Label lblDateError;
        private System.Windows.Forms.Label lblDupHHError;
        private System.Windows.Forms.TextBox tbeApt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chkSingleHeadHH;
        private System.Windows.Forms.TextBox tbBabySvcDescr;
        private System.Windows.Forms.CheckBox chkBabyServices;
        private System.Windows.Forms.ComboBox cboIDType;
        private System.Windows.Forms.Label lblVerifyMethod;
        private System.Windows.Forms.ComboBox cboPhoneType;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.Label lblPhoneType;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.ColumnHeader colHeadHH;
        private System.Windows.Forms.ColumnHeader colAptNbr;
        private System.Windows.Forms.Label lblDupHHMError;
    }
}