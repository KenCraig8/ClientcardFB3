﻿namespace ClientcardFB3
{
    partial class FamilyCardUserListPlaceholder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbSlot1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbSlot2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tbSlot4 = new System.Windows.Forms.TextBox();
            this.tbSlot3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lstbxHHUserFields = new System.Windows.Forms.ListBox();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LightYellow;
            this.groupBox4.Controls.Add(this.tbSlot1);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.tbSlot2);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.tbSlot4);
            this.groupBox4.Controls.Add(this.tbSlot3);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Location = new System.Drawing.Point(39, 80);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(241, 220);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Family Card Flag Slots";
            // 
            // tbSlot1
            // 
            this.tbSlot1.AllowDrop = true;
            this.tbSlot1.BackColor = System.Drawing.Color.Snow;
            this.tbSlot1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSlot1.ForeColor = System.Drawing.Color.MediumBlue;
            this.tbSlot1.Location = new System.Drawing.Point(4, 52);
            this.tbSlot1.Margin = new System.Windows.Forms.Padding(2);
            this.tbSlot1.Name = "tbSlot1";
            this.tbSlot1.ReadOnly = true;
            this.tbSlot1.Size = new System.Drawing.Size(226, 23);
            this.tbSlot1.TabIndex = 0;
            this.tbSlot1.Tag = "slot1";
            this.tbSlot1.WordWrap = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(2, 36);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Slot 1";
            // 
            // tbSlot2
            // 
            this.tbSlot2.AllowDrop = true;
            this.tbSlot2.BackColor = System.Drawing.Color.Snow;
            this.tbSlot2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSlot2.ForeColor = System.Drawing.Color.MediumBlue;
            this.tbSlot2.Location = new System.Drawing.Point(4, 96);
            this.tbSlot2.Margin = new System.Windows.Forms.Padding(2);
            this.tbSlot2.Name = "tbSlot2";
            this.tbSlot2.ReadOnly = true;
            this.tbSlot2.Size = new System.Drawing.Size(226, 23);
            this.tbSlot2.TabIndex = 3;
            this.tbSlot2.Tag = "slot2";
            this.tbSlot2.WordWrap = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2, 166);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Slot 4";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(2, 80);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Slot 2";
            // 
            // tbSlot4
            // 
            this.tbSlot4.AllowDrop = true;
            this.tbSlot4.BackColor = System.Drawing.Color.Snow;
            this.tbSlot4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSlot4.ForeColor = System.Drawing.Color.MediumBlue;
            this.tbSlot4.Location = new System.Drawing.Point(4, 182);
            this.tbSlot4.Margin = new System.Windows.Forms.Padding(2);
            this.tbSlot4.Name = "tbSlot4";
            this.tbSlot4.ReadOnly = true;
            this.tbSlot4.Size = new System.Drawing.Size(226, 23);
            this.tbSlot4.TabIndex = 7;
            this.tbSlot4.Tag = "slot4";
            this.tbSlot4.WordWrap = false;
            // 
            // tbSlot3
            // 
            this.tbSlot3.AllowDrop = true;
            this.tbSlot3.BackColor = System.Drawing.Color.Snow;
            this.tbSlot3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSlot3.ForeColor = System.Drawing.Color.MediumBlue;
            this.tbSlot3.Location = new System.Drawing.Point(4, 139);
            this.tbSlot3.Margin = new System.Windows.Forms.Padding(2);
            this.tbSlot3.Name = "tbSlot3";
            this.tbSlot3.ReadOnly = true;
            this.tbSlot3.Size = new System.Drawing.Size(226, 23);
            this.tbSlot3.TabIndex = 5;
            this.tbSlot3.Tag = "slot3";
            this.tbSlot3.WordWrap = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 123);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Slot 3";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Maroon;
            this.label14.Location = new System.Drawing.Point(313, 21);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(200, 51);
            this.label14.TabIndex = 14;
            this.label14.Text = "Select desired User Defined field from the list on the right and drop it on the a" +
                "ppropriate box on the left.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(297, 80);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(153, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "Household User Defined Fields";
            // 
            // lstbxHHUserFields
            // 
            this.lstbxHHUserFields.AllowDrop = true;
            this.lstbxHHUserFields.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbxHHUserFields.ForeColor = System.Drawing.Color.MediumBlue;
            this.lstbxHHUserFields.FormattingEnabled = true;
            this.lstbxHHUserFields.ItemHeight = 15;
            this.lstbxHHUserFields.Items.AddRange(new object[] {
            "UserFlag0",
            "UserFlag1",
            "UserFlag2",
            "UserFlag3",
            "UserFlag4",
            "UserFlag5",
            "UserFlag6",
            "UserFlag7",
            "UserFlag8",
            "UserFlag9"});
            this.lstbxHHUserFields.Location = new System.Drawing.Point(299, 96);
            this.lstbxHHUserFields.Margin = new System.Windows.Forms.Padding(2);
            this.lstbxHHUserFields.Name = "lstbxHHUserFields";
            this.lstbxHHUserFields.Size = new System.Drawing.Size(226, 154);
            this.lstbxHHUserFields.TabIndex = 12;
            // 
            // FamilyCardUserListPlaceholder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 453);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lstbxHHUserFields);
            this.Name = "FamilyCardUserListPlaceholder";
            this.Text = "FamilyCardUserListPlaceholder";
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbSlot1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbSlot2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbSlot4;
        private System.Windows.Forms.TextBox tbSlot3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListBox lstbxHHUserFields;
    }
}