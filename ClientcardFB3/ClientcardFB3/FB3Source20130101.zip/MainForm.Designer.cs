﻿namespace ClientcardFB3
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle82 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.ListViewItem listViewItem41 = new System.Windows.Forms.ListViewItem(new string[] {
            "Allocated",
            "120"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem42 = new System.Windows.Forms.ListViewItem(new string[] {
            "Monday",
            "40"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem43 = new System.Windows.Forms.ListViewItem(new string[] {
            "Tuesday",
            "30"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem44 = new System.Windows.Forms.ListViewItem(new string[] {
            "Wednesday",
            "0"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem45 = new System.Windows.Forms.ListViewItem(new string[] {
            "Thursday",
            "0"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem46 = new System.Windows.Forms.ListViewItem(new string[] {
            "Friday",
            "0"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem47 = new System.Windows.Forms.ListViewItem(new string[] {
            "Saturday",
            "0"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem48 = new System.Windows.Forms.ListViewItem(new string[] {
            "Avaialable",
            "50"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle97 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle83 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle84 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle85 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle86 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle87 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle88 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuClient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_FindClient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_AddHH = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuClient_NewSvcOverRide = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_NewService = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuClient_BeginEditClient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_CancelEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_SaveHHChanges = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_DeleteClient = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_PrintClientCard = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_PrintForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuClient_PrintAllClientcards = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuClient_LogOut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTrx = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrx_NewAppointment = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrx_NewServiceTrx = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrx_Edit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrx_Delete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.menuReports = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReports_MonthlyForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReports_AccessRpts = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDatabaseStatistics = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiKingCountyReport = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTools = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_VolHoursForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_DonationsForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_GroceryRescue = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuTools_DonorsForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_VolunteersForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_MaintainVoucherItems = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuTools_Backpack = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_CashDonations = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTools_CSFPServices = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_ServiceItemsForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_YearlyCalendarForm = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAdmin_BackupDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiToggleUserInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAdmin_PreferencesForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_UserDefinedFields = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_TypeCodesForm = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAdmin_UserListForm = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_EmailRecipients = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAdmin_SaveAsNewClientDefaults = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_IncomeMatrix = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin_EditJobsPlan = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiResetPOAFlag = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiResetNeedCommSigFlag = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiResetInactiveFlag = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiCreateUnitedWayExport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHD = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHD_Planner = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuHD_Routes = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHD_FundingPrograms = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHD_Buildings = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp_Contents = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp_Index = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuWSDAFAP = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp_About = new System.Windows.Forms.ToolStripMenuItem();
            this.splCntrCardMembers = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btnBeginEdit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.cboClientType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboServiceMethod = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSupplOnly = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.chkSupplOnly = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblNoCommodities = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAssignBarcode = new System.Windows.Forms.Button();
            this.tbeAddress = new System.Windows.Forms.TextBox();
            this.chkNoCommodities = new System.Windows.Forms.CheckBox();
            this.tbeCity = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tbeZipCode = new System.Windows.Forms.TextBox();
            this.tbeState = new System.Windows.Forms.TextBox();
            this.tbID = new System.Windows.Forms.TextBox();
            this.lblSingleHeadHH = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.tbeApt = new System.Windows.Forms.TextBox();
            this.chkHomeless = new System.Windows.Forms.CheckBox();
            this.chkSingleHeadHH = new System.Windows.Forms.CheckBox();
            this.lblHomeless = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chkInCityLimits = new System.Windows.Forms.CheckBox();
            this.chkInactive = new System.Windows.Forms.CheckBox();
            this.lblInCityLimits = new System.Windows.Forms.Label();
            this.tabFamily = new System.Windows.Forms.TabControl();
            this.tpgFamilyDetail = new System.Windows.Forms.TabPage();
            this.dgvHHMembers = new System.Windows.Forms.DataGridView();
            this.clmInactive = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.clmDiet = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Disabled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cmsHHMembers = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiMoveHHMem = new System.Windows.Forms.ToolStripMenuItem();
            this.tpgFamilySummary = new System.Windows.Forms.TabPage();
            this.tbmEighteens = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCSFP = new System.Windows.Forms.Label();
            this.tbmInfants = new System.Windows.Forms.TextBox();
            this.tbmCSFP = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbmDisabled = new System.Windows.Forms.TextBox();
            this.chkUseFamList = new System.Windows.Forms.CheckBox();
            this.tbmDiet = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbmYouth = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbTotalFam = new System.Windows.Forms.TextBox();
            this.tbmTeens = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tbmSeniors = new System.Windows.Forms.TextBox();
            this.tbmAdults = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.pbxEditAlert = new System.Windows.Forms.PictureBox();
            this.tbAlert = new System.Windows.Forms.RichTextBox();
            this.tbeNotes = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbFindClient = new System.Windows.Forms.ToolStripButton();
            this.tsbHHMem = new System.Windows.Forms.ToolStripButton();
            this.tsbNewService = new System.Windows.Forms.ToolStripButton();
            this.tsbDfltSvcDate = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbAddClient = new System.Windows.Forms.ToolStripButton();
            this.tsbLog = new System.Windows.Forms.ToolStripButton();
            this.splitMemTrans = new System.Windows.Forms.SplitContainer();
            this.tabCntrlMain = new System.Windows.Forms.TabControl();
            this.tpgHHData = new System.Windows.Forms.TabPage();
            this.tbPhone = new System.Windows.Forms.MaskedTextBox();
            this.cboSpecialLang = new System.Windows.Forms.ComboBox();
            this.cboHUDCategory = new System.Windows.Forms.ComboBox();
            this.lblHUDCategory = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblNeedCommodSignature = new System.Windows.Forms.Label();
            this.grpbxVerifyId = new System.Windows.Forms.GroupBox();
            this.lblNeedToVerifyId = new System.Windows.Forms.Label();
            this.chkNeedVerifyID = new System.Windows.Forms.CheckBox();
            this.cboIDType = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tbeDateIDVerified = new System.Windows.Forms.TextBox();
            this.cboPhoneType = new System.Windows.Forms.ComboBox();
            this.lblPhoneType = new System.Windows.Forms.Label();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.chkNeedCommSig = new System.Windows.Forms.CheckBox();
            this.tpgUserFields = new System.Windows.Forms.TabPage();
            this.tbUserNum0 = new System.Windows.Forms.TextBox();
            this.tbUserNum1 = new System.Windows.Forms.TextBox();
            this.lblUserNum0 = new System.Windows.Forms.Label();
            this.lblUserNum1 = new System.Windows.Forms.Label();
            this.chkLstBxUserFields = new System.Windows.Forms.CheckedListBox();
            this.tpgIncome = new System.Windows.Forms.TabPage();
            this.grpbxIncome = new System.Windows.Forms.GroupBox();
            this.tbAnualIncome = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.chkNeedIncomeVerification = new System.Windows.Forms.CheckBox();
            this.lvIncomeGroups = new System.Windows.Forms.ListView();
            this.colIncomeGrpId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colIncomeGrpName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colIncomeCat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbIncomeMonthly = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tpgHD = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lblDriverNotes = new System.Windows.Forms.Label();
            this.cboHDPrograms = new System.Windows.Forms.ComboBox();
            this.cboHDBuilding = new System.Windows.Forms.ComboBox();
            this.lblHDPrograms = new System.Windows.Forms.Label();
            this.lblHDBuildings = new System.Windows.Forms.Label();
            this.cboHDRoute = new System.Windows.Forms.ComboBox();
            this.lblHDRoute = new System.Windows.Forms.Label();
            this.cboHDItem = new System.Windows.Forms.ComboBox();
            this.lblHDItem = new System.Windows.Forms.Label();
            this.tbDriverNotes = new System.Windows.Forms.TextBox();
            this.tpgPointSys = new System.Windows.Forms.TabPage();
            this.tbpPoints = new System.Windows.Forms.TextBox();
            this.lblPoints = new System.Windows.Forms.Label();
            this.lvwPoints = new System.Windows.Forms.ListView();
            this.clmlblWkOf = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmWkOf = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tbNbrSupplThisMonth = new System.Windows.Forms.TextBox();
            this.lblNbrTEFAP = new System.Windows.Forms.Label();
            this.tbNbrTEFAPThisMonth = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tbeFirstService = new System.Windows.Forms.TextBox();
            this.tbNbrTrxThisWeek = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblLastComm = new System.Windows.Forms.Label();
            this.tbNbrTrxThisMonth = new System.Windows.Forms.TextBox();
            this.tbLastService = new System.Windows.Forms.TextBox();
            this.tbLastComodity = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbDaysSinceLstSrvc = new System.Windows.Forms.TextBox();
            this.lblHHModified = new System.Windows.Forms.Label();
            this.lblHHCreated = new System.Windows.Forms.Label();
            this.chkShowOnLog = new System.Windows.Forms.CheckBox();
            this.tbBabySvcDescr = new System.Windows.Forms.TextBox();
            this.chkBabyServices = new System.Windows.Forms.CheckBox();
            this.lblBabyServices = new System.Windows.Forms.Label();
            this.cmsLog = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiExpandLog = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExportToExcel = new System.Windows.Forms.ToolStripMenuItem();
            this.tabCntrlLog = new System.Windows.Forms.TabControl();
            this.tpgTrxLog = new System.Windows.Forms.TabPage();
            this.btnEnlarge = new System.Windows.Forms.Button();
            this.btnColapse = new System.Windows.Forms.Button();
            this.lvTrxLog = new System.Windows.Forms.ListView();
            this.clmNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSvcList = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmNonFoodLst = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmLbs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmOther = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmComm = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSupl = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmBaby = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmNotes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmInfants = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmYouth = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTeens = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmEighteen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmAdults = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSeniors = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTrxID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmCreateBy = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmCreated = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnEditTransLog = new System.Windows.Forms.Button();
            this.cboTrxLogPeriod = new System.Windows.Forms.ComboBox();
            this.LBLpERIOD = new System.Windows.Forms.Label();
            this.tpgVouchers = new System.Windows.Forms.TabPage();
            this.lvVoucherLog = new System.Windows.Forms.ListView();
            this.colCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTrxDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDesc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAmount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNotes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTrxID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnEditVoucherLog = new System.Windows.Forms.Button();
            this.cboVoucherLogPeriod = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnVoucherEnlarge = new System.Windows.Forms.Button();
            this.btnVoucherColapse = new System.Windows.Forms.Button();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbCreateAppt = new System.Windows.Forms.ToolStripButton();
            this.tsbDfltApptDate = new System.Windows.Forms.ToolStripButton();
            this.tsbCSFP = new System.Windows.Forms.ToolStripButton();
            this.tsbFoodDonations = new System.Windows.Forms.ToolStripButton();
            this.tsbPrintClientcard = new System.Windows.Forms.ToolStripButton();
            this.tsbVouchers = new System.Windows.Forms.ToolStripButton();
            this.incomeMatrixToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExportToExcell = new System.Windows.Forms.ToolStripMenuItem();
            this.dlg = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.tsmiShowSignature = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmLastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmFirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmBirthdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmCSFP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmHMID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picSignature = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCntrCardMembers)).BeginInit();
            this.splCntrCardMembers.Panel1.SuspendLayout();
            this.splCntrCardMembers.Panel2.SuspendLayout();
            this.splCntrCardMembers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabFamily.SuspendLayout();
            this.tpgFamilyDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHHMembers)).BeginInit();
            this.cmsHHMembers.SuspendLayout();
            this.tpgFamilySummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEditAlert)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMemTrans)).BeginInit();
            this.splitMemTrans.Panel1.SuspendLayout();
            this.splitMemTrans.Panel2.SuspendLayout();
            this.splitMemTrans.SuspendLayout();
            this.tabCntrlMain.SuspendLayout();
            this.tpgHHData.SuspendLayout();
            this.grpbxVerifyId.SuspendLayout();
            this.tpgUserFields.SuspendLayout();
            this.tpgIncome.SuspendLayout();
            this.grpbxIncome.SuspendLayout();
            this.tpgHD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tpgPointSys.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.cmsLog.SuspendLayout();
            this.tabCntrlLog.SuspendLayout();
            this.tpgTrxLog.SuspendLayout();
            this.tpgVouchers.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSignature)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuClient,
            this.menuTrx,
            this.menuReports,
            this.menuTools,
            this.menuAdmin,
            this.mnuHD,
            this.menuHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuClient
            // 
            this.menuClient.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClient_FindClient,
            this.mnuClient_AddHH,
            this.mnuSeparator4,
            this.mnuClient_NewSvcOverRide,
            this.mnuClient_NewService,
            this.toolStripSeparator15,
            this.mnuClient_BeginEditClient,
            this.mnuClient_CancelEdit,
            this.mnuClient_SaveHHChanges,
            this.mnuClient_DeleteClient,
            this.mnuClient_PrintClientCard,
            this.mnuClient_PrintForm,
            this.mnuSeparator5,
            this.mnuClient_PrintAllClientcards,
            this.mnuSeparator6,
            this.mnuClient_LogOut,
            this.mnuClient_Exit});
            this.menuClient.Name = "menuClient";
            this.menuClient.Size = new System.Drawing.Size(50, 20);
            this.menuClient.Tag = "0";
            this.menuClient.Text = "&Client";
            // 
            // mnuClient_FindClient
            // 
            this.mnuClient_FindClient.Name = "mnuClient_FindClient";
            this.mnuClient_FindClient.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_FindClient.Tag = "0";
            this.mnuClient_FindClient.Text = "&Find Client or Household Member";
            this.mnuClient_FindClient.Click += new System.EventHandler(this.mnuClient_FindClient_Click);
            // 
            // mnuClient_AddHH
            // 
            this.mnuClient_AddHH.Name = "mnuClient_AddHH";
            this.mnuClient_AddHH.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_AddHH.Tag = "0";
            this.mnuClient_AddHH.Text = "&Add Client";
            this.mnuClient_AddHH.Click += new System.EventHandler(this.mnuClient_AddHH_Click);
            // 
            // mnuSeparator4
            // 
            this.mnuSeparator4.Name = "mnuSeparator4";
            this.mnuSeparator4.Size = new System.Drawing.Size(251, 6);
            this.mnuSeparator4.Tag = "0";
            // 
            // mnuClient_NewSvcOverRide
            // 
            this.mnuClient_NewSvcOverRide.Name = "mnuClient_NewSvcOverRide";
            this.mnuClient_NewSvcOverRide.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_NewSvcOverRide.Tag = "0";
            this.mnuClient_NewSvcOverRide.Text = "Allow N&ew Service";
            this.mnuClient_NewSvcOverRide.Click += new System.EventHandler(this.mnuClient_NewSvcOverRide_Click);
            // 
            // mnuClient_NewService
            // 
            this.mnuClient_NewService.Name = "mnuClient_NewService";
            this.mnuClient_NewService.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_NewService.Tag = "0";
            this.mnuClient_NewService.Text = "Give &New Service";
            this.mnuClient_NewService.Click += new System.EventHandler(this.mnuClient_NewService_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(251, 6);
            this.toolStripSeparator15.Tag = "0";
            // 
            // mnuClient_BeginEditClient
            // 
            this.mnuClient_BeginEditClient.Name = "mnuClient_BeginEditClient";
            this.mnuClient_BeginEditClient.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_BeginEditClient.Tag = "0";
            this.mnuClient_BeginEditClient.Text = "&Begin Editing Client";
            this.mnuClient_BeginEditClient.Click += new System.EventHandler(this.mnuClient_BeginEditClient_Click);
            // 
            // mnuClient_CancelEdit
            // 
            this.mnuClient_CancelEdit.Enabled = false;
            this.mnuClient_CancelEdit.Name = "mnuClient_CancelEdit";
            this.mnuClient_CancelEdit.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_CancelEdit.Tag = "0";
            this.mnuClient_CancelEdit.Text = "&Cancel Edit";
            this.mnuClient_CancelEdit.Click += new System.EventHandler(this.mnuClient_CancelEdit_Click);
            // 
            // mnuClient_SaveHHChanges
            // 
            this.mnuClient_SaveHHChanges.Name = "mnuClient_SaveHHChanges";
            this.mnuClient_SaveHHChanges.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_SaveHHChanges.Tag = "0";
            this.mnuClient_SaveHHChanges.Text = "&Save Changes To Client Record";
            this.mnuClient_SaveHHChanges.Click += new System.EventHandler(this.mnuClient_SaveHHChanges_Click);
            // 
            // mnuClient_DeleteClient
            // 
            this.mnuClient_DeleteClient.Name = "mnuClient_DeleteClient";
            this.mnuClient_DeleteClient.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_DeleteClient.Tag = "1";
            this.mnuClient_DeleteClient.Text = "&Delete Client";
            this.mnuClient_DeleteClient.Click += new System.EventHandler(this.mnuClient_DeleteClient_Click);
            // 
            // mnuClient_PrintClientCard
            // 
            this.mnuClient_PrintClientCard.Name = "mnuClient_PrintClientCard";
            this.mnuClient_PrintClientCard.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_PrintClientCard.Tag = "0";
            this.mnuClient_PrintClientCard.Text = "&Print Client Card";
            this.mnuClient_PrintClientCard.Click += new System.EventHandler(this.mnuClient_PrintClientCard_Click);
            // 
            // mnuClient_PrintForm
            // 
            this.mnuClient_PrintForm.Name = "mnuClient_PrintForm";
            this.mnuClient_PrintForm.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_PrintForm.Tag = "0";
            this.mnuClient_PrintForm.Text = "Print Client Household Form";
            this.mnuClient_PrintForm.Click += new System.EventHandler(this.mnuClient_PrintForm_Click);
            // 
            // mnuSeparator5
            // 
            this.mnuSeparator5.Name = "mnuSeparator5";
            this.mnuSeparator5.Size = new System.Drawing.Size(251, 6);
            this.mnuSeparator5.Tag = "0";
            // 
            // mnuClient_PrintAllClientcards
            // 
            this.mnuClient_PrintAllClientcards.Name = "mnuClient_PrintAllClientcards";
            this.mnuClient_PrintAllClientcards.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_PrintAllClientcards.Tag = "1";
            this.mnuClient_PrintAllClientcards.Text = "Print All Client Cards";
            this.mnuClient_PrintAllClientcards.Click += new System.EventHandler(this.mnuClient_PrintAllClientCards_Click);
            // 
            // mnuSeparator6
            // 
            this.mnuSeparator6.Name = "mnuSeparator6";
            this.mnuSeparator6.Size = new System.Drawing.Size(251, 6);
            this.mnuSeparator6.Tag = "0";
            // 
            // mnuClient_LogOut
            // 
            this.mnuClient_LogOut.Name = "mnuClient_LogOut";
            this.mnuClient_LogOut.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_LogOut.Tag = "0";
            this.mnuClient_LogOut.Text = "&Log Out";
            this.mnuClient_LogOut.Click += new System.EventHandler(this.mnuClient_LogOut_Click);
            // 
            // mnuClient_Exit
            // 
            this.mnuClient_Exit.Name = "mnuClient_Exit";
            this.mnuClient_Exit.Size = new System.Drawing.Size(254, 22);
            this.mnuClient_Exit.Tag = "0";
            this.mnuClient_Exit.Text = "E&xit";
            this.mnuClient_Exit.Click += new System.EventHandler(this.mnuClient_Exit_Click);
            // 
            // menuTrx
            // 
            this.menuTrx.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTrx_NewAppointment,
            this.mnuTrx_NewServiceTrx,
            this.mnuTrx_Edit,
            this.mnuTrx_Delete,
            this.toolStripSeparator8});
            this.menuTrx.Name = "menuTrx";
            this.menuTrx.Size = new System.Drawing.Size(86, 20);
            this.menuTrx.Tag = "0";
            this.menuTrx.Text = "&Transactions";
            // 
            // mnuTrx_NewAppointment
            // 
            this.mnuTrx_NewAppointment.Name = "mnuTrx_NewAppointment";
            this.mnuTrx_NewAppointment.Size = new System.Drawing.Size(217, 22);
            this.mnuTrx_NewAppointment.Tag = "0";
            this.mnuTrx_NewAppointment.Text = "Ne&w Appointment";
            this.mnuTrx_NewAppointment.Click += new System.EventHandler(this.mnuTrx_NewAppointment_Click);
            // 
            // mnuTrx_NewServiceTrx
            // 
            this.mnuTrx_NewServiceTrx.Name = "mnuTrx_NewServiceTrx";
            this.mnuTrx_NewServiceTrx.Size = new System.Drawing.Size(217, 22);
            this.mnuTrx_NewServiceTrx.Tag = "0";
            this.mnuTrx_NewServiceTrx.Text = "&New Service";
            // 
            // mnuTrx_Edit
            // 
            this.mnuTrx_Edit.Name = "mnuTrx_Edit";
            this.mnuTrx_Edit.Size = new System.Drawing.Size(217, 22);
            this.mnuTrx_Edit.Tag = "0";
            this.mnuTrx_Edit.Text = "&Edit Transaction";
            this.mnuTrx_Edit.Click += new System.EventHandler(this.mnuTrx_Edit_Click);
            // 
            // mnuTrx_Delete
            // 
            this.mnuTrx_Delete.Name = "mnuTrx_Delete";
            this.mnuTrx_Delete.Size = new System.Drawing.Size(217, 22);
            this.mnuTrx_Delete.Tag = "1";
            this.mnuTrx_Delete.Text = "&Delete Service Transactions";
            this.mnuTrx_Delete.Click += new System.EventHandler(this.mnuTrx_Delete_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(214, 6);
            // 
            // menuReports
            // 
            this.menuReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuReports_MonthlyForm,
            this.mnuReports_AccessRpts,
            this.mnuDatabaseStatistics,
            this.toolStripSeparator12,
            this.tsmiKingCountyReport});
            this.menuReports.Name = "menuReports";
            this.menuReports.Size = new System.Drawing.Size(59, 20);
            this.menuReports.Tag = "0";
            this.menuReports.Text = "&Reports";
            // 
            // mnuReports_MonthlyForm
            // 
            this.mnuReports_MonthlyForm.Name = "mnuReports_MonthlyForm";
            this.mnuReports_MonthlyForm.Size = new System.Drawing.Size(178, 22);
            this.mnuReports_MonthlyForm.Tag = "1";
            this.mnuReports_MonthlyForm.Text = "Monthly Reports";
            this.mnuReports_MonthlyForm.Click += new System.EventHandler(this.mnuReports_MonthlyForm_Click);
            // 
            // mnuReports_AccessRpts
            // 
            this.mnuReports_AccessRpts.Name = "mnuReports_AccessRpts";
            this.mnuReports_AccessRpts.Size = new System.Drawing.Size(178, 22);
            this.mnuReports_AccessRpts.Tag = "0";
            this.mnuReports_AccessRpts.Text = "&Access Reports";
            this.mnuReports_AccessRpts.Click += new System.EventHandler(this.mnuReports_AccessRpts_Click);
            // 
            // mnuDatabaseStatistics
            // 
            this.mnuDatabaseStatistics.Name = "mnuDatabaseStatistics";
            this.mnuDatabaseStatistics.Size = new System.Drawing.Size(178, 22);
            this.mnuDatabaseStatistics.Tag = "1";
            this.mnuDatabaseStatistics.Text = "Database Statistics";
            this.mnuDatabaseStatistics.Click += new System.EventHandler(this.mnuDatabaseStatistics_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(175, 6);
            // 
            // tsmiKingCountyReport
            // 
            this.tsmiKingCountyReport.Name = "tsmiKingCountyReport";
            this.tsmiKingCountyReport.Size = new System.Drawing.Size(178, 22);
            this.tsmiKingCountyReport.Tag = "1";
            this.tsmiKingCountyReport.Text = "King County Report";
            this.tsmiKingCountyReport.Click += new System.EventHandler(this.tsmiKingCountyReport_Click);
            // 
            // menuTools
            // 
            this.menuTools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTools_VolHoursForm,
            this.mnuTools_DonationsForm,
            this.mnuTools_GroceryRescue,
            this.toolStripSeparator2,
            this.mnuTools_DonorsForm,
            this.mnuTools_VolunteersForm,
            this.mnuTools_MaintainVoucherItems,
            this.toolStripSeparator3,
            this.mnuTools_Backpack,
            this.mnuTools_CashDonations,
            this.mnuTools_CSFPServices});
            this.menuTools.Name = "menuTools";
            this.menuTools.Size = new System.Drawing.Size(48, 20);
            this.menuTools.Tag = "1";
            this.menuTools.Text = "T&ools";
            // 
            // mnuTools_VolHoursForm
            // 
            this.mnuTools_VolHoursForm.Name = "mnuTools_VolHoursForm";
            this.mnuTools_VolHoursForm.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_VolHoursForm.Tag = "1";
            this.mnuTools_VolHoursForm.Text = "Enter Volunteer &Hours";
            this.mnuTools_VolHoursForm.Click += new System.EventHandler(this.mnuTools_VolHoursForm_Click);
            // 
            // mnuTools_DonationsForm
            // 
            this.mnuTools_DonationsForm.Name = "mnuTools_DonationsForm";
            this.mnuTools_DonationsForm.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_DonationsForm.Tag = "1";
            this.mnuTools_DonationsForm.Text = "Enter Food &Receipts";
            this.mnuTools_DonationsForm.Click += new System.EventHandler(this.mnuTools_DonationsForm_Click);
            // 
            // mnuTools_GroceryRescue
            // 
            this.mnuTools_GroceryRescue.Name = "mnuTools_GroceryRescue";
            this.mnuTools_GroceryRescue.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_GroceryRescue.Tag = "1";
            this.mnuTools_GroceryRescue.Text = "Enter &Grocery Rescue";
            this.mnuTools_GroceryRescue.Click += new System.EventHandler(this.mnuTools_GroceryRescueToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(197, 6);
            // 
            // mnuTools_DonorsForm
            // 
            this.mnuTools_DonorsForm.Name = "mnuTools_DonorsForm";
            this.mnuTools_DonorsForm.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_DonorsForm.Tag = "1";
            this.mnuTools_DonorsForm.Text = "Maintain &Donors";
            this.mnuTools_DonorsForm.Click += new System.EventHandler(this.mnuTools_DonorsForm_Click);
            // 
            // mnuTools_VolunteersForm
            // 
            this.mnuTools_VolunteersForm.Name = "mnuTools_VolunteersForm";
            this.mnuTools_VolunteersForm.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_VolunteersForm.Tag = "1";
            this.mnuTools_VolunteersForm.Text = "Maintain &Volunteers";
            this.mnuTools_VolunteersForm.Click += new System.EventHandler(this.mnuTools_VolunteersForm_Click);
            // 
            // mnuTools_MaintainVoucherItems
            // 
            this.mnuTools_MaintainVoucherItems.Name = "mnuTools_MaintainVoucherItems";
            this.mnuTools_MaintainVoucherItems.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_MaintainVoucherItems.Tag = "1";
            this.mnuTools_MaintainVoucherItems.Text = "Maintain Voucher &Items";
            this.mnuTools_MaintainVoucherItems.Click += new System.EventHandler(this.mnuTools_MaintainVoucherItems_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(197, 6);
            // 
            // mnuTools_Backpack
            // 
            this.mnuTools_Backpack.Name = "mnuTools_Backpack";
            this.mnuTools_Backpack.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_Backpack.Tag = "1";
            this.mnuTools_Backpack.Text = "&Backpack Services";
            this.mnuTools_Backpack.Click += new System.EventHandler(this.mnuTools_Backpack_Click);
            // 
            // mnuTools_CashDonations
            // 
            this.mnuTools_CashDonations.Name = "mnuTools_CashDonations";
            this.mnuTools_CashDonations.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_CashDonations.Tag = "2";
            this.mnuTools_CashDonations.Text = "&Cash Donations";
            this.mnuTools_CashDonations.Click += new System.EventHandler(this.mnuTools_CashDonations_Click);
            // 
            // mnuTools_CSFPServices
            // 
            this.mnuTools_CSFPServices.Name = "mnuTools_CSFPServices";
            this.mnuTools_CSFPServices.Size = new System.Drawing.Size(200, 22);
            this.mnuTools_CSFPServices.Tag = "1";
            this.mnuTools_CSFPServices.Text = "C&SFP Services";
            this.mnuTools_CSFPServices.Click += new System.EventHandler(this.mnuTools_CSFPServices_Click);
            // 
            // menuAdmin
            // 
            this.menuAdmin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAdmin_ServiceItemsForm,
            this.mnuAdmin_YearlyCalendarForm,
            this.toolStripSeparator1,
            this.mnuAdmin_BackupDatabase,
            this.tsmiToggleUserInfo,
            this.toolStripSeparator9,
            this.mnuAdmin_PreferencesForm,
            this.mnuAdmin_UserDefinedFields,
            this.mnuAdmin_TypeCodesForm,
            this.toolStripSeparator5,
            this.mnuAdmin_UserListForm,
            this.mnuAdmin_EmailRecipients,
            this.toolStripSeparator7,
            this.mnuAdmin_SaveAsNewClientDefaults,
            this.mnuAdmin_IncomeMatrix,
            this.mnuAdmin_EditJobsPlan,
            this.toolStripSeparator10,
            this.tsmiResetPOAFlag,
            this.tsmiResetNeedCommSigFlag,
            this.tsmiResetInactiveFlag,
            this.toolStripSeparator11,
            this.tsmiCreateUnitedWayExport});
            this.menuAdmin.Name = "menuAdmin";
            this.menuAdmin.Size = new System.Drawing.Size(55, 20);
            this.menuAdmin.Tag = "1";
            this.menuAdmin.Text = "Adm&in";
            // 
            // mnuAdmin_ServiceItemsForm
            // 
            this.mnuAdmin_ServiceItemsForm.Name = "mnuAdmin_ServiceItemsForm";
            this.mnuAdmin_ServiceItemsForm.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_ServiceItemsForm.Tag = "1";
            this.mnuAdmin_ServiceItemsForm.Text = "Edit Service &Items";
            this.mnuAdmin_ServiceItemsForm.Click += new System.EventHandler(this.mnuAdmin_ServiceItemsForm_Click);
            // 
            // mnuAdmin_YearlyCalendarForm
            // 
            this.mnuAdmin_YearlyCalendarForm.Name = "mnuAdmin_YearlyCalendarForm";
            this.mnuAdmin_YearlyCalendarForm.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_YearlyCalendarForm.Tag = "1";
            this.mnuAdmin_YearlyCalendarForm.Text = "&Yearly Calendar";
            this.mnuAdmin_YearlyCalendarForm.Click += new System.EventHandler(this.mnuAdmin_YearlyCalendarForm_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(272, 6);
            // 
            // mnuAdmin_BackupDatabase
            // 
            this.mnuAdmin_BackupDatabase.Name = "mnuAdmin_BackupDatabase";
            this.mnuAdmin_BackupDatabase.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_BackupDatabase.Tag = "1";
            this.mnuAdmin_BackupDatabase.Text = "Backup Database";
            this.mnuAdmin_BackupDatabase.Click += new System.EventHandler(this.mnuAdmin_BackupDatabase_Click);
            // 
            // tsmiToggleUserInfo
            // 
            this.tsmiToggleUserInfo.Name = "tsmiToggleUserInfo";
            this.tsmiToggleUserInfo.Size = new System.Drawing.Size(275, 22);
            this.tsmiToggleUserInfo.Tag = "2";
            this.tsmiToggleUserInfo.Text = "Toggle User Info";
            this.tsmiToggleUserInfo.Click += new System.EventHandler(this.tsmiToggleUserInfo_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(272, 6);
            // 
            // mnuAdmin_PreferencesForm
            // 
            this.mnuAdmin_PreferencesForm.Name = "mnuAdmin_PreferencesForm";
            this.mnuAdmin_PreferencesForm.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_PreferencesForm.Tag = "2";
            this.mnuAdmin_PreferencesForm.Text = "&Preferences";
            this.mnuAdmin_PreferencesForm.Click += new System.EventHandler(this.mnuAdmin_PreferencesForm_Click);
            // 
            // mnuAdmin_UserDefinedFields
            // 
            this.mnuAdmin_UserDefinedFields.Name = "mnuAdmin_UserDefinedFields";
            this.mnuAdmin_UserDefinedFields.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_UserDefinedFields.Tag = "2";
            this.mnuAdmin_UserDefinedFields.Text = "User &Defined Fields";
            this.mnuAdmin_UserDefinedFields.Click += new System.EventHandler(this.mnuAdmin_UserDefinedFields_Click);
            // 
            // mnuAdmin_TypeCodesForm
            // 
            this.mnuAdmin_TypeCodesForm.Name = "mnuAdmin_TypeCodesForm";
            this.mnuAdmin_TypeCodesForm.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_TypeCodesForm.Tag = "1";
            this.mnuAdmin_TypeCodesForm.Text = "&Type Codes";
            this.mnuAdmin_TypeCodesForm.Click += new System.EventHandler(this.typeCodesToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(272, 6);
            // 
            // mnuAdmin_UserListForm
            // 
            this.mnuAdmin_UserListForm.Name = "mnuAdmin_UserListForm";
            this.mnuAdmin_UserListForm.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_UserListForm.Tag = "2";
            this.mnuAdmin_UserListForm.Text = "&User List";
            this.mnuAdmin_UserListForm.Click += new System.EventHandler(this.userListToolStripMenuItem_Click);
            // 
            // mnuAdmin_EmailRecipients
            // 
            this.mnuAdmin_EmailRecipients.Name = "mnuAdmin_EmailRecipients";
            this.mnuAdmin_EmailRecipients.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_EmailRecipients.Tag = "1";
            this.mnuAdmin_EmailRecipients.Text = "Manage &Monthly Reports";
            this.mnuAdmin_EmailRecipients.Click += new System.EventHandler(this.mnuAdmin_EmailRecipients_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(272, 6);
            // 
            // mnuAdmin_SaveAsNewClientDefaults
            // 
            this.mnuAdmin_SaveAsNewClientDefaults.Name = "mnuAdmin_SaveAsNewClientDefaults";
            this.mnuAdmin_SaveAsNewClientDefaults.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_SaveAsNewClientDefaults.Tag = "1";
            this.mnuAdmin_SaveAsNewClientDefaults.Text = "New &Client Defaults";
            this.mnuAdmin_SaveAsNewClientDefaults.Visible = false;
            this.mnuAdmin_SaveAsNewClientDefaults.Click += new System.EventHandler(this.mnuAdmin_SaveAsNewClientDefaults_Click);
            // 
            // mnuAdmin_IncomeMatrix
            // 
            this.mnuAdmin_IncomeMatrix.Name = "mnuAdmin_IncomeMatrix";
            this.mnuAdmin_IncomeMatrix.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_IncomeMatrix.Tag = "1";
            this.mnuAdmin_IncomeMatrix.Text = "Update Income Matri&x";
            this.mnuAdmin_IncomeMatrix.Click += new System.EventHandler(this.mnuAdmin_IncomeMatrix_Click);
            // 
            // mnuAdmin_EditJobsPlan
            // 
            this.mnuAdmin_EditJobsPlan.Name = "mnuAdmin_EditJobsPlan";
            this.mnuAdmin_EditJobsPlan.Size = new System.Drawing.Size(275, 22);
            this.mnuAdmin_EditJobsPlan.Tag = "1";
            this.mnuAdmin_EditJobsPlan.Text = "Edit Jobs Plan";
            this.mnuAdmin_EditJobsPlan.Click += new System.EventHandler(this.mnuAdmin_EditJobsPlan_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(272, 6);
            // 
            // tsmiResetPOAFlag
            // 
            this.tsmiResetPOAFlag.Name = "tsmiResetPOAFlag";
            this.tsmiResetPOAFlag.Size = new System.Drawing.Size(275, 22);
            this.tsmiResetPOAFlag.Tag = "2";
            this.tsmiResetPOAFlag.Text = "Reset Proof Of Address Flag";
            this.tsmiResetPOAFlag.Click += new System.EventHandler(this.tsmiResetPOAFlag_Click);
            // 
            // tsmiResetNeedCommSigFlag
            // 
            this.tsmiResetNeedCommSigFlag.Name = "tsmiResetNeedCommSigFlag";
            this.tsmiResetNeedCommSigFlag.Size = new System.Drawing.Size(275, 22);
            this.tsmiResetNeedCommSigFlag.Tag = "2";
            this.tsmiResetNeedCommSigFlag.Text = "Reset Need Commodity Signiture Flag";
            this.tsmiResetNeedCommSigFlag.Click += new System.EventHandler(this.tsmiResetNeedCommSigFlag_Click);
            // 
            // tsmiResetInactiveFlag
            // 
            this.tsmiResetInactiveFlag.Name = "tsmiResetInactiveFlag";
            this.tsmiResetInactiveFlag.Size = new System.Drawing.Size(275, 22);
            this.tsmiResetInactiveFlag.Tag = "2";
            this.tsmiResetInactiveFlag.Text = "Reset Inactive Flag";
            this.tsmiResetInactiveFlag.Click += new System.EventHandler(this.tsmiResetInactiveFlag_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(272, 6);
            // 
            // tsmiCreateUnitedWayExport
            // 
            this.tsmiCreateUnitedWayExport.Name = "tsmiCreateUnitedWayExport";
            this.tsmiCreateUnitedWayExport.Size = new System.Drawing.Size(275, 22);
            this.tsmiCreateUnitedWayExport.Tag = "2";
            this.tsmiCreateUnitedWayExport.Text = "Create United Way Export";
            this.tsmiCreateUnitedWayExport.Click += new System.EventHandler(this.tsmiCreateUnitedWayExport_Click);
            // 
            // mnuHD
            // 
            this.mnuHD.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHD_Planner,
            this.toolStripSeparator14,
            this.mnuHD_Routes,
            this.mnuHD_FundingPrograms,
            this.mnuHD_Buildings});
            this.mnuHD.Name = "mnuHD";
            this.mnuHD.Size = new System.Drawing.Size(97, 20);
            this.mnuHD.Tag = "1";
            this.mnuHD.Text = "H&ome Delivery";
            this.mnuHD.Visible = false;
            // 
            // mnuHD_Planner
            // 
            this.mnuHD_Planner.Name = "mnuHD_Planner";
            this.mnuHD_Planner.Size = new System.Drawing.Size(177, 22);
            this.mnuHD_Planner.Tag = "1";
            this.mnuHD_Planner.Text = "&Planner";
            this.mnuHD_Planner.Click += new System.EventHandler(this.mnuHD_Planner_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(174, 6);
            // 
            // mnuHD_Routes
            // 
            this.mnuHD_Routes.Name = "mnuHD_Routes";
            this.mnuHD_Routes.Size = new System.Drawing.Size(177, 22);
            this.mnuHD_Routes.Tag = "1";
            this.mnuHD_Routes.Text = "&Route Maintenance";
            this.mnuHD_Routes.Click += new System.EventHandler(this.mnuHD_Routes_Click);
            // 
            // mnuHD_FundingPrograms
            // 
            this.mnuHD_FundingPrograms.Name = "mnuHD_FundingPrograms";
            this.mnuHD_FundingPrograms.Size = new System.Drawing.Size(177, 22);
            this.mnuHD_FundingPrograms.Tag = "1";
            this.mnuHD_FundingPrograms.Text = "&Funding Programs";
            this.mnuHD_FundingPrograms.Click += new System.EventHandler(this.mnuHD_FundingPrograms_Click);
            // 
            // mnuHD_Buildings
            // 
            this.mnuHD_Buildings.Name = "mnuHD_Buildings";
            this.mnuHD_Buildings.Size = new System.Drawing.Size(177, 22);
            this.mnuHD_Buildings.Tag = "1";
            this.mnuHD_Buildings.Text = "&Buildings";
            this.mnuHD_Buildings.Click += new System.EventHandler(this.mnuHD_Buildings_Click);
            // 
            // menuHelp
            // 
            this.menuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelp_Contents,
            this.mnuHelp_Index,
            this.toolStripSeparator4,
            this.mnuWSDAFAP,
            this.mnuHelp_About});
            this.menuHelp.Name = "menuHelp";
            this.menuHelp.Size = new System.Drawing.Size(44, 20);
            this.menuHelp.Tag = "0";
            this.menuHelp.Text = "&Help";
            // 
            // mnuHelp_Contents
            // 
            this.mnuHelp_Contents.Name = "mnuHelp_Contents";
            this.mnuHelp_Contents.Size = new System.Drawing.Size(252, 22);
            this.mnuHelp_Contents.Tag = "0";
            this.mnuHelp_Contents.Text = "&Contents";
            // 
            // mnuHelp_Index
            // 
            this.mnuHelp_Index.Name = "mnuHelp_Index";
            this.mnuHelp_Index.Size = new System.Drawing.Size(252, 22);
            this.mnuHelp_Index.Tag = "0";
            this.mnuHelp_Index.Text = "&Index";
            this.mnuHelp_Index.Click += new System.EventHandler(this.mnuHelp_Index_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(249, 6);
            this.toolStripSeparator4.Tag = "0";
            // 
            // mnuWSDAFAP
            // 
            this.mnuWSDAFAP.Name = "mnuWSDAFAP";
            this.mnuWSDAFAP.Size = new System.Drawing.Size(252, 22);
            this.mnuWSDAFAP.Tag = "0";
            this.mnuWSDAFAP.Text = "WSDA - Food Assistance Program";
            this.mnuWSDAFAP.Click += new System.EventHandler(this.mnuWSDAFAP_Click);
            // 
            // mnuHelp_About
            // 
            this.mnuHelp_About.Name = "mnuHelp_About";
            this.mnuHelp_About.Size = new System.Drawing.Size(252, 22);
            this.mnuHelp_About.Tag = "0";
            this.mnuHelp_About.Text = "&About";
            this.mnuHelp_About.Click += new System.EventHandler(this.mnuHelp_About_Click);
            // 
            // splCntrCardMembers
            // 
            this.splCntrCardMembers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splCntrCardMembers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntrCardMembers.Location = new System.Drawing.Point(0, 24);
            this.splCntrCardMembers.Margin = new System.Windows.Forms.Padding(4);
            this.splCntrCardMembers.Name = "splCntrCardMembers";
            this.splCntrCardMembers.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCntrCardMembers.Panel1
            // 
            this.splCntrCardMembers.Panel1.BackColor = System.Drawing.Color.Wheat;
            this.splCntrCardMembers.Panel1.Controls.Add(this.splitContainer3);
            this.splCntrCardMembers.Panel1.Controls.Add(this.toolStrip1);
            this.splCntrCardMembers.Panel1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splCntrCardMembers.Panel1MinSize = 290;
            // 
            // splCntrCardMembers.Panel2
            // 
            this.splCntrCardMembers.Panel2.Controls.Add(this.splitMemTrans);
            this.splCntrCardMembers.Panel2.Controls.Add(this.toolStrip2);
            this.splCntrCardMembers.Panel2MinSize = 160;
            this.splCntrCardMembers.Size = new System.Drawing.Size(984, 638);
            this.splCntrCardMembers.SplitterDistance = 304;
            this.splCntrCardMembers.TabIndex = 1;
            this.splCntrCardMembers.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splCntrCardMembers_SplitterMoved);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(82, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.btnBeginEdit);
            this.splitContainer3.Panel1.Controls.Add(this.btnCancel);
            this.splitContainer3.Panel1.Controls.Add(this.btnPrevious);
            this.splitContainer3.Panel1.Controls.Add(this.cboClientType);
            this.splitContainer3.Panel1.Controls.Add(this.label3);
            this.splitContainer3.Panel1.Controls.Add(this.cboServiceMethod);
            this.splitContainer3.Panel1.Controls.Add(this.label4);
            this.splitContainer3.Panel1.Controls.Add(this.lblSupplOnly);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            this.splitContainer3.Panel1.Controls.Add(this.chkSupplOnly);
            this.splitContainer3.Panel1.Controls.Add(this.panel1);
            this.splitContainer3.Panel1.Controls.Add(this.label5);
            this.splitContainer3.Panel1.Controls.Add(this.lblNoCommodities);
            this.splitContainer3.Panel1.Controls.Add(this.label6);
            this.splitContainer3.Panel1.Controls.Add(this.btnAssignBarcode);
            this.splitContainer3.Panel1.Controls.Add(this.tbeAddress);
            this.splitContainer3.Panel1.Controls.Add(this.chkNoCommodities);
            this.splitContainer3.Panel1.Controls.Add(this.tbeCity);
            this.splitContainer3.Panel1.Controls.Add(this.label27);
            this.splitContainer3.Panel1.Controls.Add(this.tbeZipCode);
            this.splitContainer3.Panel1.Controls.Add(this.tbeState);
            this.splitContainer3.Panel1.Controls.Add(this.tbID);
            this.splitContainer3.Panel1.Controls.Add(this.lblSingleHeadHH);
            this.splitContainer3.Panel1.Controls.Add(this.btnNext);
            this.splitContainer3.Panel1.Controls.Add(this.tbeApt);
            this.splitContainer3.Panel1.Controls.Add(this.chkHomeless);
            this.splitContainer3.Panel1.Controls.Add(this.chkSingleHeadHH);
            this.splitContainer3.Panel1.Controls.Add(this.lblHomeless);
            this.splitContainer3.Panel1.Controls.Add(this.label7);
            this.splitContainer3.Panel1.Controls.Add(this.chkInCityLimits);
            this.splitContainer3.Panel1.Controls.Add(this.chkInactive);
            this.splitContainer3.Panel1.Controls.Add(this.lblInCityLimits);
            this.splitContainer3.Panel1.Controls.Add(this.tabFamily);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(900, 302);
            this.splitContainer3.SplitterDistance = 610;
            this.splitContainer3.SplitterWidth = 1;
            this.splitContainer3.TabIndex = 128;
            // 
            // btnBeginEdit
            // 
            this.btnBeginEdit.Location = new System.Drawing.Point(1, 28);
            this.btnBeginEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnBeginEdit.Name = "btnBeginEdit";
            this.btnBeginEdit.Size = new System.Drawing.Size(115, 28);
            this.btnBeginEdit.TabIndex = 126;
            this.btnBeginEdit.Text = "&Begin Edit";
            this.btnBeginEdit.UseVisualStyleBackColor = true;
            this.btnBeginEdit.Click += new System.EventHandler(this.btnBeginEdit_Click);
            this.btnBeginEdit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnNavigate_KeyDown);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(1, 56);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(115, 25);
            this.btnCancel.TabIndex = 127;
            this.btnCancel.Text = "Cancel &Edit";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Visible = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.Location = new System.Drawing.Point(2, 0);
            this.btnPrevious.Margin = new System.Windows.Forms.Padding(4);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(24, 24);
            this.btnPrevious.TabIndex = 3;
            this.btnPrevious.TabStop = false;
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            this.btnPrevious.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnNavigate_KeyDown);
            // 
            // cboClientType
            // 
            this.cboClientType.BackColor = System.Drawing.Color.White;
            this.cboClientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboClientType.FormattingEnabled = true;
            this.cboClientType.ItemHeight = 14;
            this.cboClientType.Location = new System.Drawing.Point(195, 82);
            this.cboClientType.Margin = new System.Windows.Forms.Padding(4);
            this.cboClientType.Name = "cboClientType";
            this.cboClientType.Size = new System.Drawing.Size(186, 22);
            this.cboClientType.TabIndex = 10;
            this.cboClientType.Tag = "ClientType";
            this.cboClientType.SelectionChangeCommitted += new System.EventHandler(this.cboClientType_SelectionChangeCommitted);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Address:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboServiceMethod
            // 
            this.cboServiceMethod.BackColor = System.Drawing.Color.White;
            this.cboServiceMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboServiceMethod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboServiceMethod.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboServiceMethod.FormattingEnabled = true;
            this.cboServiceMethod.ItemHeight = 14;
            this.cboServiceMethod.Location = new System.Drawing.Point(195, 108);
            this.cboServiceMethod.Margin = new System.Windows.Forms.Padding(4);
            this.cboServiceMethod.Name = "cboServiceMethod";
            this.cboServiceMethod.Size = new System.Drawing.Size(186, 22);
            this.cboServiceMethod.TabIndex = 11;
            this.cboServiceMethod.Tag = "ServiceMethod";
            this.cboServiceMethod.SelectionChangeCommitted += new System.EventHandler(this.cboServiceMethod_SelectionChangeCommitted);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(112, 58);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "City:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSupplOnly
            // 
            this.lblSupplOnly.AutoSize = true;
            this.lblSupplOnly.BackColor = System.Drawing.Color.Transparent;
            this.lblSupplOnly.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplOnly.Location = new System.Drawing.Point(471, 148);
            this.lblSupplOnly.Name = "lblSupplOnly";
            this.lblSupplOnly.Size = new System.Drawing.Size(84, 17);
            this.lblSupplOnly.TabIndex = 111;
            this.lblSupplOnly.Text = "Suppl Only";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(112, 85);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 17);
            this.label8.TabIndex = 29;
            this.label8.Text = "Category:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chkSupplOnly
            // 
            this.chkSupplOnly.Location = new System.Drawing.Point(454, 148);
            this.chkSupplOnly.Margin = new System.Windows.Forms.Padding(4);
            this.chkSupplOnly.Name = "chkSupplOnly";
            this.chkSupplOnly.Size = new System.Drawing.Size(20, 18);
            this.chkSupplOnly.TabIndex = 15;
            this.chkSupplOnly.Tag = "SupplOnly";
            this.chkSupplOnly.UseVisualStyleBackColor = true;
            this.chkSupplOnly.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkSupplOnly.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Cornsilk;
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(130, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(463, 25);
            this.panel1.TabIndex = 122;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Lucida Console", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblName.Location = new System.Drawing.Point(3, 3);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(86, 19);
            this.lblName.TabIndex = 121;
            this.lblName.Text = "lblName";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(415, 60);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "St:";
            // 
            // lblNoCommodities
            // 
            this.lblNoCommodities.AutoSize = true;
            this.lblNoCommodities.BackColor = System.Drawing.Color.Transparent;
            this.lblNoCommodities.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoCommodities.Location = new System.Drawing.Point(471, 126);
            this.lblNoCommodities.Name = "lblNoCommodities";
            this.lblNoCommodities.Size = new System.Drawing.Size(123, 17);
            this.lblNoCommodities.TabIndex = 112;
            this.lblNoCommodities.Text = "No Commodities";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(494, 61);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Zip:";
            // 
            // btnAssignBarcode
            // 
            this.btnAssignBarcode.BackColor = System.Drawing.Color.Khaki;
            this.btnAssignBarcode.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnAssignBarcode.FlatAppearance.BorderSize = 3;
            this.btnAssignBarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssignBarcode.ForeColor = System.Drawing.Color.Black;
            this.btnAssignBarcode.Location = new System.Drawing.Point(3, 130);
            this.btnAssignBarcode.Name = "btnAssignBarcode";
            this.btnAssignBarcode.Size = new System.Drawing.Size(125, 34);
            this.btnAssignBarcode.TabIndex = 116;
            this.btnAssignBarcode.TabStop = false;
            this.btnAssignBarcode.Text = "Assign Barcode";
            this.btnAssignBarcode.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAssignBarcode.UseVisualStyleBackColor = false;
            this.btnAssignBarcode.Click += new System.EventHandler(this.btnAssignBarcode_Click);
            this.btnAssignBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnNavigate_KeyDown);
            // 
            // tbeAddress
            // 
            this.tbeAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbeAddress.Font = new System.Drawing.Font("Lucida Console", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeAddress.Location = new System.Drawing.Point(195, 33);
            this.tbeAddress.Margin = new System.Windows.Forms.Padding(4);
            this.tbeAddress.MaxLength = 50;
            this.tbeAddress.Name = "tbeAddress";
            this.tbeAddress.Size = new System.Drawing.Size(329, 22);
            this.tbeAddress.TabIndex = 5;
            this.tbeAddress.Tag = "Address";
            this.tbeAddress.Text = "12345678901234567890123456789012345678901234567890";
            this.tbeAddress.Leave += new System.EventHandler(this.tbeAddress_Leave);
            // 
            // chkNoCommodities
            // 
            this.chkNoCommodities.Location = new System.Drawing.Point(454, 127);
            this.chkNoCommodities.Margin = new System.Windows.Forms.Padding(4);
            this.chkNoCommodities.Name = "chkNoCommodities";
            this.chkNoCommodities.Size = new System.Drawing.Size(20, 18);
            this.chkNoCommodities.TabIndex = 14;
            this.chkNoCommodities.Tag = "NoCommodities";
            this.chkNoCommodities.UseVisualStyleBackColor = true;
            this.chkNoCommodities.CheckedChanged += new System.EventHandler(this.chkNoCommodities_CheckedChanged);
            this.chkNoCommodities.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkNoCommodities.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // tbeCity
            // 
            this.tbeCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbeCity.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeCity.Location = new System.Drawing.Point(195, 58);
            this.tbeCity.Margin = new System.Windows.Forms.Padding(4);
            this.tbeCity.MaxLength = 40;
            this.tbeCity.Name = "tbeCity";
            this.tbeCity.Size = new System.Drawing.Size(215, 21);
            this.tbeCity.TabIndex = 7;
            this.tbeCity.Tag = "City";
            this.tbeCity.Text = "123456789012345678901234567890";
            this.tbeCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbeCity_KeyDown);
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(112, 110);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 17);
            this.label27.TabIndex = 115;
            this.label27.Text = "Svc Method:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbeZipCode
            // 
            this.tbeZipCode.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeZipCode.Location = new System.Drawing.Point(526, 58);
            this.tbeZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.tbeZipCode.MaxLength = 10;
            this.tbeZipCode.Name = "tbeZipCode";
            this.tbeZipCode.Size = new System.Drawing.Size(80, 21);
            this.tbeZipCode.TabIndex = 9;
            this.tbeZipCode.Tag = "Zipcode";
            this.tbeZipCode.Text = "98072";
            this.tbeZipCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbeZipCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbeZipCode_KeyDown);
            // 
            // tbeState
            // 
            this.tbeState.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbeState.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeState.Location = new System.Drawing.Point(439, 58);
            this.tbeState.Margin = new System.Windows.Forms.Padding(4);
            this.tbeState.MaxLength = 2;
            this.tbeState.Name = "tbeState";
            this.tbeState.Size = new System.Drawing.Size(40, 21);
            this.tbeState.TabIndex = 8;
            this.tbeState.Tag = "State";
            this.tbeState.Text = "WW";
            this.tbeState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbID
            // 
            this.tbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbID.Location = new System.Drawing.Point(29, 0);
            this.tbID.Margin = new System.Windows.Forms.Padding(4);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(67, 23);
            this.tbID.TabIndex = 1;
            this.tbID.Tag = "ID";
            this.tbID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbID.TextChanged += new System.EventHandler(this.tbID_TextChanged);
            this.tbID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbID_KeyDown);
            // 
            // lblSingleHeadHH
            // 
            this.lblSingleHeadHH.AutoSize = true;
            this.lblSingleHeadHH.BackColor = System.Drawing.Color.Transparent;
            this.lblSingleHeadHH.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSingleHeadHH.Location = new System.Drawing.Point(213, 142);
            this.lblSingleHeadHH.Name = "lblSingleHeadHH";
            this.lblSingleHeadHH.Size = new System.Drawing.Size(179, 17);
            this.lblSingleHeadHH.TabIndex = 117;
            this.lblSingleHeadHH.Text = "Single Parent Household";
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.Location = new System.Drawing.Point(99, 0);
            this.btnNext.Margin = new System.Windows.Forms.Padding(4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(24, 24);
            this.btnNext.TabIndex = 4;
            this.btnNext.TabStop = false;
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            this.btnNext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.btnNavigate_KeyDown);
            // 
            // tbeApt
            // 
            this.tbeApt.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeApt.Location = new System.Drawing.Point(562, 33);
            this.tbeApt.Margin = new System.Windows.Forms.Padding(4);
            this.tbeApt.Name = "tbeApt";
            this.tbeApt.Size = new System.Drawing.Size(44, 21);
            this.tbeApt.TabIndex = 6;
            this.tbeApt.Tag = "AptNbr";
            this.tbeApt.Text = "123456";
            this.tbeApt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chkHomeless
            // 
            this.chkHomeless.Location = new System.Drawing.Point(454, 106);
            this.chkHomeless.Margin = new System.Windows.Forms.Padding(4);
            this.chkHomeless.Name = "chkHomeless";
            this.chkHomeless.Size = new System.Drawing.Size(20, 18);
            this.chkHomeless.TabIndex = 13;
            this.chkHomeless.Tag = "Homeless";
            this.chkHomeless.UseVisualStyleBackColor = true;
            this.chkHomeless.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkHomeless.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // chkSingleHeadHH
            // 
            this.chkSingleHeadHH.Location = new System.Drawing.Point(195, 143);
            this.chkSingleHeadHH.Margin = new System.Windows.Forms.Padding(4);
            this.chkSingleHeadHH.Name = "chkSingleHeadHH";
            this.chkSingleHeadHH.Size = new System.Drawing.Size(20, 18);
            this.chkSingleHeadHH.TabIndex = 16;
            this.chkSingleHeadHH.Tag = "SingleHeadHh";
            this.chkSingleHeadHH.UseVisualStyleBackColor = true;
            this.chkSingleHeadHH.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkSingleHeadHH.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // lblHomeless
            // 
            this.lblHomeless.AutoSize = true;
            this.lblHomeless.BackColor = System.Drawing.Color.Transparent;
            this.lblHomeless.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHomeless.Location = new System.Drawing.Point(471, 105);
            this.lblHomeless.Name = "lblHomeless";
            this.lblHomeless.Size = new System.Drawing.Size(75, 17);
            this.lblHomeless.TabIndex = 110;
            this.lblHomeless.Text = "Homeless";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(528, 36);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 12);
            this.label7.TabIndex = 118;
            this.label7.Text = "Apt#";
            // 
            // chkInCityLimits
            // 
            this.chkInCityLimits.Location = new System.Drawing.Point(454, 85);
            this.chkInCityLimits.Margin = new System.Windows.Forms.Padding(4);
            this.chkInCityLimits.Name = "chkInCityLimits";
            this.chkInCityLimits.Size = new System.Drawing.Size(20, 18);
            this.chkInCityLimits.TabIndex = 12;
            this.chkInCityLimits.Tag = "InCityLimits";
            this.chkInCityLimits.Text = "In City Limits";
            this.chkInCityLimits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkInCityLimits.UseVisualStyleBackColor = true;
            this.chkInCityLimits.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkInCityLimits.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // chkInactive
            // 
            this.chkInactive.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkInactive.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkInactive.Location = new System.Drawing.Point(9, 89);
            this.chkInactive.Margin = new System.Windows.Forms.Padding(4);
            this.chkInactive.Name = "chkInactive";
            this.chkInactive.Size = new System.Drawing.Size(103, 21);
            this.chkInactive.TabIndex = 101;
            this.chkInactive.TabStop = false;
            this.chkInactive.Tag = "Inactive";
            this.chkInactive.Text = "InActive";
            this.chkInactive.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkInactive.UseVisualStyleBackColor = true;
            this.chkInactive.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkInactive.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // lblInCityLimits
            // 
            this.lblInCityLimits.AutoSize = true;
            this.lblInCityLimits.BackColor = System.Drawing.Color.Transparent;
            this.lblInCityLimits.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInCityLimits.Location = new System.Drawing.Point(471, 84);
            this.lblInCityLimits.Name = "lblInCityLimits";
            this.lblInCityLimits.Size = new System.Drawing.Size(100, 17);
            this.lblInCityLimits.TabIndex = 109;
            this.lblInCityLimits.Text = "In City Limits";
            // 
            // tabFamily
            // 
            this.tabFamily.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabFamily.Controls.Add(this.tpgFamilyDetail);
            this.tabFamily.Controls.Add(this.tpgFamilySummary);
            this.tabFamily.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFamily.HotTrack = true;
            this.tabFamily.ItemSize = new System.Drawing.Size(91, 18);
            this.tabFamily.Location = new System.Drawing.Point(2, 168);
            this.tabFamily.Name = "tabFamily";
            this.tabFamily.Padding = new System.Drawing.Point(10, 3);
            this.tabFamily.SelectedIndex = 0;
            this.tabFamily.Size = new System.Drawing.Size(604, 134);
            this.tabFamily.TabIndex = 114;
            // 
            // tpgFamilyDetail
            // 
            this.tpgFamilyDetail.Controls.Add(this.dgvHHMembers);
            this.tpgFamilyDetail.Location = new System.Drawing.Point(4, 22);
            this.tpgFamilyDetail.Name = "tpgFamilyDetail";
            this.tpgFamilyDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tpgFamilyDetail.Size = new System.Drawing.Size(596, 108);
            this.tpgFamilyDetail.TabIndex = 0;
            this.tpgFamilyDetail.Text = "Family Member List";
            this.tpgFamilyDetail.UseVisualStyleBackColor = true;
            // 
            // dgvHHMembers
            // 
            this.dgvHHMembers.AllowUserToAddRows = false;
            this.dgvHHMembers.AllowUserToDeleteRows = false;
            this.dgvHHMembers.AllowUserToResizeRows = false;
            this.dgvHHMembers.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgvHHMembers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle82.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle82.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle82.ForeColor = System.Drawing.Color.DarkBlue;
            dataGridViewCellStyle82.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle82.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle82.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHHMembers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle82;
            this.dgvHHMembers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHHMembers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmInactive,
            this.clmLastName,
            this.clmFirstName,
            this.clmBirthdate,
            this.clmAge,
            this.clmGroup,
            this.clmSex,
            this.clmCSFP,
            this.clmDiet,
            this.Disabled,
            this.clmHMID});
            this.dgvHHMembers.ContextMenuStrip = this.cmsHHMembers;
            this.dgvHHMembers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHHMembers.GridColor = System.Drawing.Color.Black;
            this.helpProvider1.SetHelpString(this.dgvHHMembers, "Use Family Mem Action Key to edit all properties");
            this.dgvHHMembers.Location = new System.Drawing.Point(3, 3);
            this.dgvHHMembers.MultiSelect = false;
            this.dgvHHMembers.Name = "dgvHHMembers";
            this.dgvHHMembers.RowHeadersVisible = false;
            this.dgvHHMembers.RowHeadersWidth = 5;
            this.dgvHHMembers.RowTemplate.Height = 24;
            this.dgvHHMembers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.helpProvider1.SetShowHelp(this.dgvHHMembers, true);
            this.dgvHHMembers.Size = new System.Drawing.Size(590, 102);
            this.dgvHHMembers.TabIndex = 52;
            this.dgvHHMembers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridMembers_CellContentClick);
            this.dgvHHMembers.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridMembers_CellEndEdit);
            this.dgvHHMembers.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridMembers_CellLeave);
            this.dgvHHMembers.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridMembers_RowEnter);
            // 
            // clmInactive
            // 
            this.clmInactive.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.clmInactive.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clmInactive.HeaderText = "Inactive";
            this.clmInactive.Name = "clmInactive";
            this.clmInactive.Width = 30;
            // 
            // clmDiet
            // 
            this.clmDiet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.clmDiet.HeaderText = "Diet";
            this.clmDiet.Name = "clmDiet";
            this.clmDiet.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clmDiet.Width = 35;
            // 
            // Disabled
            // 
            this.Disabled.HeaderText = "Disabled";
            this.Disabled.Name = "Disabled";
            this.Disabled.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Disabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Disabled.Width = 45;
            // 
            // cmsHHMembers
            // 
            this.cmsHHMembers.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.tsmiMoveHHMem});
            this.cmsHHMembers.Name = "cmsHHMembers";
            this.cmsHHMembers.Size = new System.Drawing.Size(174, 48);
            this.cmsHHMembers.Opening += new System.ComponentModel.CancelEventHandler(this.cmsHHMembers_Opening);
            this.cmsHHMembers.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmsHHMembers_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(173, 22);
            this.toolStripMenuItem1.Text = "Export To Excell";
            // 
            // tsmiMoveHHMem
            // 
            this.tsmiMoveHHMem.Name = "tsmiMoveHHMem";
            this.tsmiMoveHHMem.Size = new System.Drawing.Size(173, 22);
            this.tsmiMoveHHMem.Text = "Move HH Member";
            // 
            // tpgFamilySummary
            // 
            this.tpgFamilySummary.BackColor = System.Drawing.Color.Cornsilk;
            this.tpgFamilySummary.Controls.Add(this.tbmEighteens);
            this.tpgFamilySummary.Controls.Add(this.label1);
            this.tpgFamilySummary.Controls.Add(this.lblCSFP);
            this.tpgFamilySummary.Controls.Add(this.tbmInfants);
            this.tpgFamilySummary.Controls.Add(this.tbmCSFP);
            this.tpgFamilySummary.Controls.Add(this.label12);
            this.tpgFamilySummary.Controls.Add(this.label9);
            this.tpgFamilySummary.Controls.Add(this.tbmDisabled);
            this.tpgFamilySummary.Controls.Add(this.chkUseFamList);
            this.tpgFamilySummary.Controls.Add(this.tbmDiet);
            this.tpgFamilySummary.Controls.Add(this.label18);
            this.tpgFamilySummary.Controls.Add(this.tbmYouth);
            this.tpgFamilySummary.Controls.Add(this.label16);
            this.tpgFamilySummary.Controls.Add(this.label13);
            this.tpgFamilySummary.Controls.Add(this.tbTotalFam);
            this.tpgFamilySummary.Controls.Add(this.tbmTeens);
            this.tpgFamilySummary.Controls.Add(this.label17);
            this.tpgFamilySummary.Controls.Add(this.label15);
            this.tpgFamilySummary.Controls.Add(this.tbmSeniors);
            this.tpgFamilySummary.Controls.Add(this.tbmAdults);
            this.tpgFamilySummary.Controls.Add(this.label14);
            this.tpgFamilySummary.Location = new System.Drawing.Point(4, 22);
            this.tpgFamilySummary.Name = "tpgFamilySummary";
            this.tpgFamilySummary.Padding = new System.Windows.Forms.Padding(3);
            this.tpgFamilySummary.Size = new System.Drawing.Size(596, 108);
            this.tpgFamilySummary.TabIndex = 1;
            this.tpgFamilySummary.Text = "Family Groups";
            this.tpgFamilySummary.ToolTipText = "Family Demographics Groups";
            // 
            // tbmEighteens
            // 
            this.tbmEighteens.BackColor = System.Drawing.Color.White;
            this.tbmEighteens.Location = new System.Drawing.Point(152, 56);
            this.tbmEighteens.Margin = new System.Windows.Forms.Padding(4);
            this.tbmEighteens.Name = "tbmEighteens";
            this.tbmEighteens.Size = new System.Drawing.Size(40, 20);
            this.tbmEighteens.TabIndex = 16;
            this.tbmEighteens.Tag = "Eighteen";
            this.tbmEighteens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(149, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 107;
            this.label1.Text = "18";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCSFP
            // 
            this.lblCSFP.BackColor = System.Drawing.Color.Transparent;
            this.lblCSFP.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCSFP.Location = new System.Drawing.Point(532, 37);
            this.lblCSFP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCSFP.Name = "lblCSFP";
            this.lblCSFP.Size = new System.Drawing.Size(68, 17);
            this.lblCSFP.TabIndex = 105;
            this.lblCSFP.Tag = "";
            this.lblCSFP.Text = "# CSFP";
            this.lblCSFP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbmInfants
            // 
            this.tbmInfants.BackColor = System.Drawing.Color.White;
            this.tbmInfants.Location = new System.Drawing.Point(7, 56);
            this.tbmInfants.Margin = new System.Windows.Forms.Padding(4);
            this.tbmInfants.Name = "tbmInfants";
            this.tbmInfants.Size = new System.Drawing.Size(41, 20);
            this.tbmInfants.TabIndex = 13;
            this.tbmInfants.Tag = "Infants";
            this.tbmInfants.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmInfants.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // tbmCSFP
            // 
            this.tbmCSFP.BackColor = System.Drawing.Color.White;
            this.tbmCSFP.Location = new System.Drawing.Point(536, 56);
            this.tbmCSFP.Margin = new System.Windows.Forms.Padding(4);
            this.tbmCSFP.Name = "tbmCSFP";
            this.tbmCSFP.Size = new System.Drawing.Size(40, 20);
            this.tbmCSFP.TabIndex = 21;
            this.tbmCSFP.Tag = "NbrCSFP";
            this.tbmCSFP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmCSFP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 35);
            this.label12.Margin = new System.Windows.Forms.Padding(0, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 17);
            this.label12.TabIndex = 39;
            this.label12.Text = "Infants";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(461, 38);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 103;
            this.label9.Text = "# Disabled";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbmDisabled
            // 
            this.tbmDisabled.BackColor = System.Drawing.Color.White;
            this.tbmDisabled.Location = new System.Drawing.Point(471, 56);
            this.tbmDisabled.Margin = new System.Windows.Forms.Padding(0);
            this.tbmDisabled.Name = "tbmDisabled";
            this.tbmDisabled.Size = new System.Drawing.Size(41, 20);
            this.tbmDisabled.TabIndex = 20;
            this.tbmDisabled.Tag = "Disabled";
            this.tbmDisabled.Text = "99";
            this.tbmDisabled.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmDisabled.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // chkUseFamList
            // 
            this.chkUseFamList.AutoSize = true;
            this.chkUseFamList.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUseFamList.Location = new System.Drawing.Point(17, 11);
            this.chkUseFamList.Margin = new System.Windows.Forms.Padding(4);
            this.chkUseFamList.Name = "chkUseFamList";
            this.chkUseFamList.Size = new System.Drawing.Size(137, 18);
            this.chkUseFamList.TabIndex = 12;
            this.chkUseFamList.Tag = "UseFamilyList";
            this.chkUseFamList.Text = "Use Members List";
            this.chkUseFamList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkUseFamList.UseVisualStyleBackColor = true;
            this.chkUseFamList.CheckedChanged += new System.EventHandler(this.chkUseFamList_CheckedChanged);
            this.chkUseFamList.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkUseFamList.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // tbmDiet
            // 
            this.tbmDiet.BackColor = System.Drawing.Color.White;
            this.tbmDiet.ForeColor = System.Drawing.Color.Black;
            this.tbmDiet.Location = new System.Drawing.Point(405, 56);
            this.tbmDiet.Margin = new System.Windows.Forms.Padding(4);
            this.tbmDiet.Name = "tbmDiet";
            this.tbmDiet.Size = new System.Drawing.Size(35, 20);
            this.tbmDiet.TabIndex = 18;
            this.tbmDiet.Tag = "SpecialDiet";
            this.tbmDiet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmDiet.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(378, 39);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 13);
            this.label18.TabIndex = 51;
            this.label18.Text = "# Special Diet";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbmYouth
            // 
            this.tbmYouth.BackColor = System.Drawing.Color.White;
            this.tbmYouth.Location = new System.Drawing.Point(56, 56);
            this.tbmYouth.Margin = new System.Windows.Forms.Padding(4);
            this.tbmYouth.Name = "tbmYouth";
            this.tbmYouth.Size = new System.Drawing.Size(41, 20);
            this.tbmYouth.TabIndex = 14;
            this.tbmYouth.Tag = "Youth";
            this.tbmYouth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmYouth.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Cornsilk;
            this.label16.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(300, 34);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 20);
            this.label16.TabIndex = 49;
            this.label16.Text = "Total Family";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(60, 35);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 17);
            this.label13.TabIndex = 41;
            this.label13.Text = "Youth";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTotalFam
            // 
            this.tbTotalFam.BackColor = System.Drawing.Color.Cornsilk;
            this.tbTotalFam.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTotalFam.ForeColor = System.Drawing.Color.Blue;
            this.tbTotalFam.Location = new System.Drawing.Point(303, 56);
            this.tbTotalFam.Margin = new System.Windows.Forms.Padding(4);
            this.tbTotalFam.Name = "tbTotalFam";
            this.tbTotalFam.ReadOnly = true;
            this.tbTotalFam.Size = new System.Drawing.Size(41, 22);
            this.tbTotalFam.TabIndex = 18;
            this.tbTotalFam.TabStop = false;
            this.tbTotalFam.Tag = "TotalFamily";
            this.tbTotalFam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbmTeens
            // 
            this.tbmTeens.BackColor = System.Drawing.Color.White;
            this.tbmTeens.Location = new System.Drawing.Point(104, 56);
            this.tbmTeens.Margin = new System.Windows.Forms.Padding(4);
            this.tbmTeens.Name = "tbmTeens";
            this.tbmTeens.Size = new System.Drawing.Size(41, 20);
            this.tbmTeens.TabIndex = 15;
            this.tbmTeens.Tag = "Teens";
            this.tbmTeens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmTeens.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(251, 35);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 17);
            this.label17.TabIndex = 47;
            this.label17.Text = "Seniors";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(105, 35);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 17);
            this.label15.TabIndex = 43;
            this.label15.Text = "Teens";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbmSeniors
            // 
            this.tbmSeniors.BackColor = System.Drawing.Color.White;
            this.tbmSeniors.Location = new System.Drawing.Point(249, 56);
            this.tbmSeniors.Margin = new System.Windows.Forms.Padding(4);
            this.tbmSeniors.Name = "tbmSeniors";
            this.tbmSeniors.Size = new System.Drawing.Size(39, 20);
            this.tbmSeniors.TabIndex = 17;
            this.tbmSeniors.Tag = "Seniors";
            this.tbmSeniors.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmSeniors.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // tbmAdults
            // 
            this.tbmAdults.BackColor = System.Drawing.Color.White;
            this.tbmAdults.Location = new System.Drawing.Point(200, 56);
            this.tbmAdults.Margin = new System.Windows.Forms.Padding(4);
            this.tbmAdults.Name = "tbmAdults";
            this.tbmAdults.Size = new System.Drawing.Size(40, 20);
            this.tbmAdults.TabIndex = 16;
            this.tbmAdults.Tag = "Adults";
            this.tbmAdults.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbmAdults.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(197, 35);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 17);
            this.label14.TabIndex = 45;
            this.label14.Text = "Adults";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BackColor = System.Drawing.Color.Tan;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.pbxEditAlert);
            this.splitContainer4.Panel1.Controls.Add(this.tbAlert);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.tbeNotes);
            this.splitContainer4.Size = new System.Drawing.Size(289, 302);
            this.splitContainer4.SplitterDistance = 144;
            this.splitContainer4.TabIndex = 0;
            // 
            // pbxEditAlert
            // 
            this.pbxEditAlert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxEditAlert.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pbxEditAlert.Image = global::ClientcardFB3.Properties.Resources.edit;
            this.pbxEditAlert.Location = new System.Drawing.Point(271, 126);
            this.pbxEditAlert.Name = "pbxEditAlert";
            this.pbxEditAlert.Size = new System.Drawing.Size(16, 16);
            this.pbxEditAlert.TabIndex = 128;
            this.pbxEditAlert.TabStop = false;
            this.pbxEditAlert.Click += new System.EventHandler(this.pbxEditAlert_Click);
            // 
            // tbAlert
            // 
            this.tbAlert.BackColor = System.Drawing.Color.LightYellow;
            this.tbAlert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbAlert.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbAlert.Location = new System.Drawing.Point(0, 0);
            this.tbAlert.Name = "tbAlert";
            this.tbAlert.ReadOnly = true;
            this.tbAlert.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.tbAlert.Size = new System.Drawing.Size(289, 144);
            this.tbAlert.TabIndex = 115;
            this.tbAlert.TabStop = false;
            this.tbAlert.Text = "";
            // 
            // tbeNotes
            // 
            this.tbeNotes.AcceptsReturn = true;
            this.tbeNotes.AcceptsTab = true;
            this.tbeNotes.BackColor = System.Drawing.Color.Ivory;
            this.tbeNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbeNotes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbeNotes.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeNotes.Location = new System.Drawing.Point(0, 0);
            this.tbeNotes.Margin = new System.Windows.Forms.Padding(4);
            this.tbeNotes.Multiline = true;
            this.tbeNotes.Name = "tbeNotes";
            this.tbeNotes.Size = new System.Drawing.Size(289, 154);
            this.tbeNotes.TabIndex = 18;
            this.tbeNotes.Tag = "Comments";
            this.tbeNotes.Text = "123456789012345678901234567890123456789\r\nLine 2\r\nLine 3\r\nLine 4\r\nLine 5\r\nLine 6\r\n" +
    "Line 7\r\nLine 8\r\nLine 9\r\nLine 10";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbFindClient,
            this.tsbHHMem,
            this.tsbNewService,
            this.tsbDfltSvcDate,
            this.toolStripSeparator13,
            this.tsbAddClient,
            this.tsbLog});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(82, 302);
            this.toolStrip1.TabIndex = 75;
            this.toolStrip1.Text = "MainMenuControls";
            // 
            // tsbFindClient
            // 
            this.tsbFindClient.AutoSize = false;
            this.tsbFindClient.Image = ((System.Drawing.Image)(resources.GetObject("tsbFindClient.Image")));
            this.tsbFindClient.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbFindClient.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbFindClient.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFindClient.Margin = new System.Windows.Forms.Padding(0);
            this.tsbFindClient.Name = "tsbFindClient";
            this.tsbFindClient.Size = new System.Drawing.Size(80, 50);
            this.tsbFindClient.Tag = "FindClient";
            this.tsbFindClient.Text = "&Find Client";
            this.tsbFindClient.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbFindClient.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbFindClient.ToolTipText = "Find Client Household or Household Member";
            this.tsbFindClient.Click += new System.EventHandler(this.tsbFindClient_Click);
            // 
            // tsbHHMem
            // 
            this.tsbHHMem.AutoSize = false;
            this.tsbHHMem.Image = ((System.Drawing.Image)(resources.GetObject("tsbHHMem.Image")));
            this.tsbHHMem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbHHMem.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbHHMem.Name = "tsbHHMem";
            this.tsbHHMem.Size = new System.Drawing.Size(80, 50);
            this.tsbHHMem.Text = "Family &Mem";
            this.tsbHHMem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbHHMem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbHHMem.ToolTipText = "Maintain Household Members";
            this.tsbHHMem.Click += new System.EventHandler(this.tsbHHMem_Click);
            // 
            // tsbNewService
            // 
            this.tsbNewService.AutoSize = false;
            this.tsbNewService.Image = ((System.Drawing.Image)(resources.GetObject("tsbNewService.Image")));
            this.tsbNewService.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbNewService.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbNewService.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNewService.Margin = new System.Windows.Forms.Padding(0);
            this.tsbNewService.Name = "tsbNewService";
            this.tsbNewService.Size = new System.Drawing.Size(80, 50);
            this.tsbNewService.Tag = "NewService";
            this.tsbNewService.Text = "&New Srvc";
            this.tsbNewService.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbNewService.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbNewService.ToolTipText = "Create New Food Service for this household";
            this.tsbNewService.Click += new System.EventHandler(this.tsbNewService_Click);
            // 
            // tsbDfltSvcDate
            // 
            this.tsbDfltSvcDate.AutoSize = false;
            this.tsbDfltSvcDate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDfltSvcDate.Font = new System.Drawing.Font("Segoe UI", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbDfltSvcDate.Image = ((System.Drawing.Image)(resources.GetObject("tsbDfltSvcDate.Image")));
            this.tsbDfltSvcDate.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbDfltSvcDate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbDfltSvcDate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDfltSvcDate.Margin = new System.Windows.Forms.Padding(0);
            this.tsbDfltSvcDate.Name = "tsbDfltSvcDate";
            this.tsbDfltSvcDate.Size = new System.Drawing.Size(80, 20);
            this.tsbDfltSvcDate.Text = "01/22/2011";
            this.tsbDfltSvcDate.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.tsbDfltSvcDate.ToolTipText = "Click to Default New Service Date";
            this.tsbDfltSvcDate.Click += new System.EventHandler(this.tsbDfltSvcDate_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(80, 6);
            // 
            // tsbAddClient
            // 
            this.tsbAddClient.AutoSize = false;
            this.tsbAddClient.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbAddClient.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddClient.Image")));
            this.tsbAddClient.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbAddClient.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbAddClient.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddClient.Margin = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.tsbAddClient.Name = "tsbAddClient";
            this.tsbAddClient.Size = new System.Drawing.Size(80, 45);
            this.tsbAddClient.Tag = "AddClient";
            this.tsbAddClient.Text = "&Add Client";
            this.tsbAddClient.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbAddClient.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbAddClient.ToolTipText = "Add New Client Household";
            this.tsbAddClient.Click += new System.EventHandler(this.tsbAddClient_Click);
            // 
            // tsbLog
            // 
            this.tsbLog.Image = ((System.Drawing.Image)(resources.GetObject("tsbLog.Image")));
            this.tsbLog.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbLog.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbLog.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbLog.Name = "tsbLog";
            this.tsbLog.Size = new System.Drawing.Size(80, 49);
            this.tsbLog.Text = "&Log";
            this.tsbLog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbLog.ToolTipText = "Display Log Form";
            this.tsbLog.Click += new System.EventHandler(this.tsbLog_Click);
            // 
            // splitMemTrans
            // 
            this.splitMemTrans.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitMemTrans.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMemTrans.IsSplitterFixed = true;
            this.splitMemTrans.Location = new System.Drawing.Point(82, 0);
            this.splitMemTrans.Margin = new System.Windows.Forms.Padding(4);
            this.splitMemTrans.Name = "splitMemTrans";
            // 
            // splitMemTrans.Panel1
            // 
            this.splitMemTrans.Panel1.Controls.Add(this.tabCntrlMain);
            this.splitMemTrans.Panel1MinSize = 100;
            // 
            // splitMemTrans.Panel2
            // 
            this.splitMemTrans.Panel2.Controls.Add(this.splitContainer2);
            this.splitMemTrans.Size = new System.Drawing.Size(902, 330);
            this.splitMemTrans.SplitterDistance = 294;
            this.splitMemTrans.SplitterWidth = 5;
            this.splitMemTrans.TabIndex = 1;
            // 
            // tabCntrlMain
            // 
            this.tabCntrlMain.Controls.Add(this.tpgHHData);
            this.tabCntrlMain.Controls.Add(this.tpgUserFields);
            this.tabCntrlMain.Controls.Add(this.tpgIncome);
            this.tabCntrlMain.Controls.Add(this.tpgHD);
            this.tabCntrlMain.Controls.Add(this.tpgPointSys);
            this.tabCntrlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCntrlMain.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCntrlMain.Location = new System.Drawing.Point(0, 0);
            this.tabCntrlMain.Multiline = true;
            this.tabCntrlMain.Name = "tabCntrlMain";
            this.tabCntrlMain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabCntrlMain.SelectedIndex = 0;
            this.tabCntrlMain.Size = new System.Drawing.Size(292, 328);
            this.tabCntrlMain.TabIndex = 29;
            // 
            // tpgHHData
            // 
            this.tpgHHData.AutoScroll = true;
            this.tpgHHData.BackColor = System.Drawing.Color.Cornsilk;
            this.tpgHHData.Controls.Add(this.tbPhone);
            this.tpgHHData.Controls.Add(this.cboSpecialLang);
            this.tpgHHData.Controls.Add(this.cboHUDCategory);
            this.tpgHHData.Controls.Add(this.lblHUDCategory);
            this.tpgHHData.Controls.Add(this.label11);
            this.tpgHHData.Controls.Add(this.lblNeedCommodSignature);
            this.tpgHHData.Controls.Add(this.grpbxVerifyId);
            this.tpgHHData.Controls.Add(this.cboPhoneType);
            this.tpgHHData.Controls.Add(this.lblPhoneType);
            this.tpgHHData.Controls.Add(this.lblPhoneNum);
            this.tpgHHData.Controls.Add(this.chkNeedCommSig);
            this.tpgHHData.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpgHHData.Location = new System.Drawing.Point(4, 44);
            this.tpgHHData.Name = "tpgHHData";
            this.tpgHHData.Padding = new System.Windows.Forms.Padding(3);
            this.tpgHHData.Size = new System.Drawing.Size(284, 280);
            this.tpgHHData.TabIndex = 0;
            this.tpgHHData.Text = "ID/Phone";
            // 
            // tbPhone
            // 
            this.tbPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPhone.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPhone.HidePromptOnLeave = true;
            this.tbPhone.Location = new System.Drawing.Point(126, 149);
            this.tbPhone.Mask = "(999) 000-0000 aaaaaa";
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(150, 15);
            this.tbPhone.TabIndex = 24;
            this.tbPhone.Tag = "phone";
            this.tbPhone.Leave += new System.EventHandler(this.tbPhone_Leave);
            // 
            // cboSpecialLang
            // 
            this.cboSpecialLang.BackColor = System.Drawing.Color.White;
            this.cboSpecialLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSpecialLang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSpecialLang.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSpecialLang.FormattingEnabled = true;
            this.cboSpecialLang.Location = new System.Drawing.Point(126, 252);
            this.cboSpecialLang.Margin = new System.Windows.Forms.Padding(4);
            this.cboSpecialLang.Name = "cboSpecialLang";
            this.cboSpecialLang.Size = new System.Drawing.Size(119, 23);
            this.cboSpecialLang.TabIndex = 19;
            this.cboSpecialLang.Tag = "EthnicSpeaking";
            this.cboSpecialLang.SelectionChangeCommitted += new System.EventHandler(this.cboSpecialLang_SelectionChangeCommitted);
            // 
            // cboHUDCategory
            // 
            this.cboHUDCategory.BackColor = System.Drawing.Color.White;
            this.cboHUDCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHUDCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboHUDCategory.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHUDCategory.FormattingEnabled = true;
            this.cboHUDCategory.Items.AddRange(new object[] {
            "Very Low",
            "Low",
            "Moderate",
            "Above Moderate"});
            this.cboHUDCategory.Location = new System.Drawing.Point(126, 212);
            this.cboHUDCategory.Margin = new System.Windows.Forms.Padding(4);
            this.cboHUDCategory.Name = "cboHUDCategory";
            this.cboHUDCategory.Size = new System.Drawing.Size(150, 23);
            this.cboHUDCategory.TabIndex = 26;
            this.cboHUDCategory.Tag = "HUDCategory";
            this.cboHUDCategory.Visible = false;
            this.cboHUDCategory.SelectedIndexChanged += new System.EventHandler(this.cboHUDCategory_SelectionChangeCommitted);
            // 
            // lblHUDCategory
            // 
            this.lblHUDCategory.BackColor = System.Drawing.Color.Transparent;
            this.lblHUDCategory.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHUDCategory.Location = new System.Drawing.Point(8, 212);
            this.lblHUDCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHUDCategory.Name = "lblHUDCategory";
            this.lblHUDCategory.Size = new System.Drawing.Size(116, 20);
            this.lblHUDCategory.TabIndex = 120;
            this.lblHUDCategory.Text = "HUD Category:";
            this.lblHUDCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHUDCategory.Visible = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 252);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 21);
            this.label11.TabIndex = 36;
            this.label11.Text = "Language:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNeedCommodSignature
            // 
            this.lblNeedCommodSignature.AutoSize = true;
            this.lblNeedCommodSignature.BackColor = System.Drawing.Color.Transparent;
            this.lblNeedCommodSignature.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNeedCommodSignature.Location = new System.Drawing.Point(37, 10);
            this.lblNeedCommodSignature.Name = "lblNeedCommodSignature";
            this.lblNeedCommodSignature.Size = new System.Drawing.Size(201, 17);
            this.lblNeedCommodSignature.TabIndex = 113;
            this.lblNeedCommodSignature.Text = "Need Commodity Signature";
            // 
            // grpbxVerifyId
            // 
            this.grpbxVerifyId.Controls.Add(this.lblNeedToVerifyId);
            this.grpbxVerifyId.Controls.Add(this.chkNeedVerifyID);
            this.grpbxVerifyId.Controls.Add(this.cboIDType);
            this.grpbxVerifyId.Controls.Add(this.label21);
            this.grpbxVerifyId.Controls.Add(this.label22);
            this.grpbxVerifyId.Controls.Add(this.tbeDateIDVerified);
            this.grpbxVerifyId.Location = new System.Drawing.Point(3, 27);
            this.grpbxVerifyId.Name = "grpbxVerifyId";
            this.grpbxVerifyId.Size = new System.Drawing.Size(278, 107);
            this.grpbxVerifyId.TabIndex = 19;
            this.grpbxVerifyId.TabStop = false;
            // 
            // lblNeedToVerifyId
            // 
            this.lblNeedToVerifyId.AutoSize = true;
            this.lblNeedToVerifyId.BackColor = System.Drawing.Color.Transparent;
            this.lblNeedToVerifyId.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNeedToVerifyId.Location = new System.Drawing.Point(34, 16);
            this.lblNeedToVerifyId.Name = "lblNeedToVerifyId";
            this.lblNeedToVerifyId.Size = new System.Drawing.Size(167, 17);
            this.lblNeedToVerifyId.TabIndex = 113;
            this.lblNeedToVerifyId.Text = "Need Proof of Address";
            // 
            // chkNeedVerifyID
            // 
            this.chkNeedVerifyID.Location = new System.Drawing.Point(16, 16);
            this.chkNeedVerifyID.Margin = new System.Windows.Forms.Padding(4);
            this.chkNeedVerifyID.Name = "chkNeedVerifyID";
            this.chkNeedVerifyID.Size = new System.Drawing.Size(20, 18);
            this.chkNeedVerifyID.TabIndex = 21;
            this.chkNeedVerifyID.Tag = "NeedToVerifyID";
            this.chkNeedVerifyID.Text = "Need To Verify ID";
            this.chkNeedVerifyID.UseVisualStyleBackColor = true;
            this.chkNeedVerifyID.CheckedChanged += new System.EventHandler(this.chkVerifyID_CheckedChanged);
            this.chkNeedVerifyID.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkNeedVerifyID.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // cboIDType
            // 
            this.cboIDType.BackColor = System.Drawing.Color.White;
            this.cboIDType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIDType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboIDType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboIDType.FormattingEnabled = true;
            this.cboIDType.Location = new System.Drawing.Point(125, 42);
            this.cboIDType.Margin = new System.Windows.Forms.Padding(4);
            this.cboIDType.Name = "cboIDType";
            this.cboIDType.Size = new System.Drawing.Size(148, 22);
            this.cboIDType.TabIndex = 22;
            this.cboIDType.Tag = "IdType";
            this.cboIDType.SelectionChangeCommitted += new System.EventHandler(this.cboIDType_SelectionChangeCommitted);
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(8, 47);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 17);
            this.label21.TabIndex = 87;
            this.label21.Text = "Verify Method:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(8, 74);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 17);
            this.label22.TabIndex = 86;
            this.label22.Text = "Date Verified:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbeDateIDVerified
            // 
            this.tbeDateIDVerified.BackColor = System.Drawing.Color.White;
            this.tbeDateIDVerified.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbeDateIDVerified.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeDateIDVerified.Location = new System.Drawing.Point(125, 75);
            this.tbeDateIDVerified.Margin = new System.Windows.Forms.Padding(4);
            this.tbeDateIDVerified.Name = "tbeDateIDVerified";
            this.tbeDateIDVerified.Size = new System.Drawing.Size(104, 21);
            this.tbeDateIDVerified.TabIndex = 23;
            this.tbeDateIDVerified.TabStop = false;
            this.tbeDateIDVerified.Tag = "DateIDVerified";
            this.tbeDateIDVerified.Text = "12/29/2000";
            this.tbeDateIDVerified.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbeDateIDVerified.WordWrap = false;
            // 
            // cboPhoneType
            // 
            this.cboPhoneType.BackColor = System.Drawing.Color.White;
            this.cboPhoneType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhoneType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPhoneType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPhoneType.FormattingEnabled = true;
            this.cboPhoneType.Location = new System.Drawing.Point(126, 173);
            this.cboPhoneType.Margin = new System.Windows.Forms.Padding(4);
            this.cboPhoneType.Name = "cboPhoneType";
            this.cboPhoneType.Size = new System.Drawing.Size(151, 22);
            this.cboPhoneType.TabIndex = 25;
            this.cboPhoneType.Tag = "PhoneType";
            this.cboPhoneType.SelectionChangeCommitted += new System.EventHandler(this.cboPhoneType_SelectionChangeCommitted);
            // 
            // lblPhoneType
            // 
            this.lblPhoneType.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneType.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneType.Location = new System.Drawing.Point(7, 176);
            this.lblPhoneType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneType.Name = "lblPhoneType";
            this.lblPhoneType.Size = new System.Drawing.Size(116, 18);
            this.lblPhoneType.TabIndex = 78;
            this.lblPhoneType.Text = "Phone Type:";
            this.lblPhoneType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneNum.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNum.Location = new System.Drawing.Point(7, 147);
            this.lblPhoneNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(116, 18);
            this.lblPhoneNum.TabIndex = 33;
            this.lblPhoneNum.Text = "Phone Num:";
            this.lblPhoneNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chkNeedCommSig
            // 
            this.chkNeedCommSig.Location = new System.Drawing.Point(19, 9);
            this.chkNeedCommSig.Margin = new System.Windows.Forms.Padding(4);
            this.chkNeedCommSig.Name = "chkNeedCommSig";
            this.chkNeedCommSig.Size = new System.Drawing.Size(20, 18);
            this.chkNeedCommSig.TabIndex = 20;
            this.chkNeedCommSig.Tag = "NeedCommoditySignature";
            this.chkNeedCommSig.UseVisualStyleBackColor = true;
            this.chkNeedCommSig.CheckedChanged += new System.EventHandler(this.chkNeedCommSig_CheckedChanged);
            this.chkNeedCommSig.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkNeedCommSig.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // tpgUserFields
            // 
            this.tpgUserFields.BackColor = System.Drawing.Color.Cornsilk;
            this.tpgUserFields.Controls.Add(this.tbUserNum0);
            this.tpgUserFields.Controls.Add(this.tbUserNum1);
            this.tpgUserFields.Controls.Add(this.lblUserNum0);
            this.tpgUserFields.Controls.Add(this.lblUserNum1);
            this.tpgUserFields.Controls.Add(this.chkLstBxUserFields);
            this.tpgUserFields.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpgUserFields.Location = new System.Drawing.Point(4, 44);
            this.tpgUserFields.Name = "tpgUserFields";
            this.tpgUserFields.Padding = new System.Windows.Forms.Padding(3, 10, 3, 20);
            this.tpgUserFields.Size = new System.Drawing.Size(284, 280);
            this.tpgUserFields.TabIndex = 1;
            this.tpgUserFields.Text = "User Fields";
            // 
            // tbUserNum0
            // 
            this.tbUserNum0.BackColor = System.Drawing.Color.White;
            this.tbUserNum0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbUserNum0.Location = new System.Drawing.Point(42, 226);
            this.tbUserNum0.Margin = new System.Windows.Forms.Padding(4);
            this.tbUserNum0.Name = "tbUserNum0";
            this.tbUserNum0.Size = new System.Drawing.Size(246, 21);
            this.tbUserNum0.TabIndex = 40;
            this.tbUserNum0.Tag = "UserNum0";
            this.tbUserNum0.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // tbUserNum1
            // 
            this.tbUserNum1.BackColor = System.Drawing.Color.White;
            this.tbUserNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbUserNum1.Location = new System.Drawing.Point(43, 267);
            this.tbUserNum1.Margin = new System.Windows.Forms.Padding(4);
            this.tbUserNum1.Name = "tbUserNum1";
            this.tbUserNum1.Size = new System.Drawing.Size(245, 21);
            this.tbUserNum1.TabIndex = 42;
            this.tbUserNum1.Tag = "UserNum1";
            this.tbUserNum1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // lblUserNum0
            // 
            this.lblUserNum0.AutoSize = true;
            this.lblUserNum0.Location = new System.Drawing.Point(5, 209);
            this.lblUserNum0.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserNum0.Name = "lblUserNum0";
            this.lblUserNum0.Size = new System.Drawing.Size(132, 13);
            this.lblUserNum0.TabIndex = 39;
            this.lblUserNum0.Text = "Number of Food Stamps";
            this.lblUserNum0.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblUserNum1
            // 
            this.lblUserNum1.AutoSize = true;
            this.lblUserNum1.Location = new System.Drawing.Point(7, 253);
            this.lblUserNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserNum1.Name = "lblUserNum1";
            this.lblUserNum1.Size = new System.Drawing.Size(120, 13);
            this.lblUserNum1.TabIndex = 41;
            this.lblUserNum1.Text = "Total Assistance Given";
            this.lblUserNum1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // chkLstBxUserFields
            // 
            this.chkLstBxUserFields.BackColor = System.Drawing.Color.Cornsilk;
            this.chkLstBxUserFields.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chkLstBxUserFields.CheckOnClick = true;
            this.chkLstBxUserFields.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLstBxUserFields.FormattingEnabled = true;
            this.chkLstBxUserFields.HorizontalScrollbar = true;
            this.chkLstBxUserFields.Items.AddRange(new object[] {
            "UserFlag0",
            "UserFlag1",
            "UserFlag2",
            "UserFlag3",
            "UserFlag4",
            "UserFlag5",
            "UserFlag6",
            "UserFlag7",
            "UserFlag8",
            "UserFlag9"});
            this.chkLstBxUserFields.Location = new System.Drawing.Point(3, 3);
            this.chkLstBxUserFields.Margin = new System.Windows.Forms.Padding(4);
            this.chkLstBxUserFields.Name = "chkLstBxUserFields";
            this.chkLstBxUserFields.Size = new System.Drawing.Size(288, 198);
            this.chkLstBxUserFields.TabIndex = 38;
            this.chkLstBxUserFields.Tag = "UserFlags";
            this.chkLstBxUserFields.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chkLstBxUserFields_ItemCheck);
            // 
            // tpgIncome
            // 
            this.tpgIncome.BackColor = System.Drawing.Color.Cornsilk;
            this.tpgIncome.Controls.Add(this.grpbxIncome);
            this.tpgIncome.Location = new System.Drawing.Point(4, 44);
            this.tpgIncome.Name = "tpgIncome";
            this.tpgIncome.Size = new System.Drawing.Size(284, 280);
            this.tpgIncome.TabIndex = 2;
            this.tpgIncome.Text = "Income";
            // 
            // grpbxIncome
            // 
            this.grpbxIncome.Controls.Add(this.tbAnualIncome);
            this.grpbxIncome.Controls.Add(this.label24);
            this.grpbxIncome.Controls.Add(this.label10);
            this.grpbxIncome.Controls.Add(this.chkNeedIncomeVerification);
            this.grpbxIncome.Controls.Add(this.lvIncomeGroups);
            this.grpbxIncome.Controls.Add(this.tbIncomeMonthly);
            this.grpbxIncome.Controls.Add(this.label26);
            this.grpbxIncome.Location = new System.Drawing.Point(3, 3);
            this.grpbxIncome.Name = "grpbxIncome";
            this.grpbxIncome.Size = new System.Drawing.Size(285, 233);
            this.grpbxIncome.TabIndex = 89;
            this.grpbxIncome.TabStop = false;
            // 
            // tbAnualIncome
            // 
            this.tbAnualIncome.BackColor = System.Drawing.Color.White;
            this.tbAnualIncome.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAnualIncome.Location = new System.Drawing.Point(120, 69);
            this.tbAnualIncome.Name = "tbAnualIncome";
            this.tbAnualIncome.Size = new System.Drawing.Size(70, 23);
            this.tbAnualIncome.TabIndex = 48;
            this.tbAnualIncome.Tag = "AnnualIncome";
            this.tbAnualIncome.Text = "99999";
            this.tbAnualIncome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbAnualIncome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Location = new System.Drawing.Point(134, 51);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 15);
            this.label24.TabIndex = 47;
            this.label24.Text = "Annual";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(32, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(163, 14);
            this.label10.TabIndex = 44;
            this.label10.Text = "Need Income Verification";
            // 
            // chkNeedIncomeVerification
            // 
            this.chkNeedIncomeVerification.Location = new System.Drawing.Point(11, 24);
            this.chkNeedIncomeVerification.Margin = new System.Windows.Forms.Padding(4);
            this.chkNeedIncomeVerification.Name = "chkNeedIncomeVerification";
            this.chkNeedIncomeVerification.Size = new System.Drawing.Size(20, 18);
            this.chkNeedIncomeVerification.TabIndex = 43;
            this.chkNeedIncomeVerification.Tag = "NeedIncomeVerification";
            this.chkNeedIncomeVerification.UseVisualStyleBackColor = true;
            this.chkNeedIncomeVerification.CheckedChanged += new System.EventHandler(this.chkNeedIncomeVerification_CheckedChanged);
            this.chkNeedIncomeVerification.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkNeedIncomeVerification.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // lvIncomeGroups
            // 
            this.lvIncomeGroups.BackColor = System.Drawing.Color.LightYellow;
            this.lvIncomeGroups.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvIncomeGroups.CausesValidation = false;
            this.lvIncomeGroups.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colIncomeGrpId,
            this.colIncomeGrpName,
            this.colIncomeCat});
            this.lvIncomeGroups.Cursor = System.Windows.Forms.Cursors.No;
            this.lvIncomeGroups.ForeColor = System.Drawing.Color.MediumBlue;
            this.lvIncomeGroups.FullRowSelect = true;
            this.lvIncomeGroups.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvIncomeGroups.LabelWrap = false;
            this.lvIncomeGroups.Location = new System.Drawing.Point(1, 108);
            this.lvIncomeGroups.MultiSelect = false;
            this.lvIncomeGroups.Name = "lvIncomeGroups";
            this.lvIncomeGroups.ShowGroups = false;
            this.lvIncomeGroups.Size = new System.Drawing.Size(278, 110);
            this.lvIncomeGroups.TabIndex = 83;
            this.lvIncomeGroups.TabStop = false;
            this.lvIncomeGroups.UseCompatibleStateImageBehavior = false;
            this.lvIncomeGroups.View = System.Windows.Forms.View.Details;
            // 
            // colIncomeGrpId
            // 
            this.colIncomeGrpId.Text = "Group Id";
            this.colIncomeGrpId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colIncomeGrpId.Width = 0;
            // 
            // colIncomeGrpName
            // 
            this.colIncomeGrpName.Text = "Income Program";
            this.colIncomeGrpName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colIncomeGrpName.Width = 170;
            // 
            // colIncomeCat
            // 
            this.colIncomeCat.Text = "Category";
            this.colIncomeCat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colIncomeCat.Width = 100;
            // 
            // tbIncomeMonthly
            // 
            this.tbIncomeMonthly.BackColor = System.Drawing.Color.White;
            this.tbIncomeMonthly.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIncomeMonthly.Location = new System.Drawing.Point(23, 69);
            this.tbIncomeMonthly.Name = "tbIncomeMonthly";
            this.tbIncomeMonthly.Size = new System.Drawing.Size(70, 23);
            this.tbIncomeMonthly.TabIndex = 46;
            this.tbIncomeMonthly.Tag = "";
            this.tbIncomeMonthly.Text = "99999";
            this.tbIncomeMonthly.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbIncomeMonthly.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInteger_KeyDown);
            this.tbIncomeMonthly.Leave += new System.EventHandler(this.tbMonthlyIncome_Leave);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Location = new System.Drawing.Point(31, 51);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 15);
            this.label26.TabIndex = 45;
            this.label26.Text = "Monthly";
            // 
            // tpgHD
            // 
            this.tpgHD.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.tpgHD.Controls.Add(this.splitContainer1);
            this.tpgHD.Location = new System.Drawing.Point(4, 44);
            this.tpgHD.Name = "tpgHD";
            this.tpgHD.Size = new System.Drawing.Size(284, 280);
            this.tpgHD.TabIndex = 3;
            this.tpgHD.Text = "Home Delivery";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblDriverNotes);
            this.splitContainer1.Panel1.Controls.Add(this.cboHDPrograms);
            this.splitContainer1.Panel1.Controls.Add(this.cboHDBuilding);
            this.splitContainer1.Panel1.Controls.Add(this.lblHDPrograms);
            this.splitContainer1.Panel1.Controls.Add(this.lblHDBuildings);
            this.splitContainer1.Panel1.Controls.Add(this.cboHDRoute);
            this.splitContainer1.Panel1.Controls.Add(this.lblHDRoute);
            this.splitContainer1.Panel1.Controls.Add(this.cboHDItem);
            this.splitContainer1.Panel1.Controls.Add(this.lblHDItem);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tbDriverNotes);
            this.splitContainer1.Size = new System.Drawing.Size(284, 300);
            this.splitContainer1.SplitterDistance = 135;
            this.splitContainer1.TabIndex = 131;
            // 
            // lblDriverNotes
            // 
            this.lblDriverNotes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDriverNotes.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDriverNotes.Location = new System.Drawing.Point(4, 114);
            this.lblDriverNotes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDriverNotes.Name = "lblDriverNotes";
            this.lblDriverNotes.Size = new System.Drawing.Size(116, 17);
            this.lblDriverNotes.TabIndex = 130;
            this.lblDriverNotes.Tag = "";
            this.lblDriverNotes.Text = "Driver Notes:";
            this.lblDriverNotes.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblDriverNotes.Visible = false;
            // 
            // cboHDPrograms
            // 
            this.cboHDPrograms.BackColor = System.Drawing.Color.White;
            this.cboHDPrograms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHDPrograms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboHDPrograms.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHDPrograms.FormattingEnabled = true;
            this.cboHDPrograms.Location = new System.Drawing.Point(113, 34);
            this.cboHDPrograms.Margin = new System.Windows.Forms.Padding(4);
            this.cboHDPrograms.Name = "cboHDPrograms";
            this.cboHDPrograms.Size = new System.Drawing.Size(155, 22);
            this.cboHDPrograms.TabIndex = 122;
            this.cboHDPrograms.Tag = "HDProgram";
            this.cboHDPrograms.Visible = false;
            this.cboHDPrograms.SelectionChangeCommitted += new System.EventHandler(this.cboHD_SelectionChangeCommitted);
            // 
            // cboHDBuilding
            // 
            this.cboHDBuilding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHDBuilding.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboHDBuilding.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHDBuilding.FormattingEnabled = true;
            this.cboHDBuilding.Location = new System.Drawing.Point(113, 61);
            this.cboHDBuilding.Name = "cboHDBuilding";
            this.cboHDBuilding.Size = new System.Drawing.Size(155, 22);
            this.cboHDBuilding.TabIndex = 123;
            this.cboHDBuilding.Tag = "HDBuilding";
            this.cboHDBuilding.Visible = false;
            this.cboHDBuilding.SelectionChangeCommitted += new System.EventHandler(this.cboHD_SelectionChangeCommitted);
            // 
            // lblHDPrograms
            // 
            this.lblHDPrograms.BackColor = System.Drawing.Color.Transparent;
            this.lblHDPrograms.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHDPrograms.Location = new System.Drawing.Point(0, 34);
            this.lblHDPrograms.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHDPrograms.Name = "lblHDPrograms";
            this.lblHDPrograms.Size = new System.Drawing.Size(110, 19);
            this.lblHDPrograms.TabIndex = 125;
            this.lblHDPrograms.Text = "Funding Program:";
            this.lblHDPrograms.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHDPrograms.Visible = false;
            // 
            // lblHDBuildings
            // 
            this.lblHDBuildings.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHDBuildings.Location = new System.Drawing.Point(0, 61);
            this.lblHDBuildings.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHDBuildings.Name = "lblHDBuildings";
            this.lblHDBuildings.Size = new System.Drawing.Size(110, 22);
            this.lblHDBuildings.TabIndex = 126;
            this.lblHDBuildings.Tag = "";
            this.lblHDBuildings.Text = "Building Name:";
            this.lblHDBuildings.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHDBuildings.Visible = false;
            // 
            // cboHDRoute
            // 
            this.cboHDRoute.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHDRoute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboHDRoute.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHDRoute.FormattingEnabled = true;
            this.cboHDRoute.Location = new System.Drawing.Point(113, 7);
            this.cboHDRoute.Name = "cboHDRoute";
            this.cboHDRoute.Size = new System.Drawing.Size(155, 22);
            this.cboHDRoute.TabIndex = 121;
            this.cboHDRoute.Tag = "HDRoute";
            this.cboHDRoute.SelectionChangeCommitted += new System.EventHandler(this.cboHD_SelectionChangeCommitted);
            // 
            // lblHDRoute
            // 
            this.lblHDRoute.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHDRoute.Location = new System.Drawing.Point(0, 9);
            this.lblHDRoute.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHDRoute.Name = "lblHDRoute";
            this.lblHDRoute.Size = new System.Drawing.Size(110, 17);
            this.lblHDRoute.TabIndex = 124;
            this.lblHDRoute.Tag = "Route";
            this.lblHDRoute.Text = "Delivery Route:";
            this.lblHDRoute.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboHDItem
            // 
            this.cboHDItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHDItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboHDItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHDItem.FormattingEnabled = true;
            this.cboHDItem.Location = new System.Drawing.Point(113, 89);
            this.cboHDItem.Name = "cboHDItem";
            this.cboHDItem.Size = new System.Drawing.Size(155, 22);
            this.cboHDItem.TabIndex = 124;
            this.cboHDItem.Tag = "HDItem";
            this.cboHDItem.SelectionChangeCommitted += new System.EventHandler(this.cboHD_SelectionChangeCommitted);
            // 
            // lblHDItem
            // 
            this.lblHDItem.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHDItem.Location = new System.Drawing.Point(0, 89);
            this.lblHDItem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHDItem.Name = "lblHDItem";
            this.lblHDItem.Size = new System.Drawing.Size(110, 22);
            this.lblHDItem.TabIndex = 128;
            this.lblHDItem.Tag = "";
            this.lblHDItem.Text = "Svc Item:";
            this.lblHDItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbDriverNotes
            // 
            this.tbDriverNotes.AcceptsReturn = true;
            this.tbDriverNotes.AcceptsTab = true;
            this.tbDriverNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbDriverNotes.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDriverNotes.Location = new System.Drawing.Point(0, 0);
            this.tbDriverNotes.Margin = new System.Windows.Forms.Padding(4);
            this.tbDriverNotes.Multiline = true;
            this.tbDriverNotes.Name = "tbDriverNotes";
            this.tbDriverNotes.Size = new System.Drawing.Size(284, 83);
            this.tbDriverNotes.TabIndex = 125;
            this.tbDriverNotes.Tag = "DriverNotes";
            this.tbDriverNotes.Text = "123456789012345678901234567890123456789\r\nLine 2\r\nLine 3\r\nLine 4\r\nLine 5\r\nLine 6\r\n" +
    "Line 7\r\nLine 8\r\nLine 9\r\nLine 10";
            // 
            // tpgPointSys
            // 
            this.tpgPointSys.BackColor = System.Drawing.Color.LightGreen;
            this.tpgPointSys.Controls.Add(this.tbpPoints);
            this.tpgPointSys.Controls.Add(this.lblPoints);
            this.tpgPointSys.Controls.Add(this.lvwPoints);
            this.tpgPointSys.Location = new System.Drawing.Point(4, 44);
            this.tpgPointSys.Name = "tpgPointSys";
            this.tpgPointSys.Size = new System.Drawing.Size(284, 280);
            this.tpgPointSys.TabIndex = 4;
            this.tpgPointSys.Text = "Points";
            // 
            // tbpPoints
            // 
            this.tbpPoints.Location = new System.Drawing.Point(180, 213);
            this.tbpPoints.Name = "tbpPoints";
            this.tbpPoints.Size = new System.Drawing.Size(68, 23);
            this.tbpPoints.TabIndex = 3;
            this.tbpPoints.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbpPoints_KeyPress);
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoints.Location = new System.Drawing.Point(8, 216);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(159, 14);
            this.lblPoints.TabIndex = 2;
            this.lblPoints.Text = "Points for Thursday";
            // 
            // lvwPoints
            // 
            this.lvwPoints.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmlblWkOf,
            this.clmWkOf});
            this.lvwPoints.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvwPoints.GridLines = true;
            this.lvwPoints.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwPoints.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem41,
            listViewItem42,
            listViewItem43,
            listViewItem44,
            listViewItem45,
            listViewItem46,
            listViewItem47,
            listViewItem48});
            this.lvwPoints.Location = new System.Drawing.Point(0, 0);
            this.lvwPoints.Name = "lvwPoints";
            this.lvwPoints.Size = new System.Drawing.Size(248, 204);
            this.lvwPoints.TabIndex = 1;
            this.lvwPoints.UseCompatibleStateImageBehavior = false;
            this.lvwPoints.View = System.Windows.Forms.View.Details;
            // 
            // clmlblWkOf
            // 
            this.clmlblWkOf.Text = "Week Of";
            this.clmlblWkOf.Width = 100;
            // 
            // clmWkOf
            // 
            this.clmWkOf.Text = "06/18/2012";
            this.clmWkOf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmWkOf.Width = 100;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.Cornsilk;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.AutoScroll = true;
            this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer2.Panel1.Controls.Add(this.lblHHModified);
            this.splitContainer2.Panel1.Controls.Add(this.lblHHCreated);
            this.splitContainer2.Panel1.Controls.Add(this.chkShowOnLog);
            this.splitContainer2.Panel1.Controls.Add(this.tbBabySvcDescr);
            this.splitContainer2.Panel1.Controls.Add(this.chkBabyServices);
            this.splitContainer2.Panel1.Controls.Add(this.lblBabyServices);
            this.splitContainer2.Panel1.SizeChanged += new System.EventHandler(this.splitContainer2_Panel1_SizeChanged);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.ContextMenuStrip = this.cmsLog;
            this.splitContainer2.Panel2.Controls.Add(this.tabCntrlLog);
            this.splitContainer2.Size = new System.Drawing.Size(601, 328);
            this.splitContainer2.SplitterDistance = 92;
            this.splitContainer2.SplitterWidth = 1;
            this.splitContainer2.TabIndex = 10;
            this.splitContainer2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Ivory;
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.tbNbrSupplThisMonth);
            this.groupBox1.Controls.Add(this.lblNbrTEFAP);
            this.groupBox1.Controls.Add(this.tbNbrTEFAPThisMonth);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.tbeFirstService);
            this.groupBox1.Controls.Add(this.tbNbrTrxThisWeek);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.lblLastComm);
            this.groupBox1.Controls.Add(this.tbNbrTrxThisMonth);
            this.groupBox1.Controls.Add(this.tbLastService);
            this.groupBox1.Controls.Add(this.tbLastComodity);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.tbDaysSinceLstSrvc);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 89);
            this.groupBox1.TabIndex = 108;
            this.groupBox1.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.DarkBlue;
            this.label30.Location = new System.Drawing.Point(256, 68);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 14);
            this.label30.TabIndex = 113;
            this.label30.Text = "Supplemental - Month";
            // 
            // tbNbrSupplThisMonth
            // 
            this.tbNbrSupplThisMonth.BackColor = System.Drawing.Color.Ivory;
            this.tbNbrSupplThisMonth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNbrSupplThisMonth.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNbrSupplThisMonth.ForeColor = System.Drawing.Color.Blue;
            this.tbNbrSupplThisMonth.Location = new System.Drawing.Point(213, 70);
            this.tbNbrSupplThisMonth.Name = "tbNbrSupplThisMonth";
            this.tbNbrSupplThisMonth.ReadOnly = true;
            this.tbNbrSupplThisMonth.Size = new System.Drawing.Size(36, 14);
            this.tbNbrSupplThisMonth.TabIndex = 112;
            this.tbNbrSupplThisMonth.TabStop = false;
            this.tbNbrSupplThisMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblNbrTEFAP
            // 
            this.lblNbrTEFAP.AutoSize = true;
            this.lblNbrTEFAP.BackColor = System.Drawing.Color.Transparent;
            this.lblNbrTEFAP.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbrTEFAP.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblNbrTEFAP.Location = new System.Drawing.Point(256, 48);
            this.lblNbrTEFAP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNbrTEFAP.Name = "lblNbrTEFAP";
            this.lblNbrTEFAP.Size = new System.Drawing.Size(93, 14);
            this.lblNbrTEFAP.TabIndex = 111;
            this.lblNbrTEFAP.Text = "TEFAP This Month";
            // 
            // tbNbrTEFAPThisMonth
            // 
            this.tbNbrTEFAPThisMonth.BackColor = System.Drawing.Color.Ivory;
            this.tbNbrTEFAPThisMonth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNbrTEFAPThisMonth.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNbrTEFAPThisMonth.ForeColor = System.Drawing.Color.Blue;
            this.tbNbrTEFAPThisMonth.Location = new System.Drawing.Point(213, 50);
            this.tbNbrTEFAPThisMonth.Name = "tbNbrTEFAPThisMonth";
            this.tbNbrTEFAPThisMonth.ReadOnly = true;
            this.tbNbrTEFAPThisMonth.Size = new System.Drawing.Size(36, 14);
            this.tbNbrTEFAPThisMonth.TabIndex = 110;
            this.tbNbrTEFAPThisMonth.TabStop = false;
            this.tbNbrTEFAPThisMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkBlue;
            this.label19.Location = new System.Drawing.Point(102, 65);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(86, 18);
            this.label19.TabIndex = 80;
            this.label19.Text = "First Service";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.DarkBlue;
            this.label25.Location = new System.Drawing.Point(256, 29);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 14);
            this.label25.TabIndex = 109;
            this.label25.Text = "Services This Week";
            // 
            // tbeFirstService
            // 
            this.tbeFirstService.BackColor = System.Drawing.Color.Ivory;
            this.tbeFirstService.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbeFirstService.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbeFirstService.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbeFirstService.Location = new System.Drawing.Point(3, 67);
            this.tbeFirstService.Margin = new System.Windows.Forms.Padding(4);
            this.tbeFirstService.Name = "tbeFirstService";
            this.tbeFirstService.Size = new System.Drawing.Size(90, 12);
            this.tbeFirstService.TabIndex = 102;
            this.tbeFirstService.Tag = "FirstService";
            this.tbeFirstService.Text = "12/24/2022";
            this.tbeFirstService.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbNbrTrxThisWeek
            // 
            this.tbNbrTrxThisWeek.BackColor = System.Drawing.Color.Ivory;
            this.tbNbrTrxThisWeek.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNbrTrxThisWeek.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNbrTrxThisWeek.ForeColor = System.Drawing.Color.Blue;
            this.tbNbrTrxThisWeek.Location = new System.Drawing.Point(213, 30);
            this.tbNbrTrxThisWeek.Name = "tbNbrTrxThisWeek";
            this.tbNbrTrxThisWeek.ReadOnly = true;
            this.tbNbrTrxThisWeek.Size = new System.Drawing.Size(36, 14);
            this.tbNbrTrxThisWeek.TabIndex = 108;
            this.tbNbrTrxThisWeek.TabStop = false;
            this.tbNbrTrxThisWeek.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DarkBlue;
            this.label29.Location = new System.Drawing.Point(256, 11);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 14);
            this.label29.TabIndex = 107;
            this.label29.Text = "Services This Month";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkBlue;
            this.label20.Location = new System.Drawing.Point(101, 8);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 16);
            this.label20.TabIndex = 58;
            this.label20.Text = "Last Service";
            // 
            // lblLastComm
            // 
            this.lblLastComm.BackColor = System.Drawing.Color.Transparent;
            this.lblLastComm.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastComm.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLastComm.Location = new System.Drawing.Point(101, 45);
            this.lblLastComm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastComm.Name = "lblLastComm";
            this.lblLastComm.Size = new System.Drawing.Size(86, 16);
            this.lblLastComm.TabIndex = 60;
            this.lblLastComm.Text = "Last TEFAP";
            // 
            // tbNbrTrxThisMonth
            // 
            this.tbNbrTrxThisMonth.BackColor = System.Drawing.Color.Ivory;
            this.tbNbrTrxThisMonth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNbrTrxThisMonth.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNbrTrxThisMonth.ForeColor = System.Drawing.Color.Blue;
            this.tbNbrTrxThisMonth.Location = new System.Drawing.Point(213, 13);
            this.tbNbrTrxThisMonth.Name = "tbNbrTrxThisMonth";
            this.tbNbrTrxThisMonth.ReadOnly = true;
            this.tbNbrTrxThisMonth.Size = new System.Drawing.Size(36, 14);
            this.tbNbrTrxThisMonth.TabIndex = 124;
            this.tbNbrTrxThisMonth.TabStop = false;
            this.tbNbrTrxThisMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbLastService
            // 
            this.tbLastService.BackColor = System.Drawing.Color.Ivory;
            this.tbLastService.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbLastService.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLastService.ForeColor = System.Drawing.Color.Blue;
            this.tbLastService.Location = new System.Drawing.Point(3, 9);
            this.tbLastService.Margin = new System.Windows.Forms.Padding(4);
            this.tbLastService.Name = "tbLastService";
            this.tbLastService.ReadOnly = true;
            this.tbLastService.Size = new System.Drawing.Size(90, 14);
            this.tbLastService.TabIndex = 103;
            this.tbLastService.TabStop = false;
            this.tbLastService.Tag = "LatestService";
            this.tbLastService.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbLastComodity
            // 
            this.tbLastComodity.BackColor = System.Drawing.Color.Ivory;
            this.tbLastComodity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbLastComodity.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLastComodity.ForeColor = System.Drawing.Color.Blue;
            this.tbLastComodity.Location = new System.Drawing.Point(3, 46);
            this.tbLastComodity.Margin = new System.Windows.Forms.Padding(4);
            this.tbLastComodity.Name = "tbLastComodity";
            this.tbLastComodity.ReadOnly = true;
            this.tbLastComodity.Size = new System.Drawing.Size(90, 14);
            this.tbLastComodity.TabIndex = 25;
            this.tbLastComodity.TabStop = false;
            this.tbLastComodity.Tag = "LastCommodityService";
            this.tbLastComodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DarkBlue;
            this.label28.Location = new System.Drawing.Point(101, 25);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 16);
            this.label28.TabIndex = 106;
            this.label28.Text = "Days Last Svc";
            // 
            // tbDaysSinceLstSrvc
            // 
            this.tbDaysSinceLstSrvc.BackColor = System.Drawing.Color.Ivory;
            this.tbDaysSinceLstSrvc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDaysSinceLstSrvc.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDaysSinceLstSrvc.ForeColor = System.Drawing.Color.Blue;
            this.tbDaysSinceLstSrvc.Location = new System.Drawing.Point(57, 26);
            this.tbDaysSinceLstSrvc.Margin = new System.Windows.Forms.Padding(4);
            this.tbDaysSinceLstSrvc.Name = "tbDaysSinceLstSrvc";
            this.tbDaysSinceLstSrvc.ReadOnly = true;
            this.tbDaysSinceLstSrvc.Size = new System.Drawing.Size(36, 14);
            this.tbDaysSinceLstSrvc.TabIndex = 23;
            this.tbDaysSinceLstSrvc.TabStop = false;
            this.tbDaysSinceLstSrvc.Tag = "";
            this.tbDaysSinceLstSrvc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblHHModified
            // 
            this.lblHHModified.AutoSize = true;
            this.lblHHModified.BackColor = System.Drawing.Color.Transparent;
            this.lblHHModified.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHModified.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblHHModified.Location = new System.Drawing.Point(6, 34);
            this.lblHHModified.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHHModified.Name = "lblHHModified";
            this.lblHHModified.Size = new System.Drawing.Size(61, 12);
            this.lblHHModified.TabIndex = 117;
            this.lblHHModified.Text = "Modified";
            // 
            // lblHHCreated
            // 
            this.lblHHCreated.AutoSize = true;
            this.lblHHCreated.BackColor = System.Drawing.Color.Transparent;
            this.lblHHCreated.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHCreated.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblHHCreated.Location = new System.Drawing.Point(6, 10);
            this.lblHHCreated.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHHCreated.Name = "lblHHCreated";
            this.lblHHCreated.Size = new System.Drawing.Size(54, 12);
            this.lblHHCreated.TabIndex = 116;
            this.lblHHCreated.Text = "Created";
            // 
            // chkShowOnLog
            // 
            this.chkShowOnLog.AutoSize = true;
            this.chkShowOnLog.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowOnLog.Location = new System.Drawing.Point(411, 3);
            this.chkShowOnLog.Margin = new System.Windows.Forms.Padding(4);
            this.chkShowOnLog.Name = "chkShowOnLog";
            this.chkShowOnLog.Size = new System.Drawing.Size(144, 18);
            this.chkShowOnLog.TabIndex = 17;
            this.chkShowOnLog.Tag = "IncludeOnLog";
            this.chkShowOnLog.Text = "Show Note On Log";
            this.chkShowOnLog.UseVisualStyleBackColor = true;
            this.chkShowOnLog.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkShowOnLog.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // tbBabySvcDescr
            // 
            this.tbBabySvcDescr.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBabySvcDescr.Location = new System.Drawing.Point(410, 44);
            this.tbBabySvcDescr.Multiline = true;
            this.tbBabySvcDescr.Name = "tbBabySvcDescr";
            this.tbBabySvcDescr.Size = new System.Drawing.Size(187, 45);
            this.tbBabySvcDescr.TabIndex = 28;
            this.tbBabySvcDescr.Tag = "BabySvcDescr";
            // 
            // chkBabyServices
            // 
            this.chkBabyServices.Location = new System.Drawing.Point(411, 24);
            this.chkBabyServices.Margin = new System.Windows.Forms.Padding(4);
            this.chkBabyServices.Name = "chkBabyServices";
            this.chkBabyServices.Size = new System.Drawing.Size(20, 18);
            this.chkBabyServices.TabIndex = 27;
            this.chkBabyServices.Tag = "BabyServices";
            this.chkBabyServices.UseVisualStyleBackColor = true;
            this.chkBabyServices.Enter += new System.EventHandler(this.chkbox_Enter);
            this.chkBabyServices.Leave += new System.EventHandler(this.chkbox_Leave);
            // 
            // lblBabyServices
            // 
            this.lblBabyServices.AutoSize = true;
            this.lblBabyServices.BackColor = System.Drawing.Color.Transparent;
            this.lblBabyServices.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBabyServices.Location = new System.Drawing.Point(429, 25);
            this.lblBabyServices.Name = "lblBabyServices";
            this.lblBabyServices.Size = new System.Drawing.Size(106, 17);
            this.lblBabyServices.TabIndex = 115;
            this.lblBabyServices.Text = "Baby Services";
            // 
            // cmsLog
            // 
            this.cmsLog.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowSignature,
            this.tsmiExpandLog,
            this.tsmiExportToExcel});
            this.cmsLog.Name = "cmsLog";
            this.cmsLog.Size = new System.Drawing.Size(204, 70);
            this.cmsLog.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmsLog_ItemClicked);
            // 
            // tsmiExpandLog
            // 
            this.tsmiExpandLog.Name = "tsmiExpandLog";
            this.tsmiExpandLog.Size = new System.Drawing.Size(203, 22);
            this.tsmiExpandLog.Text = "Expand HH Transactions";
            // 
            // tsmiExportToExcel
            // 
            this.tsmiExportToExcel.Name = "tsmiExportToExcel";
            this.tsmiExportToExcel.Size = new System.Drawing.Size(203, 22);
            this.tsmiExportToExcel.Text = "Export To Excel";
            // 
            // tabCntrlLog
            // 
            this.tabCntrlLog.Controls.Add(this.tpgTrxLog);
            this.tabCntrlLog.Controls.Add(this.tpgVouchers);
            this.tabCntrlLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCntrlLog.ItemSize = new System.Drawing.Size(71, 21);
            this.tabCntrlLog.Location = new System.Drawing.Point(0, 0);
            this.tabCntrlLog.Name = "tabCntrlLog";
            this.tabCntrlLog.Padding = new System.Drawing.Point(10, 3);
            this.tabCntrlLog.SelectedIndex = 0;
            this.tabCntrlLog.Size = new System.Drawing.Size(601, 235);
            this.tabCntrlLog.TabIndex = 0;
            // 
            // tpgTrxLog
            // 
            this.tpgTrxLog.Controls.Add(this.picSignature);
            this.tpgTrxLog.Controls.Add(this.btnEnlarge);
            this.tpgTrxLog.Controls.Add(this.btnColapse);
            this.tpgTrxLog.Controls.Add(this.lvTrxLog);
            this.tpgTrxLog.Controls.Add(this.btnEditTransLog);
            this.tpgTrxLog.Controls.Add(this.cboTrxLogPeriod);
            this.tpgTrxLog.Controls.Add(this.LBLpERIOD);
            this.tpgTrxLog.Location = new System.Drawing.Point(4, 25);
            this.tpgTrxLog.Margin = new System.Windows.Forms.Padding(0);
            this.tpgTrxLog.Name = "tpgTrxLog";
            this.tpgTrxLog.Size = new System.Drawing.Size(593, 206);
            this.tpgTrxLog.TabIndex = 0;
            this.tpgTrxLog.Text = "Food Services Log";
            this.tpgTrxLog.UseVisualStyleBackColor = true;
            this.tpgTrxLog.Resize += new System.EventHandler(this.tpgTrxLog_Resize);
            // 
            // btnEnlarge
            // 
            this.btnEnlarge.Image = global::ClientcardFB3.Properties.Resources.back16;
            this.btnEnlarge.Location = new System.Drawing.Point(3, 5);
            this.btnEnlarge.Name = "btnEnlarge";
            this.btnEnlarge.Size = new System.Drawing.Size(24, 24);
            this.btnEnlarge.TabIndex = 45;
            this.btnEnlarge.UseVisualStyleBackColor = true;
            this.btnEnlarge.Click += new System.EventHandler(this.btnEnlarge_Click);
            // 
            // btnColapse
            // 
            this.btnColapse.Image = global::ClientcardFB3.Properties.Resources.Right16;
            this.btnColapse.Location = new System.Drawing.Point(3, 6);
            this.btnColapse.Name = "btnColapse";
            this.btnColapse.Size = new System.Drawing.Size(24, 24);
            this.btnColapse.TabIndex = 48;
            this.btnColapse.UseVisualStyleBackColor = true;
            this.btnColapse.Visible = false;
            this.btnColapse.Click += new System.EventHandler(this.btnColapse_Click);
            // 
            // lvTrxLog
            // 
            this.lvTrxLog.AllowColumnReorder = true;
            this.lvTrxLog.BackColor = System.Drawing.Color.Cornsilk;
            this.lvTrxLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmNum,
            this.clmDate,
            this.clmName,
            this.clmSvcList,
            this.clmNonFoodLst,
            this.clmLbs,
            this.clmOther,
            this.clmComm,
            this.clmSupl,
            this.clmBaby,
            this.clmNotes,
            this.clmInfants,
            this.clmYouth,
            this.clmTeens,
            this.clmEighteen,
            this.clmAdults,
            this.clmSeniors,
            this.clmTotal,
            this.clmTrxID,
            this.clmCreateBy,
            this.clmCreated});
            this.lvTrxLog.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvTrxLog.FullRowSelect = true;
            this.lvTrxLog.GridLines = true;
            this.lvTrxLog.HideSelection = false;
            this.lvTrxLog.Location = new System.Drawing.Point(0, 32);
            this.lvTrxLog.Margin = new System.Windows.Forms.Padding(4);
            this.lvTrxLog.MultiSelect = false;
            this.lvTrxLog.Name = "lvTrxLog";
            this.lvTrxLog.Size = new System.Drawing.Size(588, 124);
            this.lvTrxLog.SmallImageList = this.imageList1;
            this.lvTrxLog.TabIndex = 50;
            this.lvTrxLog.UseCompatibleStateImageBehavior = false;
            this.lvTrxLog.View = System.Windows.Forms.View.Details;
            this.lvTrxLog.SelectedIndexChanged += new System.EventHandler(this.lvTrxLog_SelectedIndexChanged);
            this.lvTrxLog.DoubleClick += new System.EventHandler(this.lvTrxLog_DoubleClick);
            // 
            // clmNum
            // 
            this.clmNum.Text = "#";
            this.clmNum.Width = 23;
            // 
            // clmDate
            // 
            this.clmDate.Text = "Date";
            this.clmDate.Width = 85;
            // 
            // clmName
            // 
            this.clmName.Text = "Pickup By";
            this.clmName.Width = 150;
            // 
            // clmSvcList
            // 
            this.clmSvcList.Text = "FoodSvcList";
            this.clmSvcList.Width = 89;
            // 
            // clmNonFoodLst
            // 
            this.clmNonFoodLst.Tag = "NonFoodSvcList";
            this.clmNonFoodLst.Text = "Non-Food List";
            this.clmNonFoodLst.Width = 42;
            // 
            // clmLbs
            // 
            this.clmLbs.Text = "Std";
            this.clmLbs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmLbs.Width = 40;
            // 
            // clmOther
            // 
            this.clmOther.Text = "Oth";
            this.clmOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmOther.Width = 40;
            // 
            // clmComm
            // 
            this.clmComm.Text = "Cm";
            this.clmComm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmComm.Width = 40;
            // 
            // clmSupl
            // 
            this.clmSupl.Text = "Supl";
            this.clmSupl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmSupl.Width = 40;
            // 
            // clmBaby
            // 
            this.clmBaby.Text = "Baby";
            this.clmBaby.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmBaby.Width = 40;
            // 
            // clmNotes
            // 
            this.clmNotes.Text = "Notes";
            this.clmNotes.Width = 75;
            // 
            // clmInfants
            // 
            this.clmInfants.Text = "<3";
            this.clmInfants.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmInfants.Width = 32;
            // 
            // clmYouth
            // 
            this.clmYouth.Text = "Yth";
            this.clmYouth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmYouth.Width = 32;
            // 
            // clmTeens
            // 
            this.clmTeens.Text = "Tns";
            this.clmTeens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmTeens.Width = 32;
            // 
            // clmEighteen
            // 
            this.clmEighteen.Text = "18";
            this.clmEighteen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmEighteen.Width = 32;
            // 
            // clmAdults
            // 
            this.clmAdults.Text = "Adlt";
            this.clmAdults.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmAdults.Width = 32;
            // 
            // clmSeniors
            // 
            this.clmSeniors.Text = "Sen";
            this.clmSeniors.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmSeniors.Width = 32;
            // 
            // clmTotal
            // 
            this.clmTotal.Text = "Ttl";
            this.clmTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clmTotal.Width = 35;
            // 
            // clmTrxID
            // 
            this.clmTrxID.Text = "TrxID";
            this.clmTrxID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // clmCreateBy
            // 
            this.clmCreateBy.Text = "CreatedBy";
            this.clmCreateBy.Width = 150;
            // 
            // clmCreated
            // 
            this.clmCreated.Text = "Created";
            this.clmCreated.Width = 100;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "pin_blue.png");
            // 
            // btnEditTransLog
            // 
            this.btnEditTransLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnEditTransLog.Location = new System.Drawing.Point(289, 4);
            this.btnEditTransLog.Name = "btnEditTransLog";
            this.btnEditTransLog.Size = new System.Drawing.Size(67, 24);
            this.btnEditTransLog.TabIndex = 49;
            this.btnEditTransLog.Text = "Edit";
            this.btnEditTransLog.UseVisualStyleBackColor = true;
            this.btnEditTransLog.Click += new System.EventHandler(this.btnEditTransLog_Click);
            // 
            // cboTrxLogPeriod
            // 
            this.cboTrxLogPeriod.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboTrxLogPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrxLogPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboTrxLogPeriod.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTrxLogPeriod.FormattingEnabled = true;
            this.cboTrxLogPeriod.ItemHeight = 14;
            this.cboTrxLogPeriod.Items.AddRange(new object[] {
            "Current Month",
            "Last 90 Days",
            "Current Calendar Year",
            "Current Fiscal Year",
            "Previous Calendar Year",
            "Previous Fiscal Year",
            "All"});
            this.cboTrxLogPeriod.Location = new System.Drawing.Point(103, 6);
            this.cboTrxLogPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.cboTrxLogPeriod.Name = "cboTrxLogPeriod";
            this.cboTrxLogPeriod.Size = new System.Drawing.Size(169, 22);
            this.cboTrxLogPeriod.TabIndex = 48;
            this.cboTrxLogPeriod.Tag = "";
            this.cboTrxLogPeriod.SelectionChangeCommitted += new System.EventHandler(this.cboTrxLogPeriod_SelectionChangeCommitted);
            // 
            // LBLpERIOD
            // 
            this.LBLpERIOD.BackColor = System.Drawing.Color.Transparent;
            this.LBLpERIOD.Location = new System.Drawing.Point(37, 9);
            this.LBLpERIOD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLpERIOD.Name = "LBLpERIOD";
            this.LBLpERIOD.Size = new System.Drawing.Size(57, 18);
            this.LBLpERIOD.TabIndex = 47;
            this.LBLpERIOD.Text = "Period:";
            this.LBLpERIOD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tpgVouchers
            // 
            this.tpgVouchers.BackColor = System.Drawing.Color.Tan;
            this.tpgVouchers.Controls.Add(this.lvVoucherLog);
            this.tpgVouchers.Controls.Add(this.btnEditVoucherLog);
            this.tpgVouchers.Controls.Add(this.cboVoucherLogPeriod);
            this.tpgVouchers.Controls.Add(this.label23);
            this.tpgVouchers.Controls.Add(this.btnVoucherEnlarge);
            this.tpgVouchers.Controls.Add(this.btnVoucherColapse);
            this.tpgVouchers.Location = new System.Drawing.Point(4, 25);
            this.tpgVouchers.Margin = new System.Windows.Forms.Padding(0);
            this.tpgVouchers.Name = "tpgVouchers";
            this.tpgVouchers.Size = new System.Drawing.Size(593, 206);
            this.tpgVouchers.TabIndex = 1;
            this.tpgVouchers.Text = "Voucher Log";
            // 
            // lvVoucherLog
            // 
            this.lvVoucherLog.AllowColumnReorder = true;
            this.lvVoucherLog.BackColor = System.Drawing.Color.Cornsilk;
            this.lvVoucherLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colCount,
            this.colTrxDate,
            this.colDesc,
            this.colAmount,
            this.colNotes,
            this.colTrxID});
            this.lvVoucherLog.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvVoucherLog.FullRowSelect = true;
            this.lvVoucherLog.GridLines = true;
            this.lvVoucherLog.HideSelection = false;
            this.lvVoucherLog.Location = new System.Drawing.Point(0, 32);
            this.lvVoucherLog.Margin = new System.Windows.Forms.Padding(4);
            this.lvVoucherLog.MultiSelect = false;
            this.lvVoucherLog.Name = "lvVoucherLog";
            this.lvVoucherLog.Size = new System.Drawing.Size(613, 188);
            this.lvVoucherLog.TabIndex = 56;
            this.lvVoucherLog.UseCompatibleStateImageBehavior = false;
            this.lvVoucherLog.View = System.Windows.Forms.View.Details;
            this.lvVoucherLog.SelectedIndexChanged += new System.EventHandler(this.lvVoucherLog_SelectedIndexChanged);
            // 
            // colCount
            // 
            this.colCount.Text = "#";
            this.colCount.Width = 23;
            // 
            // colTrxDate
            // 
            this.colTrxDate.Text = "Date";
            this.colTrxDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTrxDate.Width = 80;
            // 
            // colDesc
            // 
            this.colDesc.Text = "Description";
            this.colDesc.Width = 150;
            // 
            // colAmount
            // 
            this.colAmount.Text = "Amount";
            this.colAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // colNotes
            // 
            this.colNotes.Tag = "";
            this.colNotes.Text = "Notes";
            this.colNotes.Width = 200;
            // 
            // colTrxID
            // 
            this.colTrxID.Text = "TrxID";
            this.colTrxID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEditVoucherLog
            // 
            this.btnEditVoucherLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnEditVoucherLog.Location = new System.Drawing.Point(290, 4);
            this.btnEditVoucherLog.Name = "btnEditVoucherLog";
            this.btnEditVoucherLog.Size = new System.Drawing.Size(67, 24);
            this.btnEditVoucherLog.TabIndex = 55;
            this.btnEditVoucherLog.Text = "Edit";
            this.btnEditVoucherLog.UseVisualStyleBackColor = true;
            this.btnEditVoucherLog.Click += new System.EventHandler(this.btnEditVoucherLog_Click);
            // 
            // cboVoucherLogPeriod
            // 
            this.cboVoucherLogPeriod.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboVoucherLogPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVoucherLogPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboVoucherLogPeriod.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboVoucherLogPeriod.FormattingEnabled = true;
            this.cboVoucherLogPeriod.ItemHeight = 14;
            this.cboVoucherLogPeriod.Items.AddRange(new object[] {
            "Current Month",
            "Last 90 Days",
            "Current Calendar Year",
            "Current Fiscal Year",
            "Previous Calendar Year",
            "Previous Fiscal Year",
            "All"});
            this.cboVoucherLogPeriod.Location = new System.Drawing.Point(103, 6);
            this.cboVoucherLogPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.cboVoucherLogPeriod.Name = "cboVoucherLogPeriod";
            this.cboVoucherLogPeriod.Size = new System.Drawing.Size(169, 22);
            this.cboVoucherLogPeriod.TabIndex = 53;
            this.cboVoucherLogPeriod.Tag = "";
            this.cboVoucherLogPeriod.SelectionChangeCommitted += new System.EventHandler(this.cboVoucherLogPeriod_SelectionChangeCommitted);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Location = new System.Drawing.Point(38, 8);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(57, 18);
            this.label23.TabIndex = 52;
            this.label23.Text = "Period:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnVoucherEnlarge
            // 
            this.btnVoucherEnlarge.Image = global::ClientcardFB3.Properties.Resources.back16;
            this.btnVoucherEnlarge.Location = new System.Drawing.Point(3, 5);
            this.btnVoucherEnlarge.Name = "btnVoucherEnlarge";
            this.btnVoucherEnlarge.Size = new System.Drawing.Size(24, 24);
            this.btnVoucherEnlarge.TabIndex = 51;
            this.btnVoucherEnlarge.UseVisualStyleBackColor = true;
            this.btnVoucherEnlarge.Click += new System.EventHandler(this.btnEnlarge_Click);
            // 
            // btnVoucherColapse
            // 
            this.btnVoucherColapse.Image = global::ClientcardFB3.Properties.Resources.Right16;
            this.btnVoucherColapse.Location = new System.Drawing.Point(3, 5);
            this.btnVoucherColapse.Name = "btnVoucherColapse";
            this.btnVoucherColapse.Size = new System.Drawing.Size(24, 24);
            this.btnVoucherColapse.TabIndex = 54;
            this.btnVoucherColapse.UseVisualStyleBackColor = true;
            this.btnVoucherColapse.Visible = false;
            this.btnVoucherColapse.Click += new System.EventHandler(this.btnColapse_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.AutoSize = false;
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbCreateAppt,
            this.tsbDfltApptDate,
            this.tsbCSFP,
            this.tsbFoodDonations,
            this.tsbPrintClientcard,
            this.tsbVouchers});
            this.toolStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(82, 330);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // tsbCreateAppt
            // 
            this.tsbCreateAppt.ForeColor = System.Drawing.Color.Maroon;
            this.tsbCreateAppt.Image = ((System.Drawing.Image)(resources.GetObject("tsbCreateAppt.Image")));
            this.tsbCreateAppt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbCreateAppt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbCreateAppt.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbCreateAppt.Margin = new System.Windows.Forms.Padding(0);
            this.tsbCreateAppt.Name = "tsbCreateAppt";
            this.tsbCreateAppt.Size = new System.Drawing.Size(80, 51);
            this.tsbCreateAppt.Tag = "CreateAppt";
            this.tsbCreateAppt.Text = "Ne&w Appt.";
            this.tsbCreateAppt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbCreateAppt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbCreateAppt.ToolTipText = "Create New Apptointment";
            this.tsbCreateAppt.Click += new System.EventHandler(this.tsbCreateAppt_Click);
            // 
            // tsbDfltApptDate
            // 
            this.tsbDfltApptDate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDfltApptDate.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Underline);
            this.tsbDfltApptDate.ForeColor = System.Drawing.Color.Maroon;
            this.tsbDfltApptDate.Image = ((System.Drawing.Image)(resources.GetObject("tsbDfltApptDate.Image")));
            this.tsbDfltApptDate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDfltApptDate.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.tsbDfltApptDate.Name = "tsbDfltApptDate";
            this.tsbDfltApptDate.Size = new System.Drawing.Size(80, 17);
            this.tsbDfltApptDate.Text = "11/25/2011";
            this.tsbDfltApptDate.Click += new System.EventHandler(this.tsbDfltApptDate_Click);
            // 
            // tsbCSFP
            // 
            this.tsbCSFP.Image = ((System.Drawing.Image)(resources.GetObject("tsbCSFP.Image")));
            this.tsbCSFP.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbCSFP.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbCSFP.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbCSFP.Name = "tsbCSFP";
            this.tsbCSFP.Size = new System.Drawing.Size(80, 51);
            this.tsbCSFP.Tag = "CSFP";
            this.tsbCSFP.Text = "C&SFP";
            this.tsbCSFP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbCSFP.ToolTipText = "The Commodity Supplemental Food Programs (CSFP) is a Federally funded program, ";
            this.tsbCSFP.Click += new System.EventHandler(this.tsbCSFP_Click);
            // 
            // tsbFoodDonations
            // 
            this.tsbFoodDonations.AutoSize = false;
            this.tsbFoodDonations.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbFoodDonations.Image = ((System.Drawing.Image)(resources.GetObject("tsbFoodDonations.Image")));
            this.tsbFoodDonations.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbFoodDonations.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbFoodDonations.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFoodDonations.Name = "tsbFoodDonations";
            this.tsbFoodDonations.Size = new System.Drawing.Size(80, 55);
            this.tsbFoodDonations.Text = "Foo&d Rcpts";
            this.tsbFoodDonations.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.tsbFoodDonations.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbFoodDonations.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbFoodDonations.ToolTipText = "Display Donations Form";
            this.tsbFoodDonations.Click += new System.EventHandler(this.tsbFoodDonations_Click);
            // 
            // tsbPrintClientcard
            // 
            this.tsbPrintClientcard.AutoSize = false;
            this.tsbPrintClientcard.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbPrintClientcard.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrintClientcard.Image")));
            this.tsbPrintClientcard.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbPrintClientcard.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbPrintClientcard.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrintClientcard.Name = "tsbPrintClientcard";
            this.tsbPrintClientcard.Size = new System.Drawing.Size(80, 50);
            this.tsbPrintClientcard.Text = "&Print Client";
            this.tsbPrintClientcard.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbPrintClientcard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbPrintClientcard.ToolTipText = "Print Client Household Card";
            this.tsbPrintClientcard.Click += new System.EventHandler(this.tbsPrintClientcard_Click);
            // 
            // tsbVouchers
            // 
            this.tsbVouchers.AutoSize = false;
            this.tsbVouchers.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbVouchers.Image = ((System.Drawing.Image)(resources.GetObject("tsbVouchers.Image")));
            this.tsbVouchers.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbVouchers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbVouchers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbVouchers.Name = "tsbVouchers";
            this.tsbVouchers.Size = new System.Drawing.Size(80, 55);
            this.tsbVouchers.Text = "&Vouchers";
            this.tsbVouchers.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbVouchers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbVouchers.ToolTipText = "Display Vouchers Form";
            this.tsbVouchers.Click += new System.EventHandler(this.tsbVouchers_Click);
            // 
            // incomeMatrixToolStripMenuItem
            // 
            this.incomeMatrixToolStripMenuItem.Name = "incomeMatrixToolStripMenuItem";
            this.incomeMatrixToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // tsmiExportToExcell
            // 
            this.tsmiExportToExcell.Name = "tsmiExportToExcell";
            this.tsmiExportToExcell.Size = new System.Drawing.Size(32, 19);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(23, 23);
            // 
            // tsmiShowSignature
            // 
            this.tsmiShowSignature.Name = "tsmiShowSignature";
            this.tsmiShowSignature.Size = new System.Drawing.Size(203, 22);
            this.tsmiShowSignature.Text = "Show Signature";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle66.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle66;
            this.dataGridViewTextBoxColumn1.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle91.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle91.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle91;
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle92.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle92.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle92;
            this.dataGridViewTextBoxColumn3.HeaderText = "BirthDate";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 90;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle93.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle93.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle93;
            this.dataGridViewTextBoxColumn4.HeaderText = "Age";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 35;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle94.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle94.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle94;
            this.dataGridViewTextBoxColumn5.HeaderText = "Group";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 45;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle95.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle95.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle95;
            this.dataGridViewTextBoxColumn6.HeaderText = "Sex";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 25;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle96.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle96.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle96;
            this.dataGridViewTextBoxColumn7.HeaderText = "CSFP";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 40;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle97.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle97;
            this.dataGridViewTextBoxColumn8.HeaderText = "ID";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // clmLastName
            // 
            this.clmLastName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle83.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle83.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmLastName.DefaultCellStyle = dataGridViewCellStyle83;
            this.clmLastName.HeaderText = "Last Name";
            this.clmLastName.Name = "clmLastName";
            this.clmLastName.ReadOnly = true;
            this.clmLastName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clmFirstName
            // 
            this.clmFirstName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle84.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle84.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmFirstName.DefaultCellStyle = dataGridViewCellStyle84;
            this.clmFirstName.HeaderText = "First Name";
            this.clmFirstName.Name = "clmFirstName";
            this.clmFirstName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // clmBirthdate
            // 
            this.clmBirthdate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle85.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle85.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmBirthdate.DefaultCellStyle = dataGridViewCellStyle85;
            this.clmBirthdate.HeaderText = "BirthDate";
            this.clmBirthdate.Name = "clmBirthdate";
            this.clmBirthdate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmBirthdate.Width = 90;
            // 
            // clmAge
            // 
            this.clmAge.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle86.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle86.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmAge.DefaultCellStyle = dataGridViewCellStyle86;
            this.clmAge.HeaderText = "Age";
            this.clmAge.Name = "clmAge";
            this.clmAge.ReadOnly = true;
            this.clmAge.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmAge.Width = 35;
            // 
            // clmGroup
            // 
            this.clmGroup.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle87.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle87.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmGroup.DefaultCellStyle = dataGridViewCellStyle87;
            this.clmGroup.HeaderText = "Group";
            this.clmGroup.Name = "clmGroup";
            this.clmGroup.ReadOnly = true;
            this.clmGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmGroup.Width = 45;
            // 
            // clmSex
            // 
            this.clmSex.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle88.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmSex.DefaultCellStyle = dataGridViewCellStyle88;
            this.clmSex.HeaderText = "Sex";
            this.clmSex.Name = "clmSex";
            this.clmSex.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmSex.Width = 25;
            // 
            // clmCSFP
            // 
            this.clmCSFP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle89.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle89.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmCSFP.DefaultCellStyle = dataGridViewCellStyle89;
            this.clmCSFP.HeaderText = "CSFP";
            this.clmCSFP.Name = "clmCSFP";
            this.clmCSFP.ReadOnly = true;
            this.clmCSFP.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clmCSFP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmCSFP.Width = 70;
            // 
            // clmHMID
            // 
            this.clmHMID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle90.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clmHMID.DefaultCellStyle = dataGridViewCellStyle90;
            this.clmHMID.HeaderText = "ID";
            this.clmHMID.Name = "clmHMID";
            this.clmHMID.ReadOnly = true;
            this.clmHMID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmHMID.Visible = false;
            // 
            // picSignature
            // 
            this.picSignature.BackColor = System.Drawing.Color.Cornsilk;
            this.picSignature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSignature.Location = new System.Drawing.Point(229, 2);
            this.picSignature.Name = "picSignature";
            this.picSignature.Size = new System.Drawing.Size(300, 58);
            this.picSignature.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picSignature.TabIndex = 51;
            this.picSignature.TabStop = false;
            this.picSignature.Visible = false;
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.splCntrCardMembers);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Client Household Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splCntrCardMembers.Panel1.ResumeLayout(false);
            this.splCntrCardMembers.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCntrCardMembers)).EndInit();
            this.splCntrCardMembers.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabFamily.ResumeLayout(false);
            this.tpgFamilyDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHHMembers)).EndInit();
            this.cmsHHMembers.ResumeLayout(false);
            this.tpgFamilySummary.ResumeLayout(false);
            this.tpgFamilySummary.PerformLayout();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxEditAlert)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitMemTrans.Panel1.ResumeLayout(false);
            this.splitMemTrans.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitMemTrans)).EndInit();
            this.splitMemTrans.ResumeLayout(false);
            this.tabCntrlMain.ResumeLayout(false);
            this.tpgHHData.ResumeLayout(false);
            this.tpgHHData.PerformLayout();
            this.grpbxVerifyId.ResumeLayout(false);
            this.grpbxVerifyId.PerformLayout();
            this.tpgUserFields.ResumeLayout(false);
            this.tpgUserFields.PerformLayout();
            this.tpgIncome.ResumeLayout(false);
            this.grpbxIncome.ResumeLayout(false);
            this.grpbxIncome.PerformLayout();
            this.tpgHD.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tpgPointSys.ResumeLayout(false);
            this.tpgPointSys.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.cmsLog.ResumeLayout(false);
            this.tabCntrlLog.ResumeLayout(false);
            this.tpgTrxLog.ResumeLayout(false);
            this.tpgTrxLog.PerformLayout();
            this.tpgVouchers.ResumeLayout(false);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSignature)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuClient;
        private System.Windows.Forms.ToolStripMenuItem menuReports;
        private System.Windows.Forms.ToolStripMenuItem menuAdmin;
        private System.Windows.Forms.ToolStripMenuItem menuTools;
        private System.Windows.Forms.ToolStripMenuItem menuHelp;
        private System.Windows.Forms.SplitContainer splCntrCardMembers;
        private System.Windows.Forms.ToolStripButton tbsPrintClient;
        private System.Windows.Forms.CheckBox chkNeedCommSig;
        private System.Windows.Forms.TextBox tbeNotes;
        private System.Windows.Forms.CheckBox chkNoCommodities;
        private System.Windows.Forms.CheckBox chkSupplOnly;
        private System.Windows.Forms.CheckBox chkInactive;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbeZipCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbeState;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbeCity;
        private System.Windows.Forms.TextBox tbeAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBeginEdit;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.ComboBox cboSpecialLang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboClientType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbTotalFam;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbmSeniors;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbmAdults;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbmTeens;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbmYouth;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbmInfants;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbmDiet;
        private System.Windows.Forms.CheckBox chkUseFamList;
        private System.Windows.Forms.CheckBox chkShowOnLog;
        private System.Windows.Forms.TextBox tbDaysSinceLstSrvc;
        private System.Windows.Forms.Label lblLastComm;
        private System.Windows.Forms.TextBox tbLastComodity;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbLastService;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbVouchers;
        private System.Windows.Forms.ToolStripButton tsbFoodDonations;
        private System.Windows.Forms.SplitContainer splitMemTrans;
        private System.Windows.Forms.ListView lvTrxLog;
        private System.Windows.Forms.ColumnHeader clmNum;
        private System.Windows.Forms.ColumnHeader clmDate;
        private System.Windows.Forms.ColumnHeader clmInfants;
        private System.Windows.Forms.ColumnHeader clmYouth;
        private System.Windows.Forms.ColumnHeader clmTeens;
        private System.Windows.Forms.ColumnHeader clmAdults;
        private System.Windows.Forms.ColumnHeader clmSeniors;
        private System.Windows.Forms.ColumnHeader clmTotal;
        private System.Windows.Forms.ColumnHeader clmLbs;
        private System.Windows.Forms.ColumnHeader clmOther;
        private System.Windows.Forms.ColumnHeader clmComm;
        private System.Windows.Forms.ColumnHeader clmSupl;
        private System.Windows.Forms.ColumnHeader clmSvcList;
        private System.Windows.Forms.ColumnHeader clmNotes;
        private System.Windows.Forms.ColumnHeader clmCreated;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_ServiceItemsForm;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_YearlyCalendarForm;
        private System.Windows.Forms.Button btnEditTransLog;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_PreferencesForm;
        private System.Windows.Forms.ColumnHeader clmNonFoodLst;
        private System.Windows.Forms.PrintDialog dlg;
        private System.Windows.Forms.ColumnHeader clmTrxID;
        private System.Windows.Forms.TextBox tbmDisabled;
        private System.Windows.Forms.CheckBox chkHomeless;
        private System.Windows.Forms.CheckBox chkInCityLimits;
        private System.Windows.Forms.DataGridView dgvHHMembers;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEnlarge;
        private System.Windows.Forms.Button btnColapse;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ContextMenuStrip cmsHHMembers;
        private System.Windows.Forms.ContextMenuStrip cmsLog;
        private System.Windows.Forms.ToolStripMenuItem tsmiExpandLog;
        private System.Windows.Forms.TextBox tbNbrTrxThisMonth;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_UserListForm;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_FindClient;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_AddHH;
        private System.Windows.Forms.ToolStripSeparator mnuSeparator4;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_BeginEditClient;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_CancelEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_SaveHHChanges;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_DeleteClient;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_PrintClientCard;
        private System.Windows.Forms.ToolStripSeparator mnuSeparator5;
        private System.Windows.Forms.ToolStripSeparator mnuSeparator6;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_Exit;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_TypeCodesForm;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_SaveAsNewClientDefaults;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_VolHoursForm;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_DonationsForm;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_VolunteersForm;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_DonorsForm;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_CashDonations;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_LogOut;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_EmailRecipients;
        private System.Windows.Forms.ToolStripButton tsbPrintClientcard;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbFindClient;
        private System.Windows.Forms.ToolStripButton tsbAddClient;
        private System.Windows.Forms.ToolStripButton tsbNewService;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.TextBox tbeFirstService;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_PrintForm;
        private System.Windows.Forms.ToolStripMenuItem menuTrx;
        private System.Windows.Forms.ToolStripMenuItem mnuTrx_NewAppointment;
        private System.Windows.Forms.ToolStripMenuItem mnuTrx_NewServiceTrx;
        private System.Windows.Forms.ToolStripMenuItem mnuTrx_Edit;
        private System.Windows.Forms.ToolStripMenuItem mnuTrx_Delete;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp_Contents;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp_Index;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp_About;
        private System.Windows.Forms.Label lblCSFP;
        private System.Windows.Forms.TextBox tbmCSFP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_UserDefinedFields;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem mnuReports_AccessRpts;
        private System.Windows.Forms.ToolStripMenuItem mnuReports_MonthlyForm;
        private System.Windows.Forms.ToolStripMenuItem tsmiExportToExcell;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem incomeMatrixToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_IncomeMatrix;
        private System.Windows.Forms.ToolStripMenuItem tsmiExportToExcel;
        private System.Windows.Forms.ToolStripButton tsbDfltSvcDate;
        private System.Windows.Forms.ToolStripButton tsbCreateAppt;
        private System.Windows.Forms.ToolStripButton tsbDfltApptDate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.TabControl tabCntrlMain;
        private System.Windows.Forms.TabPage tpgHHData;
        private System.Windows.Forms.GroupBox grpbxVerifyId;
        private System.Windows.Forms.CheckBox chkNeedVerifyID;
        private System.Windows.Forms.ComboBox cboIDType;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbeDateIDVerified;
        private System.Windows.Forms.ComboBox cboPhoneType;
        private System.Windows.Forms.Label lblPhoneType;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.TabPage tpgUserFields;
        private System.Windows.Forms.GroupBox grpbxIncome;
        private System.Windows.Forms.ListView lvIncomeGroups;
        private System.Windows.Forms.ColumnHeader colIncomeGrpId;
        private System.Windows.Forms.ColumnHeader colIncomeGrpName;
        private System.Windows.Forms.ColumnHeader colIncomeCat;
        private System.Windows.Forms.TextBox tbIncomeMonthly;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbUserNum0;
        private System.Windows.Forms.TextBox tbUserNum1;
        private System.Windows.Forms.Label lblUserNum0;
        private System.Windows.Forms.Label lblUserNum1;
        private System.Windows.Forms.CheckedListBox chkLstBxUserFields;
        private System.Windows.Forms.Label LBLpERIOD;
        private System.Windows.Forms.ComboBox cboTrxLogPeriod;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNeedCommodSignature;
        private System.Windows.Forms.Label lblNoCommodities;
        private System.Windows.Forms.Label lblSupplOnly;
        private System.Windows.Forms.Label lblHomeless;
        private System.Windows.Forms.Label lblInCityLimits;
        private System.Windows.Forms.Label lblNeedToVerifyId;
        private System.Windows.Forms.ColumnHeader clmName;
        private System.Windows.Forms.TabControl tabFamily;
        private System.Windows.Forms.TabPage tpgFamilyDetail;
        private System.Windows.Forms.TabPage tpgFamilySummary;
        private System.Windows.Forms.ToolStripButton tsbHHMem;
        private System.Windows.Forms.TabPage tpgIncome;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clmInactive;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmLastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmFirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmBirthdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAge;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCSFP;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clmDiet;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Disabled;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmHMID;
        private System.Windows.Forms.TextBox tbBabySvcDescr;
        private System.Windows.Forms.Label lblBabyServices;
        private System.Windows.Forms.CheckBox chkBabyServices;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_GroceryRescue;
        private System.Windows.Forms.RichTextBox tbAlert;
        private System.Windows.Forms.Label lblSingleHeadHH;
        private System.Windows.Forms.CheckBox chkSingleHeadHH;
        private System.Windows.Forms.TextBox tbmEighteens;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader clmEighteen;
        private System.Windows.Forms.ToolStripButton tsbCSFP;
        private System.Windows.Forms.Button btnAssignBarcode;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_MaintainVoucherItems;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_BackupDatabase;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.TextBox tbeApt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkNeedIncomeVerification;
        private System.Windows.Forms.TabControl tabCntrlLog;
        private System.Windows.Forms.TabPage tpgTrxLog;
        private System.Windows.Forms.TabPage tpgVouchers;
        private System.Windows.Forms.Button btnVoucherEnlarge;
        private System.Windows.Forms.Button btnVoucherColapse;
        private System.Windows.Forms.ListView lvVoucherLog;
        private System.Windows.Forms.ColumnHeader colCount;
        private System.Windows.Forms.ColumnHeader colTrxDate;
        private System.Windows.Forms.ColumnHeader colDesc;
        private System.Windows.Forms.ColumnHeader colAmount;
        private System.Windows.Forms.ColumnHeader colNotes;
        private System.Windows.Forms.ColumnHeader colTrxID;
        private System.Windows.Forms.Button btnEditVoucherLog;
        private System.Windows.Forms.ComboBox cboVoucherLogPeriod;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbAnualIncome;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ToolStripMenuItem mnuDatabaseStatistics;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin_EditJobsPlan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbNbrTrxThisWeek;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbNbrSupplThisMonth;
        private System.Windows.Forms.Label lblNbrTEFAP;
        private System.Windows.Forms.TextBox tbNbrTEFAPThisMonth;
        private System.Windows.Forms.ToolStripMenuItem tsmiMoveHHMem;
        private System.Windows.Forms.ComboBox cboServiceMethod;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem tsmiResetPOAFlag;
        private System.Windows.Forms.ToolStripMenuItem tsmiResetNeedCommSigFlag;
        private System.Windows.Forms.ToolStripMenuItem tsmiResetInactiveFlag;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem tsmiCreateUnitedWayExport;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem tsmiKingCountyReport;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ComboBox cboHUDCategory;
        private System.Windows.Forms.Label lblHUDCategory;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tpgHD;
        private System.Windows.Forms.ComboBox cboHDItem;
        private System.Windows.Forms.Label lblHDItem;
        private System.Windows.Forms.ComboBox cboHDBuilding;
        private System.Windows.Forms.Label lblHDBuildings;
        private System.Windows.Forms.ComboBox cboHDPrograms;
        private System.Windows.Forms.Label lblHDPrograms;
        private System.Windows.Forms.ComboBox cboHDRoute;
        private System.Windows.Forms.Label lblHDRoute;
        private System.Windows.Forms.TextBox tbDriverNotes;
        private System.Windows.Forms.Label lblDriverNotes;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.MaskedTextBox tbPhone;
        private System.Windows.Forms.ToolStripMenuItem mnuHD;
        private System.Windows.Forms.ToolStripMenuItem mnuHD_Planner;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem mnuHD_FundingPrograms;
        private System.Windows.Forms.ToolStripMenuItem mnuHD_Buildings;
        private System.Windows.Forms.ToolStripMenuItem mnuHD_Routes;
        private System.Windows.Forms.PictureBox pbxEditAlert;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.ToolStripMenuItem tsmiToggleUserInfo;
        private System.Windows.Forms.Label lblHHModified;
        private System.Windows.Forms.Label lblHHCreated;
        private System.Windows.Forms.ToolStripMenuItem mnuWSDAFAP;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_NewSvcOverRide;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_NewService;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ColumnHeader clmCreateBy;
        private System.Windows.Forms.ToolStripMenuItem mnuClient_PrintAllClientcards;
        private System.Windows.Forms.TabPage tpgPointSys;
        private System.Windows.Forms.ListView lvwPoints;
        private System.Windows.Forms.ColumnHeader clmlblWkOf;
        private System.Windows.Forms.ColumnHeader clmWkOf;
        private System.Windows.Forms.TextBox tbpPoints;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_Backpack;
        private System.Windows.Forms.ToolStripMenuItem mnuTools_CSFPServices;
        private System.Windows.Forms.ToolStripButton tsbLog;
        private System.Windows.Forms.ColumnHeader clmBaby;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripMenuItem tsmiShowSignature;
        private System.Windows.Forms.PictureBox picSignature;
    }
}

