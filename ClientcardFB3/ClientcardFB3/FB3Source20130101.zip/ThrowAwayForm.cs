﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ClientCardFB3
{
    public partial class ThrowAwayForm : Form
    {
        public ThrowAwayForm()
        {
            InitializeComponent();


        }

        private void trash()
        {
            
            //cal.AddDateInfo(Pabo.Calendar.
        }
    }
}
