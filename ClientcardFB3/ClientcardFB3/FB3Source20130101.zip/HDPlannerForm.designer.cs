﻿namespace ClientcardFB3
{
    partial class HDPlannerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HDPlannerForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.rtplndgvHD = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.rtplncboOrderBy = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFilterBy = new System.Windows.Forms.Label();
            this.rtplncboFilter = new System.Windows.Forms.ComboBox();
            this.rtplntbFindName = new System.Windows.Forms.TextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.rtplnbtnSaveRoute = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.rtplnlbxRoutes = new System.Windows.Forms.ListBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbAdd = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.pnlRouteInfo = new System.Windows.Forms.Panel();
            this.rtplnmtbContactPhone = new System.Windows.Forms.MaskedTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.rtplntbFBContact = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.rtplntbRouteID = new System.Windows.Forms.TextBox();
            this.rtplntbRouteTitle = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rtplntbEstMiles = new System.Windows.Forms.TextBox();
            this.rtplntbEstTime = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rtplntbDriverNotes = new System.Windows.Forms.TextBox();
            this.rtplntbRouteNotes = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rtplnmtbPhone = new System.Windows.Forms.MaskedTextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.btnSelectDriver = new System.Windows.Forms.Button();
            this.rtplntbDriver = new System.Windows.Forms.TextBox();
            this.lblVolunteer = new System.Windows.Forms.Label();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.pnlFindClient = new System.Windows.Forms.Panel();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbAddress = new System.Windows.Forms.ToolStripButton();
            this.tsbApt = new System.Windows.Forms.ToolStripButton();
            this.tsbPhone = new System.Windows.Forms.ToolStripButton();
            this.tsbSize = new System.Windows.Forms.ToolStripButton();
            this.tsbComments = new System.Windows.Forms.ToolStripButton();
            this.tsbDriverNotes = new System.Windows.Forms.ToolStripButton();
            this.tsbSvcItem = new System.Windows.Forms.ToolStripButton();
            this.tsbLastSvc = new System.Windows.Forms.ToolStripButton();
            this.lblRowCnt = new System.Windows.Forms.Label();
            this.tabCtrl = new System.Windows.Forms.TabControl();
            this.tpgPlanner = new System.Windows.Forms.TabPage();
            this.tpgReview = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.lvwStatus = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label9 = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpServiceDate = new System.Windows.Forms.DateTimePicker();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.tsbPrepare = new System.Windows.Forms.ToolStripButton();
            this.tsbPrint = new System.Windows.Forms.ToolStripButton();
            this.tsbPost = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbShowRpts = new System.Windows.Forms.ToolStripButton();
            this.lvwRouteStatus = new System.Windows.Forms.ListView();
            this.colRouteTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNbrClients = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRouteID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.label10 = new System.Windows.Forms.Label();
            this.cboHistPeriod = new System.Windows.Forms.ComboBox();
            this.btnRefreshHist = new System.Windows.Forms.Button();
            this.lvwRouteHist = new System.Windows.Forms.ListView();
            this.colDelivDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNbrNC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNbrPrepared = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNbrPrinted = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNbrPosted = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpgEdit = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPost = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.toolStrip5 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.label21 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewComboBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmRouteID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmRouteTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmApt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmFamilySize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDriverNotes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmSvcItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmLastSvc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.rtplndgvHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.pnlRouteInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.pnlFindClient.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.tabCtrl.SuspendLayout();
            this.tpgPlanner.SuspendLayout();
            this.tpgReview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.tpgEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.panel2.SuspendLayout();
            this.toolStrip5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // rtplndgvHD
            // 
            this.rtplndgvHD.AllowUserToAddRows = false;
            this.rtplndgvHD.AllowUserToDeleteRows = false;
            this.rtplndgvHD.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rtplndgvHD.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.rtplndgvHD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.rtplndgvHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rtplndgvHD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmCnt,
            this.clmRouteID,
            this.clmRouteTitle,
            this.clmAddress,
            this.clmApt,
            this.clmID,
            this.clmName,
            this.clmPhone,
            this.clmFamilySize,
            this.clmComments,
            this.clmDriverNotes,
            this.clmSvcItem,
            this.clmLastSvc});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.rtplndgvHD.DefaultCellStyle = dataGridViewCellStyle11;
            this.rtplndgvHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtplndgvHD.Location = new System.Drawing.Point(0, 0);
            this.rtplndgvHD.Name = "rtplndgvHD";
            this.rtplndgvHD.RowHeadersVisible = false;
            this.rtplndgvHD.RowTemplate.Height = 24;
            this.rtplndgvHD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rtplndgvHD.Size = new System.Drawing.Size(970, 426);
            this.rtplndgvHD.TabIndex = 32;
            this.rtplndgvHD.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.rtplndgvHD_CellBeginEdit);
            this.rtplndgvHD.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.rtplndgvHD_CellDoubleClick);
            this.rtplndgvHD.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.rtplndgvHD_CellEndEdit);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 15);
            this.label1.TabIndex = 79;
            this.label1.Tag = "";
            this.label1.Text = "Find:";
            // 
            // rtplncboOrderBy
            // 
            this.rtplncboOrderBy.BackColor = System.Drawing.Color.OldLace;
            this.rtplncboOrderBy.DropDownHeight = 225;
            this.rtplncboOrderBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rtplncboOrderBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplncboOrderBy.ForeColor = System.Drawing.Color.Black;
            this.rtplncboOrderBy.FormattingEnabled = true;
            this.rtplncboOrderBy.IntegralHeight = false;
            this.rtplncboOrderBy.Items.AddRange(new object[] {
            "ID",
            "Client Name",
            "Address",
            "Apt. Number",
            "Last Service",
            "Phone",
            "Svc Item"});
            this.rtplncboOrderBy.Location = new System.Drawing.Point(243, 4);
            this.rtplncboOrderBy.Margin = new System.Windows.Forms.Padding(4);
            this.rtplncboOrderBy.Name = "rtplncboOrderBy";
            this.rtplncboOrderBy.Size = new System.Drawing.Size(162, 23);
            this.rtplncboOrderBy.TabIndex = 78;
            this.rtplncboOrderBy.SelectedIndexChanged += new System.EventHandler(this.rtplncboOrderBy_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(178, 7);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 77;
            this.label4.Tag = "SortOrder";
            this.label4.Text = "Order By:";
            // 
            // lblFilterBy
            // 
            this.lblFilterBy.AutoSize = true;
            this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilterBy.Location = new System.Drawing.Point(182, 32);
            this.lblFilterBy.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFilterBy.Name = "lblFilterBy";
            this.lblFilterBy.Size = new System.Drawing.Size(53, 15);
            this.lblFilterBy.TabIndex = 72;
            this.lblFilterBy.Tag = "SortOrder";
            this.lblFilterBy.Text = "Filter By:";
            // 
            // rtplncboFilter
            // 
            this.rtplncboFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rtplncboFilter.FormattingEnabled = true;
            this.rtplncboFilter.Location = new System.Drawing.Point(243, 29);
            this.rtplncboFilter.Margin = new System.Windows.Forms.Padding(4);
            this.rtplncboFilter.Name = "rtplncboFilter";
            this.rtplncboFilter.Size = new System.Drawing.Size(267, 24);
            this.rtplncboFilter.TabIndex = 73;
            this.rtplncboFilter.Visible = false;
            this.rtplncboFilter.SelectedIndexChanged += new System.EventHandler(this.rtplncboFilter_SelectedIndexChanged);
            // 
            // rtplntbFindName
            // 
            this.rtplntbFindName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.rtplntbFindName.HideSelection = false;
            this.rtplntbFindName.Location = new System.Drawing.Point(7, 18);
            this.rtplntbFindName.Margin = new System.Windows.Forms.Padding(4);
            this.rtplntbFindName.Name = "rtplntbFindName";
            this.rtplntbFindName.Size = new System.Drawing.Size(162, 24);
            this.rtplntbFindName.TabIndex = 70;
            this.rtplntbFindName.WordWrap = false;
            this.rtplntbFindName.TextChanged += new System.EventHandler(this.rtplntbFindName_TextChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(7, 18);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(159, 28);
            this.progressBar1.Step = 1;
            this.progressBar1.TabIndex = 76;
            this.progressBar1.Value = 1;
            this.progressBar1.Visible = false;
            // 
            // rtplnbtnSaveRoute
            // 
            this.rtplnbtnSaveRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplnbtnSaveRoute.Location = new System.Drawing.Point(647, 209);
            this.rtplnbtnSaveRoute.Name = "rtplnbtnSaveRoute";
            this.rtplnbtnSaveRoute.Size = new System.Drawing.Size(60, 30);
            this.rtplnbtnSaveRoute.TabIndex = 4;
            this.rtplnbtnSaveRoute.Text = "&Save";
            this.rtplnbtnSaveRoute.UseVisualStyleBackColor = true;
            this.rtplnbtnSaveRoute.Click += new System.EventHandler(this.rtplnbtnSaveRoute_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer5);
            this.splitContainer1.Panel1MinSize = 240;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer1.Size = new System.Drawing.Size(970, 749);
            this.splitContainer1.SplitterDistance = 253;
            this.splitContainer1.TabIndex = 85;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.rtplnlbxRoutes);
            this.splitContainer5.Panel1.Controls.Add(this.toolStrip1);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.pnlRouteInfo);
            this.splitContainer5.Size = new System.Drawing.Size(970, 253);
            this.splitContainer5.SplitterDistance = 232;
            this.splitContainer5.TabIndex = 0;
            // 
            // rtplnlbxRoutes
            // 
            this.rtplnlbxRoutes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtplnlbxRoutes.FormattingEnabled = true;
            this.rtplnlbxRoutes.ItemHeight = 16;
            this.rtplnlbxRoutes.Location = new System.Drawing.Point(0, 38);
            this.rtplnlbxRoutes.Name = "rtplnlbxRoutes";
            this.rtplnlbxRoutes.Size = new System.Drawing.Size(232, 215);
            this.rtplnlbxRoutes.TabIndex = 21;
            this.rtplnlbxRoutes.SelectedValueChanged += new System.EventHandler(this.rtplnlbxRoutes_SelectedValueChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAdd,
            this.tsbDelete});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(232, 38);
            this.toolStrip1.TabIndex = 22;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbAdd
            // 
            this.tsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsbAdd.Image")));
            this.tsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAdd.Name = "tsbAdd";
            this.tsbAdd.Size = new System.Drawing.Size(69, 35);
            this.tsbAdd.Text = "&New Route";
            this.tsbAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbAdd.Click += new System.EventHandler(this.tsbAdd_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(78, 35);
            this.tsbDelete.Text = "&Delete Route";
            this.tsbDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbDelete.ToolTipText = "Delete";
            // 
            // pnlRouteInfo
            // 
            this.pnlRouteInfo.BackColor = System.Drawing.Color.PaleGreen;
            this.pnlRouteInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRouteInfo.Controls.Add(this.rtplnmtbContactPhone);
            this.pnlRouteInfo.Controls.Add(this.label22);
            this.pnlRouteInfo.Controls.Add(this.rtplntbFBContact);
            this.pnlRouteInfo.Controls.Add(this.label23);
            this.pnlRouteInfo.Controls.Add(this.rtplntbRouteID);
            this.pnlRouteInfo.Controls.Add(this.rtplntbRouteTitle);
            this.pnlRouteInfo.Controls.Add(this.label11);
            this.pnlRouteInfo.Controls.Add(this.rtplntbEstMiles);
            this.pnlRouteInfo.Controls.Add(this.rtplntbEstTime);
            this.pnlRouteInfo.Controls.Add(this.label7);
            this.pnlRouteInfo.Controls.Add(this.label6);
            this.pnlRouteInfo.Controls.Add(this.rtplntbDriverNotes);
            this.pnlRouteInfo.Controls.Add(this.rtplntbRouteNotes);
            this.pnlRouteInfo.Controls.Add(this.rtplnbtnSaveRoute);
            this.pnlRouteInfo.Controls.Add(this.label5);
            this.pnlRouteInfo.Controls.Add(this.label3);
            this.pnlRouteInfo.Controls.Add(this.rtplnmtbPhone);
            this.pnlRouteInfo.Controls.Add(this.lblPhone);
            this.pnlRouteInfo.Controls.Add(this.btnSelectDriver);
            this.pnlRouteInfo.Controls.Add(this.rtplntbDriver);
            this.pnlRouteInfo.Controls.Add(this.lblVolunteer);
            this.pnlRouteInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRouteInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlRouteInfo.Name = "pnlRouteInfo";
            this.pnlRouteInfo.Size = new System.Drawing.Size(734, 253);
            this.pnlRouteInfo.TabIndex = 89;
            // 
            // rtplnmtbContactPhone
            // 
            this.rtplnmtbContactPhone.AllowPromptAsInput = false;
            this.rtplnmtbContactPhone.BeepOnError = true;
            this.rtplnmtbContactPhone.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplnmtbContactPhone.HidePromptOnLeave = true;
            this.rtplnmtbContactPhone.Location = new System.Drawing.Point(480, 64);
            this.rtplnmtbContactPhone.Mask = "(999) 000-0000 aaaaaaaaa";
            this.rtplnmtbContactPhone.Name = "rtplnmtbContactPhone";
            this.rtplnmtbContactPhone.Size = new System.Drawing.Size(165, 23);
            this.rtplnmtbContactPhone.TabIndex = 48;
            this.rtplnmtbContactPhone.Tag = "FBContactPhone";
            this.rtplnmtbContactPhone.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplnmtbContactPhone.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(369, 67);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(105, 17);
            this.label22.TabIndex = 47;
            this.label22.Text = "Contact Phone:";
            // 
            // rtplntbFBContact
            // 
            this.rtplntbFBContact.BackColor = System.Drawing.Color.White;
            this.rtplntbFBContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplntbFBContact.ForeColor = System.Drawing.Color.MediumBlue;
            this.rtplntbFBContact.Location = new System.Drawing.Point(99, 62);
            this.rtplntbFBContact.Name = "rtplntbFBContact";
            this.rtplntbFBContact.ReadOnly = true;
            this.rtplntbFBContact.Size = new System.Drawing.Size(213, 24);
            this.rtplntbFBContact.TabIndex = 45;
            this.rtplntbFBContact.TabStop = false;
            this.rtplntbFBContact.Tag = "FBContact";
            this.rtplntbFBContact.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbFBContact.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(2, 65);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 17);
            this.label23.TabIndex = 44;
            this.label23.Text = "FB Contact:";
            // 
            // rtplntbRouteID
            // 
            this.rtplntbRouteID.BackColor = System.Drawing.Color.Cornsilk;
            this.rtplntbRouteID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtplntbRouteID.Enabled = false;
            this.rtplntbRouteID.ForeColor = System.Drawing.Color.RoyalBlue;
            this.rtplntbRouteID.Location = new System.Drawing.Point(570, 216);
            this.rtplntbRouteID.Name = "rtplntbRouteID";
            this.rtplntbRouteID.Size = new System.Drawing.Size(60, 16);
            this.rtplntbRouteID.TabIndex = 43;
            this.rtplntbRouteID.TabStop = false;
            this.rtplntbRouteID.Tag = "id";
            this.rtplntbRouteID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rtplntbRouteTitle
            // 
            this.rtplntbRouteTitle.BackColor = System.Drawing.Color.White;
            this.rtplntbRouteTitle.ForeColor = System.Drawing.Color.Black;
            this.rtplntbRouteTitle.Location = new System.Drawing.Point(99, 3);
            this.rtplntbRouteTitle.Name = "rtplntbRouteTitle";
            this.rtplntbRouteTitle.Size = new System.Drawing.Size(249, 23);
            this.rtplntbRouteTitle.TabIndex = 41;
            this.rtplntbRouteTitle.Tag = "RouteTitle";
            this.rtplntbRouteTitle.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbRouteTitle.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 17);
            this.label11.TabIndex = 42;
            this.label11.Text = "Route Title:";
            // 
            // rtplntbEstMiles
            // 
            this.rtplntbEstMiles.Location = new System.Drawing.Point(647, 158);
            this.rtplntbEstMiles.Name = "rtplntbEstMiles";
            this.rtplntbEstMiles.Size = new System.Drawing.Size(54, 23);
            this.rtplntbEstMiles.TabIndex = 39;
            this.rtplntbEstMiles.Tag = "estmiles";
            this.rtplntbEstMiles.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rtplntbEstMiles.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbEstMiles.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // rtplntbEstTime
            // 
            this.rtplntbEstTime.Location = new System.Drawing.Point(647, 128);
            this.rtplntbEstTime.Name = "rtplntbEstTime";
            this.rtplntbEstTime.Size = new System.Drawing.Size(54, 23);
            this.rtplntbEstTime.TabIndex = 38;
            this.rtplntbEstTime.Tag = "esthours";
            this.rtplntbEstTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.rtplntbEstTime.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbEstTime.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(257, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 17);
            this.label7.TabIndex = 37;
            this.label7.Text = "Driver Notes:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 17);
            this.label6.TabIndex = 36;
            this.label6.Text = "Route Notes:";
            // 
            // rtplntbDriverNotes
            // 
            this.rtplntbDriverNotes.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplntbDriverNotes.Location = new System.Drawing.Point(260, 128);
            this.rtplntbDriverNotes.Multiline = true;
            this.rtplntbDriverNotes.Name = "rtplntbDriverNotes";
            this.rtplntbDriverNotes.Size = new System.Drawing.Size(291, 120);
            this.rtplntbDriverNotes.TabIndex = 35;
            this.rtplntbDriverNotes.Tag = "drivernotes";
            this.rtplntbDriverNotes.Text = "123456789012345678901234567890123456789";
            this.rtplntbDriverNotes.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbDriverNotes.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // rtplntbRouteNotes
            // 
            this.rtplntbRouteNotes.Location = new System.Drawing.Point(5, 128);
            this.rtplntbRouteNotes.Multiline = true;
            this.rtplntbRouteNotes.Name = "rtplntbRouteNotes";
            this.rtplntbRouteNotes.Size = new System.Drawing.Size(249, 120);
            this.rtplntbRouteNotes.TabIndex = 34;
            this.rtplntbRouteNotes.Tag = "notes";
            this.rtplntbRouteNotes.Text = "123456789012345678901234567890123456789";
            this.rtplntbRouteNotes.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbRouteNotes.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(567, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 32;
            this.label5.Text = "Est Miles:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(567, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 17);
            this.label3.TabIndex = 30;
            this.label3.Text = "Est Time:";
            // 
            // rtplnmtbPhone
            // 
            this.rtplnmtbPhone.AllowPromptAsInput = false;
            this.rtplnmtbPhone.BeepOnError = true;
            this.rtplnmtbPhone.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplnmtbPhone.HidePromptOnLeave = true;
            this.rtplnmtbPhone.Location = new System.Drawing.Point(480, 34);
            this.rtplnmtbPhone.Mask = "(999) 000-0000 aaaaaaaaa";
            this.rtplnmtbPhone.Name = "rtplnmtbPhone";
            this.rtplnmtbPhone.Size = new System.Drawing.Size(165, 23);
            this.rtplnmtbPhone.TabIndex = 29;
            this.rtplnmtbPhone.Tag = "phone";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(379, 37);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(95, 17);
            this.lblPhone.TabIndex = 3;
            this.lblPhone.Text = "Driver Phone:";
            // 
            // btnSelectDriver
            // 
            this.btnSelectDriver.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectDriver.Location = new System.Drawing.Point(318, 32);
            this.btnSelectDriver.Name = "btnSelectDriver";
            this.btnSelectDriver.Size = new System.Drawing.Size(29, 24);
            this.btnSelectDriver.TabIndex = 2;
            this.btnSelectDriver.Text = "...";
            this.btnSelectDriver.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSelectDriver.UseVisualStyleBackColor = true;
            // 
            // rtplntbDriver
            // 
            this.rtplntbDriver.BackColor = System.Drawing.Color.White;
            this.rtplntbDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtplntbDriver.ForeColor = System.Drawing.Color.MediumBlue;
            this.rtplntbDriver.Location = new System.Drawing.Point(99, 32);
            this.rtplntbDriver.Name = "rtplntbDriver";
            this.rtplntbDriver.ReadOnly = true;
            this.rtplntbDriver.Size = new System.Drawing.Size(213, 24);
            this.rtplntbDriver.TabIndex = 1;
            this.rtplntbDriver.TabStop = false;
            this.rtplntbDriver.Enter += new System.EventHandler(this.rtplntbRoute_Enter);
            this.rtplntbDriver.Leave += new System.EventHandler(this.rtplntbRoute_Leave);
            // 
            // lblVolunteer
            // 
            this.lblVolunteer.AutoSize = true;
            this.lblVolunteer.Location = new System.Drawing.Point(2, 35);
            this.lblVolunteer.Name = "lblVolunteer";
            this.lblVolunteer.Size = new System.Drawing.Size(92, 17);
            this.lblVolunteer.TabIndex = 0;
            this.lblVolunteer.Text = "Route Driver:";
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.BackColor = System.Drawing.Color.Beige;
            this.splitContainer6.Panel1.Controls.Add(this.pnlFindClient);
            this.splitContainer6.Panel1.Controls.Add(this.toolStrip2);
            this.splitContainer6.Panel1.Controls.Add(this.lblRowCnt);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.rtplndgvHD);
            this.splitContainer6.Size = new System.Drawing.Size(970, 492);
            this.splitContainer6.SplitterDistance = 62;
            this.splitContainer6.TabIndex = 0;
            // 
            // pnlFindClient
            // 
            this.pnlFindClient.Controls.Add(this.rtplntbFindName);
            this.pnlFindClient.Controls.Add(this.label4);
            this.pnlFindClient.Controls.Add(this.label1);
            this.pnlFindClient.Controls.Add(this.lblFilterBy);
            this.pnlFindClient.Controls.Add(this.rtplncboFilter);
            this.pnlFindClient.Controls.Add(this.rtplncboOrderBy);
            this.pnlFindClient.Controls.Add(this.progressBar1);
            this.pnlFindClient.Location = new System.Drawing.Point(442, 3);
            this.pnlFindClient.Name = "pnlFindClient";
            this.pnlFindClient.Size = new System.Drawing.Size(523, 57);
            this.pnlFindClient.TabIndex = 87;
            // 
            // toolStrip2
            // 
            this.toolStrip2.AllowMerge = false;
            this.toolStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAddress,
            this.tsbApt,
            this.tsbPhone,
            this.tsbSize,
            this.tsbComments,
            this.tsbDriverNotes,
            this.tsbSvcItem,
            this.tsbLastSvc});
            this.toolStrip2.Location = new System.Drawing.Point(3, 19);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(418, 25);
            this.toolStrip2.TabIndex = 138;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // tsbAddress
            // 
            this.tsbAddress.BackColor = System.Drawing.Color.Wheat;
            this.tsbAddress.Checked = true;
            this.tsbAddress.CheckOnClick = true;
            this.tsbAddress.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbAddress.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.tsbAddress.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbAddress.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddress.Image")));
            this.tsbAddress.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddress.Name = "tsbAddress";
            this.tsbAddress.Size = new System.Drawing.Size(53, 22);
            this.tsbAddress.Tag = "clmAddress";
            this.tsbAddress.Text = "Address";
            this.tsbAddress.ToolTipText = "Toggle Address and Apt columns";
            this.tsbAddress.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbApt
            // 
            this.tsbApt.BackColor = System.Drawing.Color.Wheat;
            this.tsbApt.Checked = true;
            this.tsbApt.CheckOnClick = true;
            this.tsbApt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbApt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbApt.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbApt.Image = ((System.Drawing.Image)(resources.GetObject("tsbApt.Image")));
            this.tsbApt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbApt.Name = "tsbApt";
            this.tsbApt.Size = new System.Drawing.Size(30, 22);
            this.tsbApt.Tag = "clmApt";
            this.tsbApt.Text = "Apt";
            this.tsbApt.ToolTipText = "Toggle Apt Column";
            this.tsbApt.Click += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbPhone
            // 
            this.tsbPhone.BackColor = System.Drawing.Color.Wheat;
            this.tsbPhone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tsbPhone.Checked = true;
            this.tsbPhone.CheckOnClick = true;
            this.tsbPhone.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbPhone.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.tsbPhone.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbPhone.Image = ((System.Drawing.Image)(resources.GetObject("tsbPhone.Image")));
            this.tsbPhone.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPhone.Name = "tsbPhone";
            this.tsbPhone.Size = new System.Drawing.Size(45, 22);
            this.tsbPhone.Tag = "clmPhone";
            this.tsbPhone.Text = "Phone";
            this.tsbPhone.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tsbPhone.ToolTipText = "Toggle Phone Column";
            this.tsbPhone.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbSize
            // 
            this.tsbSize.BackColor = System.Drawing.Color.Wheat;
            this.tsbSize.Checked = true;
            this.tsbSize.CheckOnClick = true;
            this.tsbSize.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSize.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.tsbSize.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbSize.Image = ((System.Drawing.Image)(resources.GetObject("tsbSize.Image")));
            this.tsbSize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSize.Name = "tsbSize";
            this.tsbSize.Size = new System.Drawing.Size(33, 22);
            this.tsbSize.Tag = "clmFamilySize";
            this.tsbSize.Text = "Size";
            this.tsbSize.ToolTipText = "Toggle Size column";
            this.tsbSize.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbComments
            // 
            this.tsbComments.BackColor = System.Drawing.Color.Wheat;
            this.tsbComments.Checked = true;
            this.tsbComments.CheckOnClick = true;
            this.tsbComments.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbComments.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbComments.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.tsbComments.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbComments.Image = ((System.Drawing.Image)(resources.GetObject("tsbComments.Image")));
            this.tsbComments.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbComments.Name = "tsbComments";
            this.tsbComments.Size = new System.Drawing.Size(69, 22);
            this.tsbComments.Tag = "clmComments";
            this.tsbComments.Text = "Comments";
            this.tsbComments.ToolTipText = "Toggle Comments column";
            this.tsbComments.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbDriverNotes
            // 
            this.tsbDriverNotes.BackColor = System.Drawing.Color.Wheat;
            this.tsbDriverNotes.Checked = true;
            this.tsbDriverNotes.CheckOnClick = true;
            this.tsbDriverNotes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbDriverNotes.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDriverNotes.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbDriverNotes.Image = ((System.Drawing.Image)(resources.GetObject("tsbDriverNotes.Image")));
            this.tsbDriverNotes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDriverNotes.Name = "tsbDriverNotes";
            this.tsbDriverNotes.Size = new System.Drawing.Size(76, 22);
            this.tsbDriverNotes.Tag = "clmDriverNotes";
            this.tsbDriverNotes.Text = "Driver Notes";
            this.tsbDriverNotes.ToolTipText = "Toggle Driver Notes column";
            this.tsbDriverNotes.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbSvcItem
            // 
            this.tsbSvcItem.BackColor = System.Drawing.Color.Wheat;
            this.tsbSvcItem.Checked = true;
            this.tsbSvcItem.CheckOnClick = true;
            this.tsbSvcItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbSvcItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSvcItem.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbSvcItem.Image = ((System.Drawing.Image)(resources.GetObject("tsbSvcItem.Image")));
            this.tsbSvcItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSvcItem.Name = "tsbSvcItem";
            this.tsbSvcItem.Size = new System.Drawing.Size(56, 22);
            this.tsbSvcItem.Tag = "clmsvcitem";
            this.tsbSvcItem.Text = "Svc Item";
            this.tsbSvcItem.ToolTipText = "Toggle Svc Item column";
            this.tsbSvcItem.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // tsbLastSvc
            // 
            this.tsbLastSvc.BackColor = System.Drawing.Color.Wheat;
            this.tsbLastSvc.Checked = true;
            this.tsbLastSvc.CheckOnClick = true;
            this.tsbLastSvc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbLastSvc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLastSvc.ForeColor = System.Drawing.Color.DarkBlue;
            this.tsbLastSvc.Image = ((System.Drawing.Image)(resources.GetObject("tsbLastSvc.Image")));
            this.tsbLastSvc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLastSvc.Name = "tsbLastSvc";
            this.tsbLastSvc.Size = new System.Drawing.Size(53, 22);
            this.tsbLastSvc.Tag = "clmLastSvc";
            this.tsbLastSvc.Text = "Last Svc";
            this.tsbLastSvc.ToolTipText = "Toggle Last Svc column";
            this.tsbLastSvc.CheckedChanged += new System.EventHandler(this.tsbToggle_CheckedChanged);
            // 
            // lblRowCnt
            // 
            this.lblRowCnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblRowCnt.AutoSize = true;
            this.lblRowCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRowCnt.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblRowCnt.Location = new System.Drawing.Point(0, 44);
            this.lblRowCnt.Name = "lblRowCnt";
            this.lblRowCnt.Size = new System.Drawing.Size(46, 17);
            this.lblRowCnt.TabIndex = 86;
            this.lblRowCnt.Text = "[ 23 ]";
            // 
            // tabCtrl
            // 
            this.tabCtrl.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabCtrl.Controls.Add(this.tpgPlanner);
            this.tabCtrl.Controls.Add(this.tpgReview);
            this.tabCtrl.Controls.Add(this.tpgEdit);
            this.tabCtrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtrl.Location = new System.Drawing.Point(0, 0);
            this.tabCtrl.Name = "tabCtrl";
            this.tabCtrl.SelectedIndex = 0;
            this.tabCtrl.Size = new System.Drawing.Size(984, 787);
            this.tabCtrl.TabIndex = 90;
            // 
            // tpgPlanner
            // 
            this.tpgPlanner.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.tpgPlanner.Controls.Add(this.splitContainer1);
            this.tpgPlanner.Location = new System.Drawing.Point(4, 28);
            this.tpgPlanner.Name = "tpgPlanner";
            this.tpgPlanner.Padding = new System.Windows.Forms.Padding(3);
            this.tpgPlanner.Size = new System.Drawing.Size(976, 755);
            this.tpgPlanner.TabIndex = 0;
            this.tpgPlanner.Text = "Route Planner";
            // 
            // tpgReview
            // 
            this.tpgReview.BackColor = System.Drawing.Color.Tan;
            this.tpgReview.Controls.Add(this.splitContainer2);
            this.tpgReview.Location = new System.Drawing.Point(4, 28);
            this.tpgReview.Name = "tpgReview";
            this.tpgReview.Padding = new System.Windows.Forms.Padding(3);
            this.tpgReview.Size = new System.Drawing.Size(976, 755);
            this.tpgReview.TabIndex = 1;
            this.tpgReview.Text = "Route Sheet Manager";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(970, 749);
            this.splitContainer2.SplitterDistance = 521;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.chkSelectAll);
            this.splitContainer3.Panel1.Controls.Add(this.lvwStatus);
            this.splitContainer3.Panel1.Controls.Add(this.label9);
            this.splitContainer3.Panel1.Controls.Add(this.btnLoad);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            this.splitContainer3.Panel1.Controls.Add(this.dtpServiceDate);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.toolStrip3);
            this.splitContainer3.Panel2.Controls.Add(this.lvwRouteStatus);
            this.splitContainer3.Size = new System.Drawing.Size(521, 749);
            this.splitContainer3.SplitterDistance = 165;
            this.splitContainer3.TabIndex = 0;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(3, 116);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(134, 21);
            this.chkSelectAll.TabIndex = 5;
            this.chkSelectAll.Text = "Select All Routes";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // lvwStatus
            // 
            this.lvwStatus.CheckBoxes = true;
            this.lvwStatus.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lvwStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvwStatus.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvwStatus.Location = new System.Drawing.Point(8, 23);
            this.lvwStatus.Name = "lvwStatus";
            this.lvwStatus.Size = new System.Drawing.Size(183, 87);
            this.lvwStatus.TabIndex = 4;
            this.lvwStatus.UseCompatibleStateImageBehavior = false;
            this.lvwStatus.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "StatusName";
            this.columnHeader1.Width = 170;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 17);
            this.label9.TabIndex = 3;
            this.label9.Text = "Status";
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(276, 56);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(166, 33);
            this.btnLoad.TabIndex = 2;
            this.btnLoad.Text = "Refresh Route List";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(227, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Delivery Date";
            // 
            // dtpServiceDate
            // 
            this.dtpServiceDate.Location = new System.Drawing.Point(230, 112);
            this.dtpServiceDate.Name = "dtpServiceDate";
            this.dtpServiceDate.Size = new System.Drawing.Size(243, 23);
            this.dtpServiceDate.TabIndex = 0;
            this.dtpServiceDate.ValueChanged += new System.EventHandler(this.dtpServiceDate_ValueChanged);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Dock = System.Windows.Forms.DockStyle.Right;
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbPrepare,
            this.tsbPrint,
            this.tsbPost,
            this.toolStripSeparator1,
            this.tsbShowRpts});
            this.toolStrip3.Location = new System.Drawing.Point(413, 0);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(108, 580);
            this.toolStrip3.TabIndex = 0;
            this.toolStrip3.Text = "toolStrip1";
            // 
            // tsbPrepare
            // 
            this.tsbPrepare.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrepare.Image")));
            this.tsbPrepare.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbPrepare.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbPrepare.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbPrepare.Name = "tsbPrepare";
            this.tsbPrepare.Size = new System.Drawing.Size(105, 51);
            this.tsbPrepare.Text = "&Create Route Lists";
            this.tsbPrepare.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbPrepare.Click += new System.EventHandler(this.tsbPrepare_Click);
            // 
            // tsbPrint
            // 
            this.tsbPrint.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrint.Image")));
            this.tsbPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbPrint.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbPrint.Name = "tsbPrint";
            this.tsbPrint.Size = new System.Drawing.Size(105, 51);
            this.tsbPrint.Text = "&Print Route Sheets";
            this.tsbPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbPrint.Click += new System.EventHandler(this.tsbPrint_Click);
            // 
            // tsbPost
            // 
            this.tsbPost.Image = ((System.Drawing.Image)(resources.GetObject("tsbPost.Image")));
            this.tsbPost.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbPost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbPost.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbPost.Name = "tsbPost";
            this.tsbPost.Size = new System.Drawing.Size(105, 51);
            this.tsbPost.Text = "&Record Services";
            this.tsbPost.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbPost.Click += new System.EventHandler(this.tsbPost_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(105, 6);
            // 
            // tsbShowRpts
            // 
            this.tsbShowRpts.Image = ((System.Drawing.Image)(resources.GetObject("tsbShowRpts.Image")));
            this.tsbShowRpts.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbShowRpts.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbShowRpts.ImageTransparentColor = System.Drawing.Color.Red;
            this.tsbShowRpts.Name = "tsbShowRpts";
            this.tsbShowRpts.Size = new System.Drawing.Size(105, 51);
            this.tsbShowRpts.Text = "&Display Sheets";
            this.tsbShowRpts.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbShowRpts.Click += new System.EventHandler(this.tsbShowRpts_Click);
            // 
            // lvwRouteStatus
            // 
            this.lvwRouteStatus.CheckBoxes = true;
            this.lvwRouteStatus.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colRouteTitle,
            this.colNbrClients,
            this.colStatus,
            this.colRouteID});
            this.lvwRouteStatus.Dock = System.Windows.Forms.DockStyle.Left;
            this.lvwRouteStatus.Location = new System.Drawing.Point(0, 0);
            this.lvwRouteStatus.Name = "lvwRouteStatus";
            this.lvwRouteStatus.Size = new System.Drawing.Size(408, 580);
            this.lvwRouteStatus.TabIndex = 0;
            this.lvwRouteStatus.UseCompatibleStateImageBehavior = false;
            this.lvwRouteStatus.View = System.Windows.Forms.View.Details;
            this.lvwRouteStatus.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.lvwRouteStatus_ItemChecked);
            // 
            // colRouteTitle
            // 
            this.colRouteTitle.Text = "Title";
            this.colRouteTitle.Width = 160;
            // 
            // colNbrClients
            // 
            this.colNbrClients.Text = "# Clients";
            this.colNbrClients.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colNbrClients.Width = 70;
            // 
            // colStatus
            // 
            this.colStatus.Text = "Status";
            this.colStatus.Width = 140;
            // 
            // colRouteID
            // 
            this.colRouteID.Text = "ID";
            this.colRouteID.Width = 0;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.BackColor = System.Drawing.Color.Wheat;
            this.splitContainer4.Panel1.Controls.Add(this.label10);
            this.splitContainer4.Panel1.Controls.Add(this.cboHistPeriod);
            this.splitContainer4.Panel1.Controls.Add(this.btnRefreshHist);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.lvwRouteHist);
            this.splitContainer4.Size = new System.Drawing.Size(445, 749);
            this.splitContainer4.SplitterDistance = 163;
            this.splitContainer4.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 23);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 17);
            this.label10.TabIndex = 87;
            this.label10.Tag = "";
            this.label10.Text = "Period:";
            // 
            // cboHistPeriod
            // 
            this.cboHistPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHistPeriod.FormattingEnabled = true;
            this.cboHistPeriod.Items.AddRange(new object[] {
            "4 Weeks",
            "Last Month",
            "Next Month",
            "This Month",
            "This Year",
            "Last Year",
            "All"});
            this.cboHistPeriod.Location = new System.Drawing.Point(14, 42);
            this.cboHistPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.cboHistPeriod.Name = "cboHistPeriod";
            this.cboHistPeriod.Size = new System.Drawing.Size(186, 24);
            this.cboHistPeriod.TabIndex = 86;
            // 
            // btnRefreshHist
            // 
            this.btnRefreshHist.Location = new System.Drawing.Point(236, 38);
            this.btnRefreshHist.Name = "btnRefreshHist";
            this.btnRefreshHist.Size = new System.Drawing.Size(78, 30);
            this.btnRefreshHist.TabIndex = 0;
            this.btnRefreshHist.Text = "Refresh";
            this.btnRefreshHist.UseVisualStyleBackColor = true;
            this.btnRefreshHist.Click += new System.EventHandler(this.btnRefreshHist_Click);
            // 
            // lvwRouteHist
            // 
            this.lvwRouteHist.BackColor = System.Drawing.Color.Wheat;
            this.lvwRouteHist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colDelivDate,
            this.colNbrNC,
            this.colNbrPrepared,
            this.colNbrPrinted,
            this.colNbrPosted});
            this.lvwRouteHist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwRouteHist.Location = new System.Drawing.Point(0, 0);
            this.lvwRouteHist.Name = "lvwRouteHist";
            this.lvwRouteHist.Size = new System.Drawing.Size(445, 582);
            this.lvwRouteHist.TabIndex = 0;
            this.lvwRouteHist.UseCompatibleStateImageBehavior = false;
            this.lvwRouteHist.View = System.Windows.Forms.View.Details;
            this.lvwRouteHist.DoubleClick += new System.EventHandler(this.lvwRouteHist_DoubleClick);
            // 
            // colDelivDate
            // 
            this.colDelivDate.Text = "Delivery Date";
            this.colDelivDate.Width = 100;
            // 
            // colNbrNC
            // 
            this.colNbrNC.Text = "Not Created";
            this.colNbrNC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colNbrNC.Width = 80;
            // 
            // colNbrPrepared
            // 
            this.colNbrPrepared.Text = "Prepared";
            this.colNbrPrepared.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colNbrPrepared.Width = 70;
            // 
            // colNbrPrinted
            // 
            this.colNbrPrinted.Text = "Printed";
            this.colNbrPrinted.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colNbrPrinted.Width = 80;
            // 
            // colNbrPosted
            // 
            this.colNbrPosted.Text = "Posted";
            this.colNbrPosted.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colNbrPosted.Width = 80;
            // 
            // tpgEdit
            // 
            this.tpgEdit.Controls.Add(this.splitContainer7);
            this.tpgEdit.Location = new System.Drawing.Point(4, 28);
            this.tpgEdit.Name = "tpgEdit";
            this.tpgEdit.Size = new System.Drawing.Size(976, 755);
            this.tpgEdit.TabIndex = 2;
            this.tpgEdit.Text = "Route Sheet Editor";
            this.tpgEdit.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.splitContainer8);
            this.splitContainer7.Panel1MinSize = 240;
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.splitContainer9);
            this.splitContainer7.Size = new System.Drawing.Size(976, 758);
            this.splitContainer7.SplitterDistance = 253;
            this.splitContainer7.TabIndex = 86;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.listBox1);
            this.splitContainer8.Panel1.Controls.Add(this.toolStrip4);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.panel1);
            this.splitContainer8.Size = new System.Drawing.Size(976, 253);
            this.splitContainer8.SplitterDistance = 318;
            this.splitContainer8.TabIndex = 0;
            // 
            // listBox1
            // 
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(0, 38);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(318, 215);
            this.listBox1.TabIndex = 21;
            // 
            // toolStrip4
            // 
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip4.Location = new System.Drawing.Point(0, 0);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(318, 38);
            this.toolStrip4.TabIndex = 22;
            this.toolStrip4.Text = "toolStrip4";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(69, 35);
            this.toolStripButton1.Text = "&New Route";
            this.toolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(78, 35);
            this.toolStripButton2.Text = "&Delete Route";
            this.toolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton2.ToolTipText = "Delete";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnPost);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.maskedTextBox1);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(654, 253);
            this.panel1.TabIndex = 89;
            // 
            // btnPost
            // 
            this.btnPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPost.Location = new System.Drawing.Point(568, 163);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(60, 30);
            this.btnPost.TabIndex = 44;
            this.btnPost.Text = "&Post";
            this.btnPost.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Enabled = false;
            this.textBox1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.textBox1.Location = new System.Drawing.Point(567, 105);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(60, 16);
            this.textBox1.TabIndex = 43;
            this.textBox1.TabStop = false;
            this.textBox1.Tag = "id";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox2.ForeColor = System.Drawing.Color.MediumBlue;
            this.textBox2.Location = new System.Drawing.Point(99, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(249, 23);
            this.textBox2.TabIndex = 41;
            this.textBox2.Tag = "RouteTitle";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 42;
            this.label2.Text = "Route Title:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(497, 62);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(54, 23);
            this.textBox3.TabIndex = 39;
            this.textBox3.Tag = "estmiles";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(497, 32);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(54, 23);
            this.textBox4.TabIndex = 38;
            this.textBox4.Tag = "esthours";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(257, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 17);
            this.label12.TabIndex = 37;
            this.label12.Text = "Driver Notes:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 108);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 17);
            this.label13.TabIndex = 36;
            this.label13.Text = "Route Notes:";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(260, 128);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(291, 120);
            this.textBox5.TabIndex = 35;
            this.textBox5.Tag = "drivernotes";
            this.textBox5.Text = "123456789012345678901234567890123456789";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(5, 128);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(249, 120);
            this.textBox6.TabIndex = 34;
            this.textBox6.Tag = "notes";
            this.textBox6.Text = "123456789012345678901234567890123456789";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(567, 127);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 30);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(406, 65);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 17);
            this.label14.TabIndex = 32;
            this.label14.Text = "Actual Miles:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(405, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 17);
            this.label15.TabIndex = 30;
            this.label15.Text = "Actual Time:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.AllowPromptAsInput = false;
            this.maskedTextBox1.BeepOnError = true;
            this.maskedTextBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox1.HidePromptOnLeave = true;
            this.maskedTextBox1.Location = new System.Drawing.Point(99, 62);
            this.maskedTextBox1.Mask = "(999) 000-0000 aaaaaaaaa";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(165, 23);
            this.maskedTextBox1.TabIndex = 29;
            this.maskedTextBox1.Tag = "phone";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(-2, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "Driver Phone:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(318, 32);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(29, 24);
            this.button2.TabIndex = 2;
            this.button2.Text = "...";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.DarkBlue;
            this.textBox7.Location = new System.Drawing.Point(99, 32);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(213, 24);
            this.textBox7.TabIndex = 1;
            this.textBox7.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(2, 35);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Route Driver:";
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.BackColor = System.Drawing.Color.Beige;
            this.splitContainer9.Panel1.Controls.Add(this.panel2);
            this.splitContainer9.Panel1.Controls.Add(this.toolStrip5);
            this.splitContainer9.Panel1.Controls.Add(this.label21);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer9.Size = new System.Drawing.Size(976, 501);
            this.splitContainer9.SplitterDistance = 62;
            this.splitContainer9.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.progressBar2);
            this.panel2.Location = new System.Drawing.Point(442, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(523, 57);
            this.panel2.TabIndex = 87;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.textBox8.HideSelection = false;
            this.textBox8.Location = new System.Drawing.Point(7, 18);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(162, 24);
            this.textBox8.TabIndex = 70;
            this.textBox8.WordWrap = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(178, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 15);
            this.label18.TabIndex = 77;
            this.label18.Tag = "SortOrder";
            this.label18.Text = "Order By:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(34, 15);
            this.label19.TabIndex = 79;
            this.label19.Tag = "";
            this.label19.Text = "Find:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(345, 2);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 15);
            this.label20.TabIndex = 72;
            this.label20.Tag = "SortOrder";
            this.label20.Text = "Filter By:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(347, 19);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(162, 24);
            this.comboBox1.TabIndex = 73;
            this.comboBox1.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.OldLace;
            this.comboBox2.DropDownHeight = 225;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.ForeColor = System.Drawing.Color.Black;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.IntegralHeight = false;
            this.comboBox2.Items.AddRange(new object[] {
            "ID",
            "Client Name",
            "Address",
            "Apt. Number",
            "Last Service",
            "Phone"});
            this.comboBox2.Location = new System.Drawing.Point(177, 19);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(162, 23);
            this.comboBox2.TabIndex = 78;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(7, 18);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(159, 28);
            this.progressBar2.Step = 1;
            this.progressBar2.TabIndex = 76;
            this.progressBar2.Value = 1;
            this.progressBar2.Visible = false;
            // 
            // toolStrip5
            // 
            this.toolStrip5.AllowMerge = false;
            this.toolStrip5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.toolStrip5.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip5.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton10});
            this.toolStrip5.Location = new System.Drawing.Point(3, 19);
            this.toolStrip5.Name = "toolStrip5";
            this.toolStrip5.Size = new System.Drawing.Size(418, 25);
            this.toolStrip5.TabIndex = 138;
            this.toolStrip5.Text = "toolStrip5";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton3.Checked = true;
            this.toolStripButton3.CheckOnClick = true;
            this.toolStripButton3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.toolStripButton3.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(53, 22);
            this.toolStripButton3.Tag = "clmAddress";
            this.toolStripButton3.Text = "Address";
            this.toolStripButton3.ToolTipText = "Toggle Address and Apt columns";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton4.Checked = true;
            this.toolStripButton4.CheckOnClick = true;
            this.toolStripButton4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton4.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(30, 22);
            this.toolStripButton4.Tag = "clmApt";
            this.toolStripButton4.Text = "Apt";
            this.toolStripButton4.ToolTipText = "Toggle Apt Column";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.toolStripButton5.Checked = true;
            this.toolStripButton5.CheckOnClick = true;
            this.toolStripButton5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton5.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.toolStripButton5.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(45, 22);
            this.toolStripButton5.Tag = "clmPhone";
            this.toolStripButton5.Text = "Phone";
            this.toolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButton5.ToolTipText = "Toggle Phone Column";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton6.Checked = true;
            this.toolStripButton6.CheckOnClick = true;
            this.toolStripButton6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.toolStripButton6.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(33, 22);
            this.toolStripButton6.Tag = "clmFamilySize";
            this.toolStripButton6.Text = "Size";
            this.toolStripButton6.ToolTipText = "Toggle Size column";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton7.Checked = true;
            this.toolStripButton7.CheckOnClick = true;
            this.toolStripButton7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F);
            this.toolStripButton7.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(69, 22);
            this.toolStripButton7.Tag = "clmComments";
            this.toolStripButton7.Text = "Comments";
            this.toolStripButton7.ToolTipText = "Toggle Comments column";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton8.Checked = true;
            this.toolStripButton8.CheckOnClick = true;
            this.toolStripButton8.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton8.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(76, 22);
            this.toolStripButton8.Tag = "clmDriverNotes";
            this.toolStripButton8.Text = "Driver Notes";
            this.toolStripButton8.ToolTipText = "Toggle Driver Notes column";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton9.Checked = true;
            this.toolStripButton9.CheckOnClick = true;
            this.toolStripButton9.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton9.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(56, 22);
            this.toolStripButton9.Tag = "clmsvcitem";
            this.toolStripButton9.Text = "Svc Item";
            this.toolStripButton9.ToolTipText = "Toggle Svc Item column";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.BackColor = System.Drawing.Color.Wheat;
            this.toolStripButton10.Checked = true;
            this.toolStripButton10.CheckOnClick = true;
            this.toolStripButton10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton10.ForeColor = System.Drawing.Color.DarkBlue;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(53, 22);
            this.toolStripButton10.Tag = "clmLastSvc";
            this.toolStripButton10.Text = "Last Svc";
            this.toolStripButton10.ToolTipText = "Toggle Last Svc column";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label21.Location = new System.Drawing.Point(0, 44);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 17);
            this.label21.TabIndex = 86;
            this.label21.Text = "[ 23 ]";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewComboBoxColumn1,
            this.dataGridViewTextBoxColumn22});
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.PaleGoldenrod;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(976, 435);
            this.dataGridView1.TabIndex = 32;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle13.NullValue = false;
            this.dataGridViewCheckBoxColumn1.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewCheckBoxColumn1.Frozen = true;
            this.dataGridViewCheckBoxColumn1.HeaderText = "sel";
            this.dataGridViewCheckBoxColumn1.MinimumWidth = 30;
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Width = 30;
            // 
            // dataGridViewComboBoxColumn1
            // 
            this.dataGridViewComboBoxColumn1.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewComboBoxColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataGridViewComboBoxColumn1.HeaderText = "Svc Item";
            this.dataGridViewComboBoxColumn1.Name = "dataGridViewComboBoxColumn1";
            this.dataGridViewComboBoxColumn1.ReadOnly = true;
            this.dataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "Household Name";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 40;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 250;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn2.HeaderText = "Address";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 60;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridViewTextBoxColumn3.HeaderText = "Apt.";
            this.dataGridViewTextBoxColumn3.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 28;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn4.HeaderText = "City";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn4.Width = 180;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewTextBoxColumn5.HeaderText = "Route";
            this.dataGridViewTextBoxColumn5.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn5.Width = 54;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewTextBoxColumn6.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn6.MaxInputLength = 40;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn6.Visible = false;
            this.dataGridViewTextBoxColumn6.Width = 52;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.HeaderText = "Date Served";
            this.dataGridViewTextBoxColumn7.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewTextBoxColumn8.HeaderText = "ID";
            this.dataGridViewTextBoxColumn8.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn8.Width = 74;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn9.HeaderText = "Size";
            this.dataGridViewTextBoxColumn9.MaxInputLength = 300;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn9.Width = 60;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn10.HeaderText = "Date Served";
            this.dataGridViewTextBoxColumn10.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn10.Width = 160;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn11.HeaderText = "Comments";
            this.dataGridViewTextBoxColumn11.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn11.Width = 160;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn12.HeaderText = "RouteID";
            this.dataGridViewTextBoxColumn12.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn12.Visible = false;
            this.dataGridViewTextBoxColumn12.Width = 84;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn13.HeaderText = "Rt";
            this.dataGridViewTextBoxColumn13.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn13.Visible = false;
            this.dataGridViewTextBoxColumn13.Width = 47;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn14.HeaderText = "Address";
            this.dataGridViewTextBoxColumn14.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 85;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewTextBoxColumn15.HeaderText = "Apt";
            this.dataGridViewTextBoxColumn15.MaxInputLength = 40;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn15.Visible = false;
            this.dataGridViewTextBoxColumn15.Width = 54;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridViewTextBoxColumn16.HeaderText = "Hh ID";
            this.dataGridViewTextBoxColumn16.MaxInputLength = 40;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn16.Visible = false;
            this.dataGridViewTextBoxColumn16.Width = 68;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridViewTextBoxColumn17.HeaderText = "Client Name";
            this.dataGridViewTextBoxColumn17.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn17.Visible = false;
            this.dataGridViewTextBoxColumn17.Width = 109;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn18.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn18.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn18.Visible = false;
            this.dataGridViewTextBoxColumn18.Width = 74;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridViewTextBoxColumn19.HeaderText = "Size";
            this.dataGridViewTextBoxColumn19.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn19.Visible = false;
            this.dataGridViewTextBoxColumn19.Width = 60;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridViewTextBoxColumn20.HeaderText = "Comments";
            this.dataGridViewTextBoxColumn20.MaxInputLength = 300;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn20.Visible = false;
            this.dataGridViewTextBoxColumn20.Width = 99;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn21.HeaderText = "Driver Notes";
            this.dataGridViewTextBoxColumn21.MaxInputLength = 300;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn21.Width = 112;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridViewTextBoxColumn22.HeaderText = "Last Svc";
            this.dataGridViewTextBoxColumn22.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn22.Width = 87;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn23.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn23.HeaderText = "Last Svc";
            this.dataGridViewTextBoxColumn23.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn23.Width = 103;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn24.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn24.HeaderText = "Last Svc";
            this.dataGridViewTextBoxColumn24.MaxInputLength = 10;
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn24.Width = 60;
            // 
            // clmCnt
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            this.clmCnt.DefaultCellStyle = dataGridViewCellStyle2;
            this.clmCnt.Frozen = true;
            this.clmCnt.HeaderText = "";
            this.clmCnt.MinimumWidth = 40;
            this.clmCnt.Name = "clmCnt";
            this.clmCnt.ReadOnly = true;
            this.clmCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clmCnt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.clmCnt.Width = 40;
            // 
            // clmRouteID
            // 
            this.clmRouteID.HeaderText = "RouteID";
            this.clmRouteID.Name = "clmRouteID";
            this.clmRouteID.ReadOnly = true;
            this.clmRouteID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmRouteID.Visible = false;
            this.clmRouteID.Width = 60;
            // 
            // clmRouteTitle
            // 
            this.clmRouteTitle.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clmRouteTitle.DefaultCellStyle = dataGridViewCellStyle3;
            this.clmRouteTitle.HeaderText = "Rt";
            this.clmRouteTitle.Name = "clmRouteTitle";
            this.clmRouteTitle.ReadOnly = true;
            this.clmRouteTitle.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmRouteTitle.Visible = false;
            this.clmRouteTitle.Width = 28;
            // 
            // clmAddress
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.clmAddress.DefaultCellStyle = dataGridViewCellStyle4;
            this.clmAddress.HeaderText = "Address";
            this.clmAddress.MaxInputLength = 50;
            this.clmAddress.Name = "clmAddress";
            this.clmAddress.ReadOnly = true;
            this.clmAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmAddress.Width = 180;
            // 
            // clmApt
            // 
            this.clmApt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clmApt.DefaultCellStyle = dataGridViewCellStyle5;
            this.clmApt.HeaderText = "Apt";
            this.clmApt.MaxInputLength = 40;
            this.clmApt.Name = "clmApt";
            this.clmApt.ReadOnly = true;
            this.clmApt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmApt.Width = 54;
            // 
            // clmID
            // 
            this.clmID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clmID.DefaultCellStyle = dataGridViewCellStyle6;
            this.clmID.HeaderText = "Hh ID";
            this.clmID.Name = "clmID";
            this.clmID.ReadOnly = true;
            this.clmID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmID.Width = 68;
            // 
            // clmName
            // 
            this.clmName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmName.HeaderText = "Client Name";
            this.clmName.MaxInputLength = 50;
            this.clmName.Name = "clmName";
            this.clmName.ReadOnly = true;
            this.clmName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmName.Width = 109;
            // 
            // clmPhone
            // 
            this.clmPhone.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.clmPhone.HeaderText = "Phone";
            this.clmPhone.MaxInputLength = 50;
            this.clmPhone.Name = "clmPhone";
            this.clmPhone.ReadOnly = true;
            this.clmPhone.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmPhone.Width = 74;
            // 
            // clmFamilySize
            // 
            this.clmFamilySize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clmFamilySize.DefaultCellStyle = dataGridViewCellStyle7;
            this.clmFamilySize.HeaderText = "Size";
            this.clmFamilySize.Name = "clmFamilySize";
            this.clmFamilySize.ReadOnly = true;
            this.clmFamilySize.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmFamilySize.Width = 60;
            // 
            // clmComments
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.clmComments.DefaultCellStyle = dataGridViewCellStyle8;
            this.clmComments.HeaderText = "Comments";
            this.clmComments.MaxInputLength = 300;
            this.clmComments.Name = "clmComments";
            this.clmComments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmComments.Width = 160;
            // 
            // clmDriverNotes
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.clmDriverNotes.DefaultCellStyle = dataGridViewCellStyle9;
            this.clmDriverNotes.HeaderText = "Driver Notes";
            this.clmDriverNotes.Name = "clmDriverNotes";
            this.clmDriverNotes.Width = 160;
            // 
            // clmSvcItem
            // 
            this.clmSvcItem.HeaderText = "Svc Item";
            this.clmSvcItem.Name = "clmSvcItem";
            this.clmSvcItem.ReadOnly = true;
            this.clmSvcItem.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clmSvcItem.Width = 60;
            // 
            // clmLastSvc
            // 
            this.clmLastSvc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.clmLastSvc.DefaultCellStyle = dataGridViewCellStyle10;
            this.clmLastSvc.HeaderText = "Last Svc";
            this.clmLastSvc.MaxInputLength = 10;
            this.clmLastSvc.Name = "clmLastSvc";
            this.clmLastSvc.ReadOnly = true;
            this.clmLastSvc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.clmLastSvc.Width = 87;
            // 
            // HDPlannerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(984, 787);
            this.Controls.Add(this.tabCtrl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1000, 700);
            this.Name = "HDPlannerForm";
            this.Text = "Home Delivery Form";
            this.Resize += new System.EventHandler(this.EditHDForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.rtplndgvHD)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pnlRouteInfo.ResumeLayout(false);
            this.pnlRouteInfo.PerformLayout();
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.pnlFindClient.ResumeLayout(false);
            this.pnlFindClient.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.tabCtrl.ResumeLayout(false);
            this.tpgPlanner.ResumeLayout(false);
            this.tpgReview.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.tpgEdit.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.toolStrip5.ResumeLayout(false);
            this.toolStrip5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView rtplndgvHD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox rtplncboOrderBy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblFilterBy;
        private System.Windows.Forms.ComboBox rtplncboFilter;
        public System.Windows.Forms.TextBox rtplntbFindName;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button rtplnbtnSaveRoute;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lblRowCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.Panel pnlFindClient;
        private System.Windows.Forms.Panel pnlRouteInfo;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Button btnSelectDriver;
        private System.Windows.Forms.TextBox rtplntbDriver;
        private System.Windows.Forms.Label lblVolunteer;
        private System.Windows.Forms.MaskedTextBox rtplnmtbPhone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox rtplntbDriverNotes;
        private System.Windows.Forms.TextBox rtplntbRouteNotes;
        private System.Windows.Forms.TabControl tabCtrl;
        private System.Windows.Forms.TabPage tpgPlanner;
        private System.Windows.Forms.TabPage tpgReview;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbAddress;
        private System.Windows.Forms.ToolStripButton tsbPhone;
        private System.Windows.Forms.ToolStripButton tsbSize;
        private System.Windows.Forms.ToolStripButton tsbComments;
        private System.Windows.Forms.ToolStripButton tsbDriverNotes;
        private System.Windows.Forms.ToolStripButton tsbSvcItem;
        private System.Windows.Forms.ToolStripButton tsbLastSvc;
        private System.Windows.Forms.ToolStripButton tsbApt;
        private System.Windows.Forms.TextBox rtplntbEstTime;
        private System.Windows.Forms.TextBox rtplntbEstMiles;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.ListView lvwStatus;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpServiceDate;
        private System.Windows.Forms.ListView lvwRouteStatus;
        private System.Windows.Forms.ColumnHeader colRouteTitle;
        private System.Windows.Forms.ColumnHeader colNbrClients;
        private System.Windows.Forms.ColumnHeader colStatus;
        private System.Windows.Forms.ColumnHeader colRouteID;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton tsbPrepare;
        private System.Windows.Forms.ToolStripButton tsbPrint;
        private System.Windows.Forms.ToolStripButton tsbPost;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Button btnRefreshHist;
        private System.Windows.Forms.ListView lvwRouteHist;
        private System.Windows.Forms.ColumnHeader colDelivDate;
        private System.Windows.Forms.ColumnHeader colNbrPrepared;
        private System.Windows.Forms.ColumnHeader colNbrPrinted;
        private System.Windows.Forms.ColumnHeader colNbrPosted;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboHistPeriod;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbShowRpts;
        private System.Windows.Forms.ColumnHeader colNbrNC;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.ListBox rtplnlbxRoutes;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbAdd;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.TextBox rtplntbRouteTitle;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox rtplntbRouteID;
        private System.Windows.Forms.TabPage tpgEdit;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPost;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ToolStrip toolStrip5;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.MaskedTextBox rtplnmtbContactPhone;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox rtplntbFBContact;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmRouteID;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmRouteTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmApt;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmID;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmPhone;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmFamilySize;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDriverNotes;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmSvcItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmLastSvc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
    }
}