﻿namespace ClientcardFB3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlHHPvYrMonth = new System.Windows.Forms.Panel();
            this.tbHHPvY2YTDStdReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDStdNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDStd = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDHomeless = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimitsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDHomelessNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimitsNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDHomelessReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransientReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOther = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServedNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentMale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransientNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServed = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOther = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDSingleMale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServedReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleFemale = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDSingleFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplementalReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimits = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplementalNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransient = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodityReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcs = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodityNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplemental = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodity = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcsNew = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDParentMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleMaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentMaleNew = new System.Windows.Forms.TextBox();
            this.lblHHPvYrMonth = new System.Windows.Forms.Label();
            this.pnlHHPvYrMonth.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHHPvYrMonth
            // 
            this.pnlHHPvYrMonth.BackColor = System.Drawing.Color.Cornsilk;
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDStdReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDStdNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDStd);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDHomeless);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDInCityLimitsReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDHomelessNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDInCityLimitsNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDHomelessReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTransientReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentOther);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTotalServedNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentMale);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTransientNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentFemale);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTotalServed);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleOther);
            this.pnlHHPvYrMonth.Controls.Add(this.label87);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleMale);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTotalServedReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleFemale);
            this.pnlHHPvYrMonth.Controls.Add(this.label86);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleFemaleReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentFemaleReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleFemaleNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSupplementalReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentOtherReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentFemaleNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDInCityLimits);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSupplementalNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDTransient);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDCommodityReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDBabySvcs);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleOtherNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentOtherNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDCommodityNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSupplemental);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDBabySvcsReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDCommodity);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleOtherReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleMaleReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDBabySvcsNew);
            this.pnlHHPvYrMonth.Controls.Add(this.label84);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDParentMaleReturning);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDSingleMaleNew);
            this.pnlHHPvYrMonth.Controls.Add(this.tbHHPvY2YTDOneParentMaleNew);
            this.pnlHHPvYrMonth.Controls.Add(this.lblHHPvYrMonth);
            this.pnlHHPvYrMonth.Location = new System.Drawing.Point(412, 12);
            this.pnlHHPvYrMonth.Name = "pnlHHPvYrMonth";
            this.pnlHHPvYrMonth.Size = new System.Drawing.Size(200, 422);
            this.pnlHHPvYrMonth.TabIndex = 281;
            // 
            // tbHHPvY2YTDStdReturning
            // 
            this.tbHHPvY2YTDStdReturning.AccessibleName = "";
            this.tbHHPvY2YTDStdReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDStdReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDStdReturning.Location = new System.Drawing.Point(68, 62);
            this.tbHHPvY2YTDStdReturning.Name = "tbHHPvY2YTDStdReturning";
            this.tbHHPvY2YTDStdReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDStdReturning.TabIndex = 226;
            this.tbHHPvY2YTDStdReturning.Tag = "HHRcvdStdReturning";
            this.tbHHPvY2YTDStdReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDStdNew
            // 
            this.tbHHPvY2YTDStdNew.AccessibleName = "";
            this.tbHHPvY2YTDStdNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDStdNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDStdNew.Location = new System.Drawing.Point(4, 62);
            this.tbHHPvY2YTDStdNew.Name = "tbHHPvY2YTDStdNew";
            this.tbHHPvY2YTDStdNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDStdNew.TabIndex = 225;
            this.tbHHPvY2YTDStdNew.Tag = "HHRcvdStdNew";
            this.tbHHPvY2YTDStdNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDStd
            // 
            this.tbHHPvY2YTDStd.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDStd.Location = new System.Drawing.Point(135, 62);
            this.tbHHPvY2YTDStd.Name = "tbHHPvY2YTDStd";
            this.tbHHPvY2YTDStd.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDStd.TabIndex = 227;
            this.tbHHPvY2YTDStd.Tag = "HHRcvdStd";
            this.tbHHPvY2YTDStd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDHomeless
            // 
            this.tbHHPvY2YTDHomeless.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomeless.Location = new System.Drawing.Point(134, 176);
            this.tbHHPvY2YTDHomeless.Name = "tbHHPvY2YTDHomeless";
            this.tbHHPvY2YTDHomeless.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDHomeless.TabIndex = 224;
            this.tbHHPvY2YTDHomeless.Tag = "HHHomeless";
            this.tbHHPvY2YTDHomeless.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimitsReturning
            // 
            this.tbHHPvY2YTDInCityLimitsReturning.AccessibleName = "";
            this.tbHHPvY2YTDInCityLimitsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimitsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimitsReturning.Location = new System.Drawing.Point(67, 224);
            this.tbHHPvY2YTDInCityLimitsReturning.Name = "tbHHPvY2YTDInCityLimitsReturning";
            this.tbHHPvY2YTDInCityLimitsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDInCityLimitsReturning.TabIndex = 189;
            this.tbHHPvY2YTDInCityLimitsReturning.Tag = "HHInCityLimitsReturning";
            this.tbHHPvY2YTDInCityLimitsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDHomelessNew
            // 
            this.tbHHPvY2YTDHomelessNew.AccessibleName = "";
            this.tbHHPvY2YTDHomelessNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomelessNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomelessNew.Location = new System.Drawing.Point(4, 176);
            this.tbHHPvY2YTDHomelessNew.Name = "tbHHPvY2YTDHomelessNew";
            this.tbHHPvY2YTDHomelessNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDHomelessNew.TabIndex = 223;
            this.tbHHPvY2YTDHomelessNew.Tag = "HHHomelessNew";
            this.tbHHPvY2YTDHomelessNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimitsNew
            // 
            this.tbHHPvY2YTDInCityLimitsNew.AccessibleName = "";
            this.tbHHPvY2YTDInCityLimitsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimitsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimitsNew.Location = new System.Drawing.Point(4, 224);
            this.tbHHPvY2YTDInCityLimitsNew.Name = "tbHHPvY2YTDInCityLimitsNew";
            this.tbHHPvY2YTDInCityLimitsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDInCityLimitsNew.TabIndex = 188;
            this.tbHHPvY2YTDInCityLimitsNew.Tag = "HHInCityLimitsNew";
            this.tbHHPvY2YTDInCityLimitsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDHomelessReturning
            // 
            this.tbHHPvY2YTDHomelessReturning.AccessibleName = "";
            this.tbHHPvY2YTDHomelessReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomelessReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomelessReturning.Location = new System.Drawing.Point(67, 176);
            this.tbHHPvY2YTDHomelessReturning.Name = "tbHHPvY2YTDHomelessReturning";
            this.tbHHPvY2YTDHomelessReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDHomelessReturning.TabIndex = 222;
            this.tbHHPvY2YTDHomelessReturning.Tag = "HHHomelessReturning";
            this.tbHHPvY2YTDHomelessReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransientReturning
            // 
            this.tbHHPvY2YTDTransientReturning.AccessibleName = "";
            this.tbHHPvY2YTDTransientReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransientReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransientReturning.Location = new System.Drawing.Point(67, 200);
            this.tbHHPvY2YTDTransientReturning.Name = "tbHHPvY2YTDTransientReturning";
            this.tbHHPvY2YTDTransientReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTransientReturning.TabIndex = 186;
            this.tbHHPvY2YTDTransientReturning.Tag = "HHTransientReturning";
            this.tbHHPvY2YTDTransientReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOther
            // 
            this.tbHHPvY2YTDOneParentOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOther.Location = new System.Drawing.Point(134, 399);
            this.tbHHPvY2YTDOneParentOther.Name = "tbHHPvY2YTDOneParentOther";
            this.tbHHPvY2YTDOneParentOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentOther.TabIndex = 221;
            this.tbHHPvY2YTDOneParentOther.Tag = "HHOneParentOther";
            this.tbHHPvY2YTDOneParentOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServedNew
            // 
            this.tbHHPvY2YTDTotalServedNew.AccessibleName = "";
            this.tbHHPvY2YTDTotalServedNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServedNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServedNew.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvY2YTDTotalServedNew.Location = new System.Drawing.Point(3, 111);
            this.tbHHPvY2YTDTotalServedNew.Name = "tbHHPvY2YTDTotalServedNew";
            this.tbHHPvY2YTDTotalServedNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTotalServedNew.TabIndex = 185;
            this.tbHHPvY2YTDTotalServedNew.Tag = "HHTotalServedNew";
            this.tbHHPvY2YTDTotalServedNew.Text = "500,569";
            this.tbHHPvY2YTDTotalServedNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentMale
            // 
            this.tbHHPvY2YTDOneParentMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentMale.Location = new System.Drawing.Point(134, 377);
            this.tbHHPvY2YTDOneParentMale.Name = "tbHHPvY2YTDOneParentMale";
            this.tbHHPvY2YTDOneParentMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentMale.TabIndex = 220;
            this.tbHHPvY2YTDOneParentMale.Tag = "HHOneParentMale";
            this.tbHHPvY2YTDOneParentMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransientNew
            // 
            this.tbHHPvY2YTDTransientNew.AccessibleName = "";
            this.tbHHPvY2YTDTransientNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransientNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransientNew.Location = new System.Drawing.Point(4, 200);
            this.tbHHPvY2YTDTransientNew.Name = "tbHHPvY2YTDTransientNew";
            this.tbHHPvY2YTDTransientNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTransientNew.TabIndex = 187;
            this.tbHHPvY2YTDTransientNew.Tag = "HHTransientNew";
            this.tbHHPvY2YTDTransientNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemale
            // 
            this.tbHHPvY2YTDOneParentFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemale.Location = new System.Drawing.Point(134, 354);
            this.tbHHPvY2YTDOneParentFemale.Name = "tbHHPvY2YTDOneParentFemale";
            this.tbHHPvY2YTDOneParentFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentFemale.TabIndex = 219;
            this.tbHHPvY2YTDOneParentFemale.Tag = "HHOneParentFemale";
            this.tbHHPvY2YTDOneParentFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServed
            // 
            this.tbHHPvY2YTDTotalServed.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServed.Location = new System.Drawing.Point(133, 111);
            this.tbHHPvY2YTDTotalServed.Name = "tbHHPvY2YTDTotalServed";
            this.tbHHPvY2YTDTotalServed.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDTotalServed.TabIndex = 190;
            this.tbHHPvY2YTDTotalServed.Tag = "HHTotalServed";
            this.tbHHPvY2YTDTotalServed.Text = "356,987";
            this.tbHHPvY2YTDTotalServed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOther
            // 
            this.tbHHPvY2YTDSingleOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOther.Location = new System.Drawing.Point(133, 312);
            this.tbHHPvY2YTDSingleOther.Name = "tbHHPvY2YTDSingleOther";
            this.tbHHPvY2YTDSingleOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleOther.TabIndex = 218;
            this.tbHHPvY2YTDSingleOther.Tag = "HHSingleOther";
            this.tbHHPvY2YTDSingleOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label87
            // 
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.Color.Black;
            this.label87.Location = new System.Drawing.Point(3, 18);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(60, 18);
            this.label87.TabIndex = 184;
            this.label87.Text = "New";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDSingleMale
            // 
            this.tbHHPvY2YTDSingleMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMale.Location = new System.Drawing.Point(133, 290);
            this.tbHHPvY2YTDSingleMale.Name = "tbHHPvY2YTDSingleMale";
            this.tbHHPvY2YTDSingleMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleMale.TabIndex = 217;
            this.tbHHPvY2YTDSingleMale.Tag = "HHSingleMale";
            this.tbHHPvY2YTDSingleMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServedReturning
            // 
            this.tbHHPvY2YTDTotalServedReturning.AccessibleName = "";
            this.tbHHPvY2YTDTotalServedReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServedReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServedReturning.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvY2YTDTotalServedReturning.Location = new System.Drawing.Point(66, 111);
            this.tbHHPvY2YTDTotalServedReturning.Name = "tbHHPvY2YTDTotalServedReturning";
            this.tbHHPvY2YTDTotalServedReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTotalServedReturning.TabIndex = 183;
            this.tbHHPvY2YTDTotalServedReturning.Tag = "HHTotalServedReturning";
            this.tbHHPvY2YTDTotalServedReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleFemale
            // 
            this.tbHHPvY2YTDSingleFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemale.Location = new System.Drawing.Point(133, 268);
            this.tbHHPvY2YTDSingleFemale.Name = "tbHHPvY2YTDSingleFemale";
            this.tbHHPvY2YTDSingleFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleFemale.TabIndex = 216;
            this.tbHHPvY2YTDSingleFemale.Tag = "HHSingleFemale";
            this.tbHHPvY2YTDSingleFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label86
            // 
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.Black;
            this.label86.Location = new System.Drawing.Point(66, 18);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(60, 18);
            this.label86.TabIndex = 182;
            this.label86.Text = "Returning";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDSingleFemaleReturning
            // 
            this.tbHHPvY2YTDSingleFemaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemaleReturning.Location = new System.Drawing.Point(66, 268);
            this.tbHHPvY2YTDSingleFemaleReturning.Name = "tbHHPvY2YTDSingleFemaleReturning";
            this.tbHHPvY2YTDSingleFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleFemaleReturning.TabIndex = 193;
            this.tbHHPvY2YTDSingleFemaleReturning.Tag = "HHSingleFemaleReturning";
            this.tbHHPvY2YTDSingleFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemaleReturning
            // 
            this.tbHHPvY2YTDOneParentFemaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDOneParentFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemaleReturning.Location = new System.Drawing.Point(67, 354);
            this.tbHHPvY2YTDOneParentFemaleReturning.Name = "tbHHPvY2YTDOneParentFemaleReturning";
            this.tbHHPvY2YTDOneParentFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentFemaleReturning.TabIndex = 199;
            this.tbHHPvY2YTDOneParentFemaleReturning.Tag = "HHOneParentFemaleReturning";
            this.tbHHPvY2YTDOneParentFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleFemaleNew
            // 
            this.tbHHPvY2YTDSingleFemaleNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemaleNew.Location = new System.Drawing.Point(3, 268);
            this.tbHHPvY2YTDSingleFemaleNew.Name = "tbHHPvY2YTDSingleFemaleNew";
            this.tbHHPvY2YTDSingleFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleFemaleNew.TabIndex = 192;
            this.tbHHPvY2YTDSingleFemaleNew.Tag = "HHSingleFemaleNew";
            this.tbHHPvY2YTDSingleFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplementalReturning
            // 
            this.tbHHPvY2YTDSupplementalReturning.AccessibleName = "";
            this.tbHHPvY2YTDSupplementalReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplementalReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplementalReturning.Location = new System.Drawing.Point(67, 86);
            this.tbHHPvY2YTDSupplementalReturning.Name = "tbHHPvY2YTDSupplementalReturning";
            this.tbHHPvY2YTDSupplementalReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSupplementalReturning.TabIndex = 207;
            this.tbHHPvY2YTDSupplementalReturning.Tag = "HHRcvdSupplementalReturning";
            this.tbHHPvY2YTDSupplementalReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOtherReturning
            // 
            this.tbHHPvY2YTDOneParentOtherReturning.AccessibleName = "";
            this.tbHHPvY2YTDOneParentOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOtherReturning.Location = new System.Drawing.Point(67, 399);
            this.tbHHPvY2YTDOneParentOtherReturning.Name = "tbHHPvY2YTDOneParentOtherReturning";
            this.tbHHPvY2YTDOneParentOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentOtherReturning.TabIndex = 203;
            this.tbHHPvY2YTDOneParentOtherReturning.Tag = "HHOneParentOtherReturning";
            this.tbHHPvY2YTDOneParentOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemaleNew
            // 
            this.tbHHPvY2YTDOneParentFemaleNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemaleNew.Location = new System.Drawing.Point(4, 354);
            this.tbHHPvY2YTDOneParentFemaleNew.Name = "tbHHPvY2YTDOneParentFemaleNew";
            this.tbHHPvY2YTDOneParentFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentFemaleNew.TabIndex = 198;
            this.tbHHPvY2YTDOneParentFemaleNew.Tag = "HHOneParentFemaleNew";
            this.tbHHPvY2YTDOneParentFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimits
            // 
            this.tbHHPvY2YTDInCityLimits.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimits.Location = new System.Drawing.Point(134, 224);
            this.tbHHPvY2YTDInCityLimits.Name = "tbHHPvY2YTDInCityLimits";
            this.tbHHPvY2YTDInCityLimits.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDInCityLimits.TabIndex = 215;
            this.tbHHPvY2YTDInCityLimits.Tag = "HHInCityLimits";
            this.tbHHPvY2YTDInCityLimits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplementalNew
            // 
            this.tbHHPvY2YTDSupplementalNew.AccessibleName = "";
            this.tbHHPvY2YTDSupplementalNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplementalNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplementalNew.Location = new System.Drawing.Point(3, 86);
            this.tbHHPvY2YTDSupplementalNew.Name = "tbHHPvY2YTDSupplementalNew";
            this.tbHHPvY2YTDSupplementalNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSupplementalNew.TabIndex = 206;
            this.tbHHPvY2YTDSupplementalNew.Tag = "HHRcvdSupplementalNew";
            this.tbHHPvY2YTDSupplementalNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransient
            // 
            this.tbHHPvY2YTDTransient.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransient.Location = new System.Drawing.Point(134, 200);
            this.tbHHPvY2YTDTransient.Name = "tbHHPvY2YTDTransient";
            this.tbHHPvY2YTDTransient.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDTransient.TabIndex = 214;
            this.tbHHPvY2YTDTransient.Tag = "HHTransient";
            this.tbHHPvY2YTDTransient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodityReturning
            // 
            this.tbHHPvY2YTDCommodityReturning.AccessibleName = "";
            this.tbHHPvY2YTDCommodityReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodityReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodityReturning.Location = new System.Drawing.Point(67, 38);
            this.tbHHPvY2YTDCommodityReturning.Name = "tbHHPvY2YTDCommodityReturning";
            this.tbHHPvY2YTDCommodityReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDCommodityReturning.TabIndex = 204;
            this.tbHHPvY2YTDCommodityReturning.Tag = "HHRcvdCommodityReturning";
            this.tbHHPvY2YTDCommodityReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcs
            // 
            this.tbHHPvY2YTDBabySvcs.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcs.Location = new System.Drawing.Point(134, 152);
            this.tbHHPvY2YTDBabySvcs.Name = "tbHHPvY2YTDBabySvcs";
            this.tbHHPvY2YTDBabySvcs.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDBabySvcs.TabIndex = 213;
            this.tbHHPvY2YTDBabySvcs.Tag = "HHRcvdBabyServices";
            this.tbHHPvY2YTDBabySvcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOtherNew
            // 
            this.tbHHPvY2YTDSingleOtherNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOtherNew.Location = new System.Drawing.Point(3, 312);
            this.tbHHPvY2YTDSingleOtherNew.Name = "tbHHPvY2YTDSingleOtherNew";
            this.tbHHPvY2YTDSingleOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleOtherNew.TabIndex = 196;
            this.tbHHPvY2YTDSingleOtherNew.Tag = "HHSingleOtherNew";
            this.tbHHPvY2YTDSingleOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOtherNew
            // 
            this.tbHHPvY2YTDOneParentOtherNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOtherNew.Location = new System.Drawing.Point(4, 399);
            this.tbHHPvY2YTDOneParentOtherNew.Name = "tbHHPvY2YTDOneParentOtherNew";
            this.tbHHPvY2YTDOneParentOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentOtherNew.TabIndex = 202;
            this.tbHHPvY2YTDOneParentOtherNew.Tag = "HHOneParentOtherNew";
            this.tbHHPvY2YTDOneParentOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodityNew
            // 
            this.tbHHPvY2YTDCommodityNew.AccessibleName = "";
            this.tbHHPvY2YTDCommodityNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodityNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodityNew.Location = new System.Drawing.Point(4, 38);
            this.tbHHPvY2YTDCommodityNew.Name = "tbHHPvY2YTDCommodityNew";
            this.tbHHPvY2YTDCommodityNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDCommodityNew.TabIndex = 205;
            this.tbHHPvY2YTDCommodityNew.Tag = "HHRcvdCommodityNew";
            this.tbHHPvY2YTDCommodityNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplemental
            // 
            this.tbHHPvY2YTDSupplemental.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplemental.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplemental.Location = new System.Drawing.Point(134, 86);
            this.tbHHPvY2YTDSupplemental.Name = "tbHHPvY2YTDSupplemental";
            this.tbHHPvY2YTDSupplemental.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSupplemental.TabIndex = 212;
            this.tbHHPvY2YTDSupplemental.Tag = "HHRcvdSupplemental";
            this.tbHHPvY2YTDSupplemental.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcsReturning
            // 
            this.tbHHPvY2YTDBabySvcsReturning.AccessibleName = "";
            this.tbHHPvY2YTDBabySvcsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcsReturning.Location = new System.Drawing.Point(67, 152);
            this.tbHHPvY2YTDBabySvcsReturning.Name = "tbHHPvY2YTDBabySvcsReturning";
            this.tbHHPvY2YTDBabySvcsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDBabySvcsReturning.TabIndex = 209;
            this.tbHHPvY2YTDBabySvcsReturning.Tag = "HHRcvdBabyServicesReturning";
            this.tbHHPvY2YTDBabySvcsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodity
            // 
            this.tbHHPvY2YTDCommodity.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodity.Location = new System.Drawing.Point(134, 38);
            this.tbHHPvY2YTDCommodity.Name = "tbHHPvY2YTDCommodity";
            this.tbHHPvY2YTDCommodity.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDCommodity.TabIndex = 211;
            this.tbHHPvY2YTDCommodity.Tag = "HHRcvdCommodity";
            this.tbHHPvY2YTDCommodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOtherReturning
            // 
            this.tbHHPvY2YTDSingleOtherReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOtherReturning.Location = new System.Drawing.Point(66, 312);
            this.tbHHPvY2YTDSingleOtherReturning.Name = "tbHHPvY2YTDSingleOtherReturning";
            this.tbHHPvY2YTDSingleOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleOtherReturning.TabIndex = 197;
            this.tbHHPvY2YTDSingleOtherReturning.Tag = "HHSingleOtherReturning";
            this.tbHHPvY2YTDSingleOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleMaleReturning
            // 
            this.tbHHPvY2YTDSingleMaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMaleReturning.Location = new System.Drawing.Point(66, 290);
            this.tbHHPvY2YTDSingleMaleReturning.Name = "tbHHPvY2YTDSingleMaleReturning";
            this.tbHHPvY2YTDSingleMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleMaleReturning.TabIndex = 195;
            this.tbHHPvY2YTDSingleMaleReturning.Tag = "HHSingleMaleReturning";
            this.tbHHPvY2YTDSingleMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcsNew
            // 
            this.tbHHPvY2YTDBabySvcsNew.AccessibleName = "";
            this.tbHHPvY2YTDBabySvcsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcsNew.Location = new System.Drawing.Point(4, 152);
            this.tbHHPvY2YTDBabySvcsNew.Name = "tbHHPvY2YTDBabySvcsNew";
            this.tbHHPvY2YTDBabySvcsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDBabySvcsNew.TabIndex = 208;
            this.tbHHPvY2YTDBabySvcsNew.Tag = "HHRcvdBabyServicesNew";
            this.tbHHPvY2YTDBabySvcsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label84
            // 
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.Color.Black;
            this.label84.Location = new System.Drawing.Point(133, 18);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(60, 18);
            this.label84.TabIndex = 210;
            this.label84.Text = "Total";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDParentMaleReturning
            // 
            this.tbHHPvY2YTDParentMaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDParentMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDParentMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDParentMaleReturning.Location = new System.Drawing.Point(67, 377);
            this.tbHHPvY2YTDParentMaleReturning.Name = "tbHHPvY2YTDParentMaleReturning";
            this.tbHHPvY2YTDParentMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDParentMaleReturning.TabIndex = 201;
            this.tbHHPvY2YTDParentMaleReturning.Tag = "HHOneParentMaleReturning";
            this.tbHHPvY2YTDParentMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleMaleNew
            // 
            this.tbHHPvY2YTDSingleMaleNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMaleNew.Location = new System.Drawing.Point(3, 290);
            this.tbHHPvY2YTDSingleMaleNew.Name = "tbHHPvY2YTDSingleMaleNew";
            this.tbHHPvY2YTDSingleMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleMaleNew.TabIndex = 194;
            this.tbHHPvY2YTDSingleMaleNew.Tag = "HHSingleMaleNew";
            this.tbHHPvY2YTDSingleMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentMaleNew
            // 
            this.tbHHPvY2YTDOneParentMaleNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentMaleNew.Location = new System.Drawing.Point(4, 377);
            this.tbHHPvY2YTDOneParentMaleNew.Name = "tbHHPvY2YTDOneParentMaleNew";
            this.tbHHPvY2YTDOneParentMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentMaleNew.TabIndex = 200;
            this.tbHHPvY2YTDOneParentMaleNew.Tag = "HHOneParentMaleNew";
            this.tbHHPvY2YTDOneParentMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblHHPvYrMonth
            // 
            this.lblHHPvYrMonth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHHPvYrMonth.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHHPvYrMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHPvYrMonth.ForeColor = System.Drawing.Color.Black;
            this.lblHHPvYrMonth.Location = new System.Drawing.Point(0, 0);
            this.lblHHPvYrMonth.Name = "lblHHPvYrMonth";
            this.lblHHPvYrMonth.Size = new System.Drawing.Size(200, 19);
            this.lblHHPvYrMonth.TabIndex = 191;
            this.lblHHPvYrMonth.Text = "Previous Year";
            this.lblHHPvYrMonth.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 628);
            this.Controls.Add(this.pnlHHPvYrMonth);
            this.Name = "Form3";
            this.Text = "Form3";
            this.pnlHHPvYrMonth.ResumeLayout(false);
            this.pnlHHPvYrMonth.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHHPvYrMonth;
        private System.Windows.Forms.TextBox tbHHPvY2YTDStdReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDStdNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDStd;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomeless;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimitsReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomelessNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimitsNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomelessReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransientReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOther;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServedNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentMale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransientNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServed;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOther;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServedReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemale;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplementalReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimits;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplementalNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransient;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodityReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcs;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOtherNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOtherNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodityNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplemental;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcsReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodity;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcsNew;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox tbHHPvY2YTDParentMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentMaleNew;
        private System.Windows.Forms.Label lblHHPvYrMonth;

    }
}