﻿namespace ClientcardFB3
{
    partial class VoucherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tbEighteen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboClientType = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbInfants = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbYouth = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTeens = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbAdults = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSeniors = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbTotalFam = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbDiet = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbDisabled = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.chkInCityLimits = new System.Windows.Forms.CheckBox();
            this.chkHomeless = new System.Windows.Forms.CheckBox();
            this.btnPost = new System.Windows.Forms.Button();
            this.dtpTrxDate = new System.Windows.Forms.DateTimePicker();
            this.tbClient = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.gridVouchers = new System.Windows.Forms.DataGridView();
            this.clmDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAmntRcvd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAmntAvail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmEnable = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.clmAmountGiven = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmDefaultAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridVouchers)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tbEighteen);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.cboClientType);
            this.splitContainer1.Panel1.Controls.Add(this.label20);
            this.splitContainer1.Panel1.Controls.Add(this.tbInfants);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.tbYouth);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.tbTeens);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.tbAdults);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.tbSeniors);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.tbTotalFam);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.tbDiet);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.tbDisabled);
            this.splitContainer1.Panel1.Controls.Add(this.label11);
            this.splitContainer1.Panel1.Controls.Add(this.chkInCityLimits);
            this.splitContainer1.Panel1.Controls.Add(this.chkHomeless);
            this.splitContainer1.Panel1.Controls.Add(this.btnPost);
            this.splitContainer1.Panel1.Controls.Add(this.dtpTrxDate);
            this.splitContainer1.Panel1.Controls.Add(this.tbClient);
            this.splitContainer1.Panel1.Controls.Add(this.btnClose);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gridVouchers);
            this.splitContainer1.Size = new System.Drawing.Size(927, 476);
            this.splitContainer1.SplitterDistance = 165;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 0;
            // 
            // tbEighteen
            // 
            this.tbEighteen.Location = new System.Drawing.Point(460, 74);
            this.tbEighteen.Margin = new System.Windows.Forms.Padding(4);
            this.tbEighteen.Name = "tbEighteen";
            this.tbEighteen.Size = new System.Drawing.Size(41, 23);
            this.tbEighteen.TabIndex = 164;
            this.tbEighteen.Tag = "Eighteen";
            this.tbEighteen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(457, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 165;
            this.label2.Text = "18\'s";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboClientType
            // 
            this.cboClientType.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboClientType.FormattingEnabled = true;
            this.cboClientType.ItemHeight = 13;
            this.cboClientType.Location = new System.Drawing.Point(405, 7);
            this.cboClientType.Margin = new System.Windows.Forms.Padding(4);
            this.cboClientType.Name = "cboClientType";
            this.cboClientType.Size = new System.Drawing.Size(177, 21);
            this.cboClientType.TabIndex = 157;
            this.cboClientType.Tag = "ClientType";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(311, 8);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 17);
            this.label20.TabIndex = 144;
            this.label20.Text = "Hh Category:";
            // 
            // tbInfants
            // 
            this.tbInfants.Location = new System.Drawing.Point(319, 74);
            this.tbInfants.Margin = new System.Windows.Forms.Padding(4);
            this.tbInfants.Name = "tbInfants";
            this.tbInfants.Size = new System.Drawing.Size(41, 23);
            this.tbInfants.TabIndex = 145;
            this.tbInfants.Tag = "Infants";
            this.tbInfants.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(316, 54);
            this.label3.Margin = new System.Windows.Forms.Padding(0, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 151;
            this.label3.Text = "Infants";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbYouth
            // 
            this.tbYouth.Location = new System.Drawing.Point(367, 73);
            this.tbYouth.Margin = new System.Windows.Forms.Padding(4);
            this.tbYouth.Name = "tbYouth";
            this.tbYouth.Size = new System.Drawing.Size(41, 23);
            this.tbYouth.TabIndex = 146;
            this.tbYouth.Tag = "Youth";
            this.tbYouth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(364, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 152;
            this.label4.Text = "Youth";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTeens
            // 
            this.tbTeens.Location = new System.Drawing.Point(415, 74);
            this.tbTeens.Margin = new System.Windows.Forms.Padding(4);
            this.tbTeens.Name = "tbTeens";
            this.tbTeens.Size = new System.Drawing.Size(41, 23);
            this.tbTeens.TabIndex = 147;
            this.tbTeens.Tag = "Teens";
            this.tbTeens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(412, 54);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 17);
            this.label5.TabIndex = 153;
            this.label5.Text = "Teens";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbAdults
            // 
            this.tbAdults.Location = new System.Drawing.Point(505, 74);
            this.tbAdults.Margin = new System.Windows.Forms.Padding(4);
            this.tbAdults.Name = "tbAdults";
            this.tbAdults.Size = new System.Drawing.Size(41, 23);
            this.tbAdults.TabIndex = 148;
            this.tbAdults.Tag = "Adults";
            this.tbAdults.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(502, 56);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 154;
            this.label6.Text = "Adults";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbSeniors
            // 
            this.tbSeniors.Location = new System.Drawing.Point(548, 75);
            this.tbSeniors.Margin = new System.Windows.Forms.Padding(4);
            this.tbSeniors.Name = "tbSeniors";
            this.tbSeniors.Size = new System.Drawing.Size(41, 23);
            this.tbSeniors.TabIndex = 149;
            this.tbSeniors.Tag = "Seniors";
            this.tbSeniors.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(545, 55);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 17);
            this.label7.TabIndex = 155;
            this.label7.Text = "Seniors:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTotalFam
            // 
            this.tbTotalFam.BackColor = System.Drawing.Color.Cornsilk;
            this.tbTotalFam.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTotalFam.ForeColor = System.Drawing.Color.Blue;
            this.tbTotalFam.Location = new System.Drawing.Point(602, 75);
            this.tbTotalFam.Margin = new System.Windows.Forms.Padding(4);
            this.tbTotalFam.Name = "tbTotalFam";
            this.tbTotalFam.ReadOnly = true;
            this.tbTotalFam.Size = new System.Drawing.Size(41, 22);
            this.tbTotalFam.TabIndex = 150;
            this.tbTotalFam.TabStop = false;
            this.tbTotalFam.Tag = "TotalFamily";
            this.tbTotalFam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(599, 50);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 25);
            this.label9.TabIndex = 156;
            this.label9.Text = "Total Family";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbDiet
            // 
            this.tbDiet.Location = new System.Drawing.Point(319, 108);
            this.tbDiet.Margin = new System.Windows.Forms.Padding(4);
            this.tbDiet.Name = "tbDiet";
            this.tbDiet.Size = new System.Drawing.Size(41, 23);
            this.tbDiet.TabIndex = 158;
            this.tbDiet.Tag = "SpecialDiet";
            this.tbDiet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(364, 110);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 160;
            this.label10.Text = "Special Diet";
            // 
            // tbDisabled
            // 
            this.tbDisabled.Location = new System.Drawing.Point(319, 134);
            this.tbDisabled.Margin = new System.Windows.Forms.Padding(4);
            this.tbDisabled.Name = "tbDisabled";
            this.tbDisabled.Size = new System.Drawing.Size(41, 23);
            this.tbDisabled.TabIndex = 159;
            this.tbDisabled.Tag = "Disabled";
            this.tbDisabled.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(362, 137);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 13);
            this.label11.TabIndex = 161;
            this.label11.Text = "Disabled";
            // 
            // chkInCityLimits
            // 
            this.chkInCityLimits.AutoSize = true;
            this.chkInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkInCityLimits.Location = new System.Drawing.Point(614, 8);
            this.chkInCityLimits.Margin = new System.Windows.Forms.Padding(4);
            this.chkInCityLimits.Name = "chkInCityLimits";
            this.chkInCityLimits.Size = new System.Drawing.Size(84, 17);
            this.chkInCityLimits.TabIndex = 162;
            this.chkInCityLimits.Tag = "InCityLimits";
            this.chkInCityLimits.Text = "In City Limits";
            this.chkInCityLimits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkInCityLimits.UseVisualStyleBackColor = true;
            // 
            // chkHomeless
            // 
            this.chkHomeless.AutoSize = true;
            this.chkHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHomeless.Location = new System.Drawing.Point(614, 36);
            this.chkHomeless.Margin = new System.Windows.Forms.Padding(4);
            this.chkHomeless.Name = "chkHomeless";
            this.chkHomeless.Size = new System.Drawing.Size(72, 17);
            this.chkHomeless.TabIndex = 163;
            this.chkHomeless.Tag = "Homeless";
            this.chkHomeless.Text = "Homeless";
            this.chkHomeless.UseVisualStyleBackColor = true;
            // 
            // btnPost
            // 
            this.btnPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnPost.Location = new System.Drawing.Point(576, 118);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(122, 24);
            this.btnPost.TabIndex = 143;
            this.btnPost.Text = "Post Demographics";
            this.btnPost.UseVisualStyleBackColor = true;
            // 
            // dtpTrxDate
            // 
            this.dtpTrxDate.Location = new System.Drawing.Point(80, 117);
            this.dtpTrxDate.Name = "dtpTrxDate";
            this.dtpTrxDate.Size = new System.Drawing.Size(224, 23);
            this.dtpTrxDate.TabIndex = 103;
            this.dtpTrxDate.ValueChanged += new System.EventHandler(this.dtpTrxDate_ValueChanged);
            this.dtpTrxDate.Validated += new System.EventHandler(this.dtpTrxDate_Validated);
            // 
            // tbClient
            // 
            this.tbClient.BackColor = System.Drawing.Color.LightYellow;
            this.tbClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbClient.Location = new System.Drawing.Point(8, 8);
            this.tbClient.Multiline = true;
            this.tbClient.Name = "tbClient";
            this.tbClient.ReadOnly = true;
            this.tbClient.Size = new System.Drawing.Size(296, 96);
            this.tbClient.TabIndex = 102;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnClose.Location = new System.Drawing.Point(878, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(45, 27);
            this.btnClose.TabIndex = 100;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 117);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 17);
            this.label8.TabIndex = 98;
            this.label8.Text = "Trx Date";
            // 
            // gridVouchers
            // 
            this.gridVouchers.AllowUserToAddRows = false;
            this.gridVouchers.AllowUserToDeleteRows = false;
            this.gridVouchers.AllowUserToOrderColumns = true;
            this.gridVouchers.AllowUserToResizeRows = false;
            this.gridVouchers.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.gridVouchers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridVouchers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridVouchers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridVouchers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmDesc,
            this.clmAmntRcvd,
            this.clmAmntAvail,
            this.clmEnable,
            this.clmAmountGiven,
            this.clmComments,
            this.clmDefaultAmount});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Beige;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridVouchers.DefaultCellStyle = dataGridViewCellStyle7;
            this.gridVouchers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridVouchers.Location = new System.Drawing.Point(0, 0);
            this.gridVouchers.MultiSelect = false;
            this.gridVouchers.Name = "gridVouchers";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridVouchers.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gridVouchers.RowHeadersVisible = false;
            this.gridVouchers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gridVouchers.Size = new System.Drawing.Size(927, 310);
            this.gridVouchers.TabIndex = 99;
            this.gridVouchers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridVouchers_CellContentClick);
            this.gridVouchers.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridVouchers_RowEnter);
            this.gridVouchers.RowLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridVouchers_RowLeave);
            // 
            // clmDesc
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.clmDesc.DefaultCellStyle = dataGridViewCellStyle2;
            this.clmDesc.HeaderText = "Description";
            this.clmDesc.Name = "clmDesc";
            this.clmDesc.ReadOnly = true;
            this.clmDesc.Width = 150;
            // 
            // clmAmntRcvd
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.clmAmntRcvd.DefaultCellStyle = dataGridViewCellStyle3;
            this.clmAmntRcvd.HeaderText = "Received This Year";
            this.clmAmntRcvd.Name = "clmAmntRcvd";
            this.clmAmntRcvd.ReadOnly = true;
            // 
            // clmAmntAvail
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Tan;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.clmAmntAvail.DefaultCellStyle = dataGridViewCellStyle4;
            this.clmAmntAvail.HeaderText = "Available Amount ";
            this.clmAmntAvail.Name = "clmAmntAvail";
            this.clmAmntAvail.ReadOnly = true;
            // 
            // clmEnable
            // 
            this.clmEnable.HeaderText = "";
            this.clmEnable.Name = "clmEnable";
            this.clmEnable.ThreeState = true;
            this.clmEnable.Width = 30;
            // 
            // clmAmountGiven
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            this.clmAmountGiven.DefaultCellStyle = dataGridViewCellStyle5;
            this.clmAmountGiven.HeaderText = "Amount Given";
            this.clmAmountGiven.Name = "clmAmountGiven";
            // 
            // clmComments
            // 
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            this.clmComments.DefaultCellStyle = dataGridViewCellStyle6;
            this.clmComments.HeaderText = "Coments";
            this.clmComments.Name = "clmComments";
            this.clmComments.Width = 400;
            // 
            // clmDefaultAmount
            // 
            this.clmDefaultAmount.HeaderText = "Default Amount";
            this.clmDefaultAmount.Name = "clmDefaultAmount";
            this.clmDefaultAmount.ReadOnly = true;
            this.clmDefaultAmount.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // VoucherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(927, 476);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "VoucherForm";
            this.Text = "VoucherForm";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridVouchers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView gridVouchers;
        private System.Windows.Forms.TextBox tbClient;
        private System.Windows.Forms.DateTimePicker dtpTrxDate;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox tbEighteen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboClientType;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbInfants;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbYouth;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTeens;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbAdults;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbSeniors;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbTotalFam;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbDiet;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbDisabled;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox chkInCityLimits;
        private System.Windows.Forms.CheckBox chkHomeless;
        private System.Windows.Forms.Button btnPost;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAmntRcvd;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAmntAvail;
        private System.Windows.Forms.DataGridViewCheckBoxColumn clmEnable;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAmountGiven;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDefaultAmount;


    }
}