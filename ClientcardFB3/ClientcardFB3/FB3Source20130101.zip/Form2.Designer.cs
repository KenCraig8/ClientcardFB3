﻿namespace ClientcardFB3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel19 = new System.Windows.Forms.Panel();
            this.lblIndPvY2YTD = new System.Windows.Forms.Label();
            this.tbIndPvY2YTDTeensReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDYouthReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDAdultsReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSeniorsReturning = new System.Windows.Forms.TextBox();
            this.label140 = new System.Windows.Forms.Label();
            this.tbIndPvY2YTDDisabledReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDDisabled = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDInfantsReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSpecialDiet = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDTotalsReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSeniors = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDTotalsNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDAdults = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDDisabledNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDEighteen = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSpecialDietReturning = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDTeens = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSeniorsNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDYouth = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDSpecialDietNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDInfants = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDAdultsNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDTotalFamily = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTD18New = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDTeensNew = new System.Windows.Forms.TextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.tbIndPvY2YTD18Returning = new System.Windows.Forms.TextBox();
            this.label142 = new System.Windows.Forms.Label();
            this.tbIndPvY2YTDYouthNew = new System.Windows.Forms.TextBox();
            this.tbIndPvY2YTDInfantsNew = new System.Windows.Forms.TextBox();
            this.panel19.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.lblIndPvY2YTD);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTeensReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDYouthReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDAdultsReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSeniorsReturning);
            this.panel19.Controls.Add(this.label140);
            this.panel19.Controls.Add(this.tbIndPvY2YTDDisabledReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDDisabled);
            this.panel19.Controls.Add(this.tbIndPvY2YTDInfantsReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSpecialDiet);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTotalsReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSeniors);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTotalsNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDAdults);
            this.panel19.Controls.Add(this.tbIndPvY2YTDDisabledNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDEighteen);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSpecialDietReturning);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTeens);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSeniorsNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDYouth);
            this.panel19.Controls.Add(this.tbIndPvY2YTDSpecialDietNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDInfants);
            this.panel19.Controls.Add(this.tbIndPvY2YTDAdultsNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTotalFamily);
            this.panel19.Controls.Add(this.tbIndPvY2YTD18New);
            this.panel19.Controls.Add(this.tbIndPvY2YTDTeensNew);
            this.panel19.Controls.Add(this.label141);
            this.panel19.Controls.Add(this.tbIndPvY2YTD18Returning);
            this.panel19.Controls.Add(this.label142);
            this.panel19.Controls.Add(this.tbIndPvY2YTDYouthNew);
            this.panel19.Controls.Add(this.tbIndPvY2YTDInfantsNew);
            this.panel19.Location = new System.Drawing.Point(167, 80);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(228, 307);
            this.panel19.TabIndex = 160;
            // 
            // lblIndPvY2YTD
            // 
            this.lblIndPvY2YTD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndPvY2YTD.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblIndPvY2YTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndPvY2YTD.ForeColor = System.Drawing.Color.Black;
            this.lblIndPvY2YTD.Location = new System.Drawing.Point(0, 0);
            this.lblIndPvY2YTD.Name = "lblIndPvY2YTD";
            this.lblIndPvY2YTD.Size = new System.Drawing.Size(228, 19);
            this.lblIndPvY2YTD.TabIndex = 96;
            this.lblIndPvY2YTD.Tag = "Previous Fiscal YTD - ";
            this.lblIndPvY2YTD.Text = "Previous Year";
            this.lblIndPvY2YTD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbIndPvY2YTDTeensReturning
            // 
            this.tbIndPvY2YTDTeensReturning.AccessibleName = "";
            this.tbIndPvY2YTDTeensReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTeensReturning.Location = new System.Drawing.Point(77, 91);
            this.tbIndPvY2YTDTeensReturning.Name = "tbIndPvY2YTDTeensReturning";
            this.tbIndPvY2YTDTeensReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTeensReturning.TabIndex = 59;
            this.tbIndPvY2YTDTeensReturning.Tag = "TeensReturning";
            this.tbIndPvY2YTDTeensReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDYouthReturning
            // 
            this.tbIndPvY2YTDYouthReturning.AccessibleName = "";
            this.tbIndPvY2YTDYouthReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDYouthReturning.Location = new System.Drawing.Point(77, 65);
            this.tbIndPvY2YTDYouthReturning.Name = "tbIndPvY2YTDYouthReturning";
            this.tbIndPvY2YTDYouthReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDYouthReturning.TabIndex = 55;
            this.tbIndPvY2YTDYouthReturning.Tag = "YouthReturning";
            this.tbIndPvY2YTDYouthReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDAdultsReturning
            // 
            this.tbIndPvY2YTDAdultsReturning.AccessibleName = "";
            this.tbIndPvY2YTDAdultsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDAdultsReturning.Location = new System.Drawing.Point(77, 148);
            this.tbIndPvY2YTDAdultsReturning.Name = "tbIndPvY2YTDAdultsReturning";
            this.tbIndPvY2YTDAdultsReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDAdultsReturning.TabIndex = 64;
            this.tbIndPvY2YTDAdultsReturning.Tag = "AdultsReturning";
            this.tbIndPvY2YTDAdultsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSeniorsReturning
            // 
            this.tbIndPvY2YTDSeniorsReturning.AccessibleName = "";
            this.tbIndPvY2YTDSeniorsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSeniorsReturning.Location = new System.Drawing.Point(77, 175);
            this.tbIndPvY2YTDSeniorsReturning.Name = "tbIndPvY2YTDSeniorsReturning";
            this.tbIndPvY2YTDSeniorsReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSeniorsReturning.TabIndex = 68;
            this.tbIndPvY2YTDSeniorsReturning.Tag = "SeniorsReturning";
            this.tbIndPvY2YTDSeniorsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label140
            // 
            this.label140.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label140.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.ForeColor = System.Drawing.Color.Black;
            this.label140.Location = new System.Drawing.Point(155, 19);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(70, 20);
            this.label140.TabIndex = 148;
            this.label140.Text = "Total";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbIndPvY2YTDDisabledReturning
            // 
            this.tbIndPvY2YTDDisabledReturning.AccessibleName = "";
            this.tbIndPvY2YTDDisabledReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDDisabledReturning.Location = new System.Drawing.Point(77, 280);
            this.tbIndPvY2YTDDisabledReturning.Name = "tbIndPvY2YTDDisabledReturning";
            this.tbIndPvY2YTDDisabledReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDDisabledReturning.TabIndex = 40;
            this.tbIndPvY2YTDDisabledReturning.Tag = "CntDisabledReturning";
            this.tbIndPvY2YTDDisabledReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDDisabled
            // 
            this.tbIndPvY2YTDDisabled.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDDisabled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDDisabled.Location = new System.Drawing.Point(155, 279);
            this.tbIndPvY2YTDDisabled.Name = "tbIndPvY2YTDDisabled";
            this.tbIndPvY2YTDDisabled.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDDisabled.TabIndex = 112;
            this.tbIndPvY2YTDDisabled.Tag = "CntDisabled";
            this.tbIndPvY2YTDDisabled.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDInfantsReturning
            // 
            this.tbIndPvY2YTDInfantsReturning.AccessibleName = "";
            this.tbIndPvY2YTDInfantsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDInfantsReturning.Location = new System.Drawing.Point(77, 40);
            this.tbIndPvY2YTDInfantsReturning.Name = "tbIndPvY2YTDInfantsReturning";
            this.tbIndPvY2YTDInfantsReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDInfantsReturning.TabIndex = 51;
            this.tbIndPvY2YTDInfantsReturning.Tag = "InfantsReturning";
            this.tbIndPvY2YTDInfantsReturning.Text = "532,145";
            this.tbIndPvY2YTDInfantsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSpecialDiet
            // 
            this.tbIndPvY2YTDSpecialDiet.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDSpecialDiet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSpecialDiet.Location = new System.Drawing.Point(155, 255);
            this.tbIndPvY2YTDSpecialDiet.Name = "tbIndPvY2YTDSpecialDiet";
            this.tbIndPvY2YTDSpecialDiet.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSpecialDiet.TabIndex = 111;
            this.tbIndPvY2YTDSpecialDiet.Tag = "CntSpecialDiet";
            this.tbIndPvY2YTDSpecialDiet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDTotalsReturning
            // 
            this.tbIndPvY2YTDTotalsReturning.AccessibleName = "";
            this.tbIndPvY2YTDTotalsReturning.BackColor = System.Drawing.Color.LightCyan;
            this.tbIndPvY2YTDTotalsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTotalsReturning.ForeColor = System.Drawing.Color.Black;
            this.tbIndPvY2YTDTotalsReturning.Location = new System.Drawing.Point(77, 202);
            this.tbIndPvY2YTDTotalsReturning.Name = "tbIndPvY2YTDTotalsReturning";
            this.tbIndPvY2YTDTotalsReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTotalsReturning.TabIndex = 72;
            this.tbIndPvY2YTDTotalsReturning.Tag = "TotalFamilyReturning";
            this.tbIndPvY2YTDTotalsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSeniors
            // 
            this.tbIndPvY2YTDSeniors.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDSeniors.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSeniors.Location = new System.Drawing.Point(155, 175);
            this.tbIndPvY2YTDSeniors.Name = "tbIndPvY2YTDSeniors";
            this.tbIndPvY2YTDSeniors.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSeniors.TabIndex = 110;
            this.tbIndPvY2YTDSeniors.Tag = "Seniors";
            this.tbIndPvY2YTDSeniors.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDTotalsNew
            // 
            this.tbIndPvY2YTDTotalsNew.AccessibleName = "";
            this.tbIndPvY2YTDTotalsNew.BackColor = System.Drawing.Color.LightCyan;
            this.tbIndPvY2YTDTotalsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTotalsNew.ForeColor = System.Drawing.Color.Black;
            this.tbIndPvY2YTDTotalsNew.Location = new System.Drawing.Point(3, 202);
            this.tbIndPvY2YTDTotalsNew.Name = "tbIndPvY2YTDTotalsNew";
            this.tbIndPvY2YTDTotalsNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTotalsNew.TabIndex = 73;
            this.tbIndPvY2YTDTotalsNew.Tag = "TotalFamilyNew";
            this.tbIndPvY2YTDTotalsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDAdults
            // 
            this.tbIndPvY2YTDAdults.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDAdults.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDAdults.Location = new System.Drawing.Point(155, 148);
            this.tbIndPvY2YTDAdults.Name = "tbIndPvY2YTDAdults";
            this.tbIndPvY2YTDAdults.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDAdults.TabIndex = 109;
            this.tbIndPvY2YTDAdults.Tag = "Adults";
            this.tbIndPvY2YTDAdults.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDDisabledNew
            // 
            this.tbIndPvY2YTDDisabledNew.AccessibleName = "";
            this.tbIndPvY2YTDDisabledNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDDisabledNew.Location = new System.Drawing.Point(3, 280);
            this.tbIndPvY2YTDDisabledNew.Name = "tbIndPvY2YTDDisabledNew";
            this.tbIndPvY2YTDDisabledNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDDisabledNew.TabIndex = 39;
            this.tbIndPvY2YTDDisabledNew.Tag = "CntDisabledNew";
            this.tbIndPvY2YTDDisabledNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDEighteen
            // 
            this.tbIndPvY2YTDEighteen.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDEighteen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDEighteen.Location = new System.Drawing.Point(155, 121);
            this.tbIndPvY2YTDEighteen.Name = "tbIndPvY2YTDEighteen";
            this.tbIndPvY2YTDEighteen.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDEighteen.TabIndex = 108;
            this.tbIndPvY2YTDEighteen.Tag = "Eighteen";
            this.tbIndPvY2YTDEighteen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSpecialDietReturning
            // 
            this.tbIndPvY2YTDSpecialDietReturning.AccessibleName = "";
            this.tbIndPvY2YTDSpecialDietReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSpecialDietReturning.Location = new System.Drawing.Point(77, 256);
            this.tbIndPvY2YTDSpecialDietReturning.Name = "tbIndPvY2YTDSpecialDietReturning";
            this.tbIndPvY2YTDSpecialDietReturning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSpecialDietReturning.TabIndex = 36;
            this.tbIndPvY2YTDSpecialDietReturning.Tag = "CntSpecialDietReturning";
            this.tbIndPvY2YTDSpecialDietReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDTeens
            // 
            this.tbIndPvY2YTDTeens.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDTeens.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTeens.Location = new System.Drawing.Point(155, 91);
            this.tbIndPvY2YTDTeens.Name = "tbIndPvY2YTDTeens";
            this.tbIndPvY2YTDTeens.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTeens.TabIndex = 107;
            this.tbIndPvY2YTDTeens.Tag = "Teens";
            this.tbIndPvY2YTDTeens.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSeniorsNew
            // 
            this.tbIndPvY2YTDSeniorsNew.AccessibleName = "";
            this.tbIndPvY2YTDSeniorsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSeniorsNew.Location = new System.Drawing.Point(3, 175);
            this.tbIndPvY2YTDSeniorsNew.Name = "tbIndPvY2YTDSeniorsNew";
            this.tbIndPvY2YTDSeniorsNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSeniorsNew.TabIndex = 69;
            this.tbIndPvY2YTDSeniorsNew.Tag = "SeniorsNew";
            this.tbIndPvY2YTDSeniorsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDYouth
            // 
            this.tbIndPvY2YTDYouth.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDYouth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDYouth.Location = new System.Drawing.Point(155, 64);
            this.tbIndPvY2YTDYouth.Name = "tbIndPvY2YTDYouth";
            this.tbIndPvY2YTDYouth.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDYouth.TabIndex = 106;
            this.tbIndPvY2YTDYouth.Tag = "Youth";
            this.tbIndPvY2YTDYouth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDSpecialDietNew
            // 
            this.tbIndPvY2YTDSpecialDietNew.AccessibleName = "";
            this.tbIndPvY2YTDSpecialDietNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDSpecialDietNew.Location = new System.Drawing.Point(3, 256);
            this.tbIndPvY2YTDSpecialDietNew.Name = "tbIndPvY2YTDSpecialDietNew";
            this.tbIndPvY2YTDSpecialDietNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDSpecialDietNew.TabIndex = 35;
            this.tbIndPvY2YTDSpecialDietNew.Tag = "CntSpecialDietNew";
            this.tbIndPvY2YTDSpecialDietNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDInfants
            // 
            this.tbIndPvY2YTDInfants.BackColor = System.Drawing.Color.White;
            this.tbIndPvY2YTDInfants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDInfants.Location = new System.Drawing.Point(155, 40);
            this.tbIndPvY2YTDInfants.Name = "tbIndPvY2YTDInfants";
            this.tbIndPvY2YTDInfants.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDInfants.TabIndex = 105;
            this.tbIndPvY2YTDInfants.Tag = "Infants";
            this.tbIndPvY2YTDInfants.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDAdultsNew
            // 
            this.tbIndPvY2YTDAdultsNew.AccessibleName = "";
            this.tbIndPvY2YTDAdultsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDAdultsNew.Location = new System.Drawing.Point(3, 148);
            this.tbIndPvY2YTDAdultsNew.Name = "tbIndPvY2YTDAdultsNew";
            this.tbIndPvY2YTDAdultsNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDAdultsNew.TabIndex = 65;
            this.tbIndPvY2YTDAdultsNew.Tag = "AdultsNew";
            this.tbIndPvY2YTDAdultsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDTotalFamily
            // 
            this.tbIndPvY2YTDTotalFamily.BackColor = System.Drawing.Color.LightCyan;
            this.tbIndPvY2YTDTotalFamily.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTotalFamily.Location = new System.Drawing.Point(155, 202);
            this.tbIndPvY2YTDTotalFamily.Name = "tbIndPvY2YTDTotalFamily";
            this.tbIndPvY2YTDTotalFamily.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTotalFamily.TabIndex = 90;
            this.tbIndPvY2YTDTotalFamily.Tag = "TotalFamily";
            this.tbIndPvY2YTDTotalFamily.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTD18New
            // 
            this.tbIndPvY2YTD18New.AccessibleName = "";
            this.tbIndPvY2YTD18New.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTD18New.Location = new System.Drawing.Point(3, 121);
            this.tbIndPvY2YTD18New.Name = "tbIndPvY2YTD18New";
            this.tbIndPvY2YTD18New.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTD18New.TabIndex = 101;
            this.tbIndPvY2YTD18New.Tag = "EighteenNew";
            this.tbIndPvY2YTD18New.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDTeensNew
            // 
            this.tbIndPvY2YTDTeensNew.AccessibleName = "";
            this.tbIndPvY2YTDTeensNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDTeensNew.Location = new System.Drawing.Point(3, 91);
            this.tbIndPvY2YTDTeensNew.Name = "tbIndPvY2YTDTeensNew";
            this.tbIndPvY2YTDTeensNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDTeensNew.TabIndex = 60;
            this.tbIndPvY2YTDTeensNew.Tag = "TeensNew";
            this.tbIndPvY2YTDTeensNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label141
            // 
            this.label141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label141.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.ForeColor = System.Drawing.Color.Black;
            this.label141.Location = new System.Drawing.Point(77, 19);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(70, 20);
            this.label141.TabIndex = 94;
            this.label141.Text = "Returning";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbIndPvY2YTD18Returning
            // 
            this.tbIndPvY2YTD18Returning.AccessibleName = "";
            this.tbIndPvY2YTD18Returning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTD18Returning.Location = new System.Drawing.Point(77, 121);
            this.tbIndPvY2YTD18Returning.Name = "tbIndPvY2YTD18Returning";
            this.tbIndPvY2YTD18Returning.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTD18Returning.TabIndex = 100;
            this.tbIndPvY2YTD18Returning.Tag = "EighteenReturning";
            this.tbIndPvY2YTD18Returning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label142
            // 
            this.label142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label142.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label142.ForeColor = System.Drawing.Color.Black;
            this.label142.Location = new System.Drawing.Point(3, 19);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(70, 20);
            this.label142.TabIndex = 95;
            this.label142.Text = "New";
            this.label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbIndPvY2YTDYouthNew
            // 
            this.tbIndPvY2YTDYouthNew.AccessibleName = "";
            this.tbIndPvY2YTDYouthNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDYouthNew.Location = new System.Drawing.Point(3, 65);
            this.tbIndPvY2YTDYouthNew.Name = "tbIndPvY2YTDYouthNew";
            this.tbIndPvY2YTDYouthNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDYouthNew.TabIndex = 56;
            this.tbIndPvY2YTDYouthNew.Tag = "YouthNew";
            this.tbIndPvY2YTDYouthNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIndPvY2YTDInfantsNew
            // 
            this.tbIndPvY2YTDInfantsNew.AccessibleName = "";
            this.tbIndPvY2YTDInfantsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIndPvY2YTDInfantsNew.Location = new System.Drawing.Point(3, 40);
            this.tbIndPvY2YTDInfantsNew.Name = "tbIndPvY2YTDInfantsNew";
            this.tbIndPvY2YTDInfantsNew.Size = new System.Drawing.Size(70, 20);
            this.tbIndPvY2YTDInfantsNew.TabIndex = 52;
            this.tbIndPvY2YTDInfantsNew.Tag = "InfantsNew";
            this.tbIndPvY2YTDInfantsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 466);
            this.Controls.Add(this.panel19);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label lblIndPvY2YTD;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTeensReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDYouthReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDAdultsReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSeniorsReturning;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.TextBox tbIndPvY2YTDDisabledReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDDisabled;
        private System.Windows.Forms.TextBox tbIndPvY2YTDInfantsReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSpecialDiet;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTotalsReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSeniors;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTotalsNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDAdults;
        private System.Windows.Forms.TextBox tbIndPvY2YTDDisabledNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDEighteen;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSpecialDietReturning;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTeens;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSeniorsNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDYouth;
        private System.Windows.Forms.TextBox tbIndPvY2YTDSpecialDietNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDInfants;
        private System.Windows.Forms.TextBox tbIndPvY2YTDAdultsNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTotalFamily;
        private System.Windows.Forms.TextBox tbIndPvY2YTD18New;
        private System.Windows.Forms.TextBox tbIndPvY2YTDTeensNew;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox tbIndPvY2YTD18Returning;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.TextBox tbIndPvY2YTDYouthNew;
        private System.Windows.Forms.TextBox tbIndPvY2YTDInfantsNew;

    }
}