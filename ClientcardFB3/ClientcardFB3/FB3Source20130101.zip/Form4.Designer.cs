﻿namespace ClientcardFB3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlHHPvYr2YTD = new System.Windows.Forms.Panel();
            this.tbHHPvY2YTDHomeless = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimitsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDHomelessNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimitsNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDHomelessReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransientReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOther = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServedNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentMale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransientNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServed = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOther = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDSingleMale = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTotalServedReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleFemale = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDSingleFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplementalReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDInCityLimits = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplementalNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDTransient = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodityReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcs = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleMaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodityNew = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSupplemental = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDCommodity = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDSingleMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDBabySvcsNew = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.tbHHPvY2YTDParentMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvY2YTDOneParentMaleNew = new System.Windows.Forms.TextBox();
            this.lblHHPrev2YTD = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pnlHHYTDChange = new System.Windows.Forms.Panel();
            this.tbHHCurYTDInCityLimitsPercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDHomeless = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDInCityLimits = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDHomelessPercent = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDTransientPercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDTotalServed = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDTransient = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbHHCurYTDTotalServedPercent = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbHHCurYTDSingleFemalePercent = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentFemalePercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDSingleFemale = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSupplementalPercent = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentOtherPercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDOneParentFemale = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDSupplemental = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDCommodityPercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDSingleOther = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDOneParentOther = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDCommodity = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDBabySvcsPercent = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleOtherPercent = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleMalePercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDBabySvcs = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentMalePercent = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDSingleMale = new System.Windows.Forms.TextBox();
            this.tbHHDifYTDOneParentMale = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.pnlHHCurYTD = new System.Windows.Forms.Panel();
            this.tbHHCurYTDInCityLimitsReturning = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.tbHHCurYTDInCityLimitsNew = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.tbHHCurYTDTransientReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDTotalServedNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDHomeless = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDTransientNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDHomelessNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDTotalServed = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDHomelessReturning = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.tbHHCurYTDTotalServedReturning = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.tbHHCurYTDOneParentFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSupplementalReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSupplementalNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDCommodityReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDCommodityNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentOther = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDBabySvcsReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentMale = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentFemale = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDBabySvcsNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleOther = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDParentMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleMale = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentMaleNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleFemale = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleMaleNew = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.tbHHCurYTDSingleMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDCommodity = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSupplemental = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDSingleFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDBabySvcs = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDTransient = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDInCityLimits = new System.Windows.Forms.TextBox();
            this.tbHHCurYTDOneParentOtherReturning = new System.Windows.Forms.TextBox();
            this.lblHHCurYTD = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.pnlHHPvYrYTD = new System.Windows.Forms.Panel();
            this.tbHHPvYrYTDHomeless = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDInCityLimitsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDHomelessNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDInCityLimitsNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDHomelessReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTransientReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentOther = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTotalServedNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentMale = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTransientNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentFemale = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTotalServed = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleOther = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.tbHHPvYrYTDSingleMale = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTotalServedReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleFemale = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.tbHHPvYrYTDSingleFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentFemaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSupplementalReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentFemaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDInCityLimits = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSupplementalNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDTransient = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDCommodityReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDBabySvcs = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentOtherNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDCommodityNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSupplemental = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDBabySvcsReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDCommodity = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleOtherReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDBabySvcsNew = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.tbHHPvYrYTDParentMaleReturning = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDSingleMaleNew = new System.Windows.Forms.TextBox();
            this.tbHHPvYrYTDOneParentMaleNew = new System.Windows.Forms.TextBox();
            this.lblHHPrev1YTD = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.pnlHHPvYr2YTD.SuspendLayout();
            this.pnlHHYTDChange.SuspendLayout();
            this.pnlHHCurYTD.SuspendLayout();
            this.pnlHHPvYrYTD.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHHPvYr2YTD
            // 
            this.pnlHHPvYr2YTD.BackColor = System.Drawing.Color.Cornsilk;
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDHomeless);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDInCityLimitsReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDHomelessNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDInCityLimitsNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDHomelessReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTransientReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentOther);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTotalServedNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentMale);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTransientNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentFemale);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTotalServed);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleOther);
            this.pnlHHPvYr2YTD.Controls.Add(this.label111);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleMale);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTotalServedReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleFemale);
            this.pnlHHPvYr2YTD.Controls.Add(this.label112);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleFemaleReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentFemaleReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleFemaleNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSupplementalReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentOtherReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentFemaleNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDInCityLimits);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSupplementalNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDTransient);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDCommodityReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDBabySvcs);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleMaleNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleOtherNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentOtherNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDCommodityNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSupplemental);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDBabySvcsReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDCommodity);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleOtherReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDSingleMaleReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDBabySvcsNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.label113);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDParentMaleReturning);
            this.pnlHHPvYr2YTD.Controls.Add(this.tbHHPvY2YTDOneParentMaleNew);
            this.pnlHHPvYr2YTD.Controls.Add(this.lblHHPrev2YTD);
            this.pnlHHPvYr2YTD.Location = new System.Drawing.Point(665, 99);
            this.pnlHHPvYr2YTD.Name = "pnlHHPvYr2YTD";
            this.pnlHHPvYr2YTD.Size = new System.Drawing.Size(200, 427);
            this.pnlHHPvYr2YTD.TabIndex = 278;
            // 
            // tbHHPvY2YTDHomeless
            // 
            this.tbHHPvY2YTDHomeless.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomeless.Location = new System.Drawing.Point(133, 151);
            this.tbHHPvY2YTDHomeless.Name = "tbHHPvY2YTDHomeless";
            this.tbHHPvY2YTDHomeless.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDHomeless.TabIndex = 224;
            this.tbHHPvY2YTDHomeless.Tag = "HHHomeless";
            this.tbHHPvY2YTDHomeless.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimitsReturning
            // 
            this.tbHHPvY2YTDInCityLimitsReturning.AccessibleName = "";
            this.tbHHPvY2YTDInCityLimitsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimitsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimitsReturning.Location = new System.Drawing.Point(66, 206);
            this.tbHHPvY2YTDInCityLimitsReturning.Name = "tbHHPvY2YTDInCityLimitsReturning";
            this.tbHHPvY2YTDInCityLimitsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDInCityLimitsReturning.TabIndex = 189;
            this.tbHHPvY2YTDInCityLimitsReturning.Tag = "HHInCityLimitsReturning";
            this.tbHHPvY2YTDInCityLimitsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDHomelessNew
            // 
            this.tbHHPvY2YTDHomelessNew.AccessibleName = "";
            this.tbHHPvY2YTDHomelessNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomelessNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomelessNew.Location = new System.Drawing.Point(3, 152);
            this.tbHHPvY2YTDHomelessNew.Name = "tbHHPvY2YTDHomelessNew";
            this.tbHHPvY2YTDHomelessNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDHomelessNew.TabIndex = 223;
            this.tbHHPvY2YTDHomelessNew.Tag = "HHHomelessNew";
            this.tbHHPvY2YTDHomelessNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimitsNew
            // 
            this.tbHHPvY2YTDInCityLimitsNew.AccessibleName = "";
            this.tbHHPvY2YTDInCityLimitsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimitsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimitsNew.Location = new System.Drawing.Point(3, 206);
            this.tbHHPvY2YTDInCityLimitsNew.Name = "tbHHPvY2YTDInCityLimitsNew";
            this.tbHHPvY2YTDInCityLimitsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDInCityLimitsNew.TabIndex = 188;
            this.tbHHPvY2YTDInCityLimitsNew.Tag = "HHInCityLimitsNew";
            this.tbHHPvY2YTDInCityLimitsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDHomelessReturning
            // 
            this.tbHHPvY2YTDHomelessReturning.AccessibleName = "";
            this.tbHHPvY2YTDHomelessReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDHomelessReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDHomelessReturning.Location = new System.Drawing.Point(66, 151);
            this.tbHHPvY2YTDHomelessReturning.Name = "tbHHPvY2YTDHomelessReturning";
            this.tbHHPvY2YTDHomelessReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDHomelessReturning.TabIndex = 222;
            this.tbHHPvY2YTDHomelessReturning.Tag = "HHHomelessReturning";
            this.tbHHPvY2YTDHomelessReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransientReturning
            // 
            this.tbHHPvY2YTDTransientReturning.AccessibleName = "";
            this.tbHHPvY2YTDTransientReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransientReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransientReturning.Location = new System.Drawing.Point(66, 177);
            this.tbHHPvY2YTDTransientReturning.Name = "tbHHPvY2YTDTransientReturning";
            this.tbHHPvY2YTDTransientReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTransientReturning.TabIndex = 186;
            this.tbHHPvY2YTDTransientReturning.Tag = "HHTransientReturning";
            this.tbHHPvY2YTDTransientReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOther
            // 
            this.tbHHPvY2YTDOneParentOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOther.Location = new System.Drawing.Point(133, 405);
            this.tbHHPvY2YTDOneParentOther.Name = "tbHHPvY2YTDOneParentOther";
            this.tbHHPvY2YTDOneParentOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentOther.TabIndex = 221;
            this.tbHHPvY2YTDOneParentOther.Tag = "HHOneParentOther";
            this.tbHHPvY2YTDOneParentOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServedNew
            // 
            this.tbHHPvY2YTDTotalServedNew.AccessibleName = "";
            this.tbHHPvY2YTDTotalServedNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServedNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServedNew.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvY2YTDTotalServedNew.Location = new System.Drawing.Point(3, 38);
            this.tbHHPvY2YTDTotalServedNew.Name = "tbHHPvY2YTDTotalServedNew";
            this.tbHHPvY2YTDTotalServedNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTotalServedNew.TabIndex = 185;
            this.tbHHPvY2YTDTotalServedNew.Tag = "HHTotalServedNew";
            this.tbHHPvY2YTDTotalServedNew.Text = "500,569";
            this.tbHHPvY2YTDTotalServedNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentMale
            // 
            this.tbHHPvY2YTDOneParentMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentMale.Location = new System.Drawing.Point(133, 380);
            this.tbHHPvY2YTDOneParentMale.Name = "tbHHPvY2YTDOneParentMale";
            this.tbHHPvY2YTDOneParentMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentMale.TabIndex = 220;
            this.tbHHPvY2YTDOneParentMale.Tag = "HHOneParentMale";
            this.tbHHPvY2YTDOneParentMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransientNew
            // 
            this.tbHHPvY2YTDTransientNew.AccessibleName = "";
            this.tbHHPvY2YTDTransientNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransientNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransientNew.Location = new System.Drawing.Point(3, 178);
            this.tbHHPvY2YTDTransientNew.Name = "tbHHPvY2YTDTransientNew";
            this.tbHHPvY2YTDTransientNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTransientNew.TabIndex = 187;
            this.tbHHPvY2YTDTransientNew.Tag = "HHTransientNew";
            this.tbHHPvY2YTDTransientNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemale
            // 
            this.tbHHPvY2YTDOneParentFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemale.Location = new System.Drawing.Point(133, 351);
            this.tbHHPvY2YTDOneParentFemale.Name = "tbHHPvY2YTDOneParentFemale";
            this.tbHHPvY2YTDOneParentFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDOneParentFemale.TabIndex = 219;
            this.tbHHPvY2YTDOneParentFemale.Tag = "HHOneParentFemale";
            this.tbHHPvY2YTDOneParentFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServed
            // 
            this.tbHHPvY2YTDTotalServed.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServed.Location = new System.Drawing.Point(133, 38);
            this.tbHHPvY2YTDTotalServed.Name = "tbHHPvY2YTDTotalServed";
            this.tbHHPvY2YTDTotalServed.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDTotalServed.TabIndex = 190;
            this.tbHHPvY2YTDTotalServed.Tag = "HHTotalServed";
            this.tbHHPvY2YTDTotalServed.Text = "356,987";
            this.tbHHPvY2YTDTotalServed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOther
            // 
            this.tbHHPvY2YTDSingleOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOther.Location = new System.Drawing.Point(133, 304);
            this.tbHHPvY2YTDSingleOther.Name = "tbHHPvY2YTDSingleOther";
            this.tbHHPvY2YTDSingleOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleOther.TabIndex = 218;
            this.tbHHPvY2YTDSingleOther.Tag = "HHSingleOther";
            this.tbHHPvY2YTDSingleOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label111
            // 
            this.label111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.ForeColor = System.Drawing.Color.Black;
            this.label111.Location = new System.Drawing.Point(3, 18);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(60, 18);
            this.label111.TabIndex = 184;
            this.label111.Text = "New";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDSingleMale
            // 
            this.tbHHPvY2YTDSingleMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMale.Location = new System.Drawing.Point(133, 280);
            this.tbHHPvY2YTDSingleMale.Name = "tbHHPvY2YTDSingleMale";
            this.tbHHPvY2YTDSingleMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleMale.TabIndex = 217;
            this.tbHHPvY2YTDSingleMale.Tag = "HHSingleMale";
            this.tbHHPvY2YTDSingleMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTotalServedReturning
            // 
            this.tbHHPvY2YTDTotalServedReturning.AccessibleName = "";
            this.tbHHPvY2YTDTotalServedReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTotalServedReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTotalServedReturning.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvY2YTDTotalServedReturning.Location = new System.Drawing.Point(66, 38);
            this.tbHHPvY2YTDTotalServedReturning.Name = "tbHHPvY2YTDTotalServedReturning";
            this.tbHHPvY2YTDTotalServedReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDTotalServedReturning.TabIndex = 183;
            this.tbHHPvY2YTDTotalServedReturning.Tag = "HHTotalServedReturning";
            this.tbHHPvY2YTDTotalServedReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleFemale
            // 
            this.tbHHPvY2YTDSingleFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemale.Location = new System.Drawing.Point(133, 254);
            this.tbHHPvY2YTDSingleFemale.Name = "tbHHPvY2YTDSingleFemale";
            this.tbHHPvY2YTDSingleFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSingleFemale.TabIndex = 216;
            this.tbHHPvY2YTDSingleFemale.Tag = "HHSingleFemale";
            this.tbHHPvY2YTDSingleFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label112
            // 
            this.label112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.ForeColor = System.Drawing.Color.Black;
            this.label112.Location = new System.Drawing.Point(66, 18);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(60, 18);
            this.label112.TabIndex = 182;
            this.label112.Text = "Returning";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDSingleFemaleReturning
            // 
            this.tbHHPvY2YTDSingleFemaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemaleReturning.Location = new System.Drawing.Point(66, 255);
            this.tbHHPvY2YTDSingleFemaleReturning.Name = "tbHHPvY2YTDSingleFemaleReturning";
            this.tbHHPvY2YTDSingleFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleFemaleReturning.TabIndex = 193;
            this.tbHHPvY2YTDSingleFemaleReturning.Tag = "HHSingleFemaleReturning";
            this.tbHHPvY2YTDSingleFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemaleReturning
            // 
            this.tbHHPvY2YTDOneParentFemaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDOneParentFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemaleReturning.Location = new System.Drawing.Point(66, 351);
            this.tbHHPvY2YTDOneParentFemaleReturning.Name = "tbHHPvY2YTDOneParentFemaleReturning";
            this.tbHHPvY2YTDOneParentFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentFemaleReturning.TabIndex = 199;
            this.tbHHPvY2YTDOneParentFemaleReturning.Tag = "HHOneParentFemaleReturning";
            this.tbHHPvY2YTDOneParentFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleFemaleNew
            // 
            this.tbHHPvY2YTDSingleFemaleNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleFemaleNew.Location = new System.Drawing.Point(3, 255);
            this.tbHHPvY2YTDSingleFemaleNew.Name = "tbHHPvY2YTDSingleFemaleNew";
            this.tbHHPvY2YTDSingleFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleFemaleNew.TabIndex = 192;
            this.tbHHPvY2YTDSingleFemaleNew.Tag = "HHSingleFemaleNew";
            this.tbHHPvY2YTDSingleFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplementalReturning
            // 
            this.tbHHPvY2YTDSupplementalReturning.AccessibleName = "";
            this.tbHHPvY2YTDSupplementalReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplementalReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplementalReturning.Location = new System.Drawing.Point(66, 98);
            this.tbHHPvY2YTDSupplementalReturning.Name = "tbHHPvY2YTDSupplementalReturning";
            this.tbHHPvY2YTDSupplementalReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSupplementalReturning.TabIndex = 207;
            this.tbHHPvY2YTDSupplementalReturning.Tag = "HHRcvdSupplementalReturning";
            this.tbHHPvY2YTDSupplementalReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOtherReturning
            // 
            this.tbHHPvY2YTDOneParentOtherReturning.AccessibleName = "";
            this.tbHHPvY2YTDOneParentOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOtherReturning.Location = new System.Drawing.Point(66, 405);
            this.tbHHPvY2YTDOneParentOtherReturning.Name = "tbHHPvY2YTDOneParentOtherReturning";
            this.tbHHPvY2YTDOneParentOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentOtherReturning.TabIndex = 203;
            this.tbHHPvY2YTDOneParentOtherReturning.Tag = "HHOneParentOtherReturning";
            this.tbHHPvY2YTDOneParentOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentFemaleNew
            // 
            this.tbHHPvY2YTDOneParentFemaleNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentFemaleNew.Location = new System.Drawing.Point(3, 350);
            this.tbHHPvY2YTDOneParentFemaleNew.Name = "tbHHPvY2YTDOneParentFemaleNew";
            this.tbHHPvY2YTDOneParentFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentFemaleNew.TabIndex = 198;
            this.tbHHPvY2YTDOneParentFemaleNew.Tag = "HHOneParentFemaleNew";
            this.tbHHPvY2YTDOneParentFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDInCityLimits
            // 
            this.tbHHPvY2YTDInCityLimits.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDInCityLimits.Location = new System.Drawing.Point(133, 205);
            this.tbHHPvY2YTDInCityLimits.Name = "tbHHPvY2YTDInCityLimits";
            this.tbHHPvY2YTDInCityLimits.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDInCityLimits.TabIndex = 215;
            this.tbHHPvY2YTDInCityLimits.Tag = "HHInCityLimits";
            this.tbHHPvY2YTDInCityLimits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplementalNew
            // 
            this.tbHHPvY2YTDSupplementalNew.AccessibleName = "";
            this.tbHHPvY2YTDSupplementalNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplementalNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplementalNew.Location = new System.Drawing.Point(3, 98);
            this.tbHHPvY2YTDSupplementalNew.Name = "tbHHPvY2YTDSupplementalNew";
            this.tbHHPvY2YTDSupplementalNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSupplementalNew.TabIndex = 206;
            this.tbHHPvY2YTDSupplementalNew.Tag = "HHRcvdSupplementalNew";
            this.tbHHPvY2YTDSupplementalNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDTransient
            // 
            this.tbHHPvY2YTDTransient.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDTransient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDTransient.Location = new System.Drawing.Point(133, 177);
            this.tbHHPvY2YTDTransient.Name = "tbHHPvY2YTDTransient";
            this.tbHHPvY2YTDTransient.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDTransient.TabIndex = 214;
            this.tbHHPvY2YTDTransient.Tag = "HHTransient";
            this.tbHHPvY2YTDTransient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodityReturning
            // 
            this.tbHHPvY2YTDCommodityReturning.AccessibleName = "";
            this.tbHHPvY2YTDCommodityReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodityReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodityReturning.Location = new System.Drawing.Point(66, 75);
            this.tbHHPvY2YTDCommodityReturning.Name = "tbHHPvY2YTDCommodityReturning";
            this.tbHHPvY2YTDCommodityReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDCommodityReturning.TabIndex = 204;
            this.tbHHPvY2YTDCommodityReturning.Tag = "HHRcvdCommodityReturning";
            this.tbHHPvY2YTDCommodityReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcs
            // 
            this.tbHHPvY2YTDBabySvcs.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcs.Location = new System.Drawing.Point(133, 124);
            this.tbHHPvY2YTDBabySvcs.Name = "tbHHPvY2YTDBabySvcs";
            this.tbHHPvY2YTDBabySvcs.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDBabySvcs.TabIndex = 213;
            this.tbHHPvY2YTDBabySvcs.Tag = "HHRcvdBabyServices";
            this.tbHHPvY2YTDBabySvcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleMaleNew
            // 
            this.tbHHPvY2YTDSingleMaleNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMaleNew.Location = new System.Drawing.Point(3, 282);
            this.tbHHPvY2YTDSingleMaleNew.Name = "tbHHPvY2YTDSingleMaleNew";
            this.tbHHPvY2YTDSingleMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleMaleNew.TabIndex = 194;
            this.tbHHPvY2YTDSingleMaleNew.Tag = "HHSingleMaleNew";
            this.tbHHPvY2YTDSingleMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOtherNew
            // 
            this.tbHHPvY2YTDSingleOtherNew.AccessibleName = "";
            this.tbHHPvY2YTDSingleOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOtherNew.Location = new System.Drawing.Point(3, 305);
            this.tbHHPvY2YTDSingleOtherNew.Name = "tbHHPvY2YTDSingleOtherNew";
            this.tbHHPvY2YTDSingleOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleOtherNew.TabIndex = 196;
            this.tbHHPvY2YTDSingleOtherNew.Tag = "HHSingleOtherNew";
            this.tbHHPvY2YTDSingleOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentOtherNew
            // 
            this.tbHHPvY2YTDOneParentOtherNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentOtherNew.Location = new System.Drawing.Point(3, 404);
            this.tbHHPvY2YTDOneParentOtherNew.Name = "tbHHPvY2YTDOneParentOtherNew";
            this.tbHHPvY2YTDOneParentOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentOtherNew.TabIndex = 202;
            this.tbHHPvY2YTDOneParentOtherNew.Tag = "HHOneParentOtherNew";
            this.tbHHPvY2YTDOneParentOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodityNew
            // 
            this.tbHHPvY2YTDCommodityNew.AccessibleName = "";
            this.tbHHPvY2YTDCommodityNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodityNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodityNew.Location = new System.Drawing.Point(3, 76);
            this.tbHHPvY2YTDCommodityNew.Name = "tbHHPvY2YTDCommodityNew";
            this.tbHHPvY2YTDCommodityNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDCommodityNew.TabIndex = 205;
            this.tbHHPvY2YTDCommodityNew.Tag = "HHRcvdCommodityNew";
            this.tbHHPvY2YTDCommodityNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSupplemental
            // 
            this.tbHHPvY2YTDSupplemental.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSupplemental.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSupplemental.Location = new System.Drawing.Point(133, 97);
            this.tbHHPvY2YTDSupplemental.Name = "tbHHPvY2YTDSupplemental";
            this.tbHHPvY2YTDSupplemental.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDSupplemental.TabIndex = 212;
            this.tbHHPvY2YTDSupplemental.Tag = "HHRcvdSupplemental";
            this.tbHHPvY2YTDSupplemental.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcsReturning
            // 
            this.tbHHPvY2YTDBabySvcsReturning.AccessibleName = "";
            this.tbHHPvY2YTDBabySvcsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcsReturning.Location = new System.Drawing.Point(66, 125);
            this.tbHHPvY2YTDBabySvcsReturning.Name = "tbHHPvY2YTDBabySvcsReturning";
            this.tbHHPvY2YTDBabySvcsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDBabySvcsReturning.TabIndex = 209;
            this.tbHHPvY2YTDBabySvcsReturning.Tag = "HHRcvdBabyServicesReturning";
            this.tbHHPvY2YTDBabySvcsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDCommodity
            // 
            this.tbHHPvY2YTDCommodity.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDCommodity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDCommodity.Location = new System.Drawing.Point(133, 75);
            this.tbHHPvY2YTDCommodity.Name = "tbHHPvY2YTDCommodity";
            this.tbHHPvY2YTDCommodity.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvY2YTDCommodity.TabIndex = 211;
            this.tbHHPvY2YTDCommodity.Tag = "HHRcvdCommodity";
            this.tbHHPvY2YTDCommodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleOtherReturning
            // 
            this.tbHHPvY2YTDSingleOtherReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleOtherReturning.Location = new System.Drawing.Point(66, 305);
            this.tbHHPvY2YTDSingleOtherReturning.Name = "tbHHPvY2YTDSingleOtherReturning";
            this.tbHHPvY2YTDSingleOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleOtherReturning.TabIndex = 197;
            this.tbHHPvY2YTDSingleOtherReturning.Tag = "HHSingleOtherReturning";
            this.tbHHPvY2YTDSingleOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDSingleMaleReturning
            // 
            this.tbHHPvY2YTDSingleMaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDSingleMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDSingleMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDSingleMaleReturning.Location = new System.Drawing.Point(66, 282);
            this.tbHHPvY2YTDSingleMaleReturning.Name = "tbHHPvY2YTDSingleMaleReturning";
            this.tbHHPvY2YTDSingleMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDSingleMaleReturning.TabIndex = 195;
            this.tbHHPvY2YTDSingleMaleReturning.Tag = "HHSingleMaleReturning";
            this.tbHHPvY2YTDSingleMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDBabySvcsNew
            // 
            this.tbHHPvY2YTDBabySvcsNew.AccessibleName = "";
            this.tbHHPvY2YTDBabySvcsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDBabySvcsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDBabySvcsNew.Location = new System.Drawing.Point(3, 125);
            this.tbHHPvY2YTDBabySvcsNew.Name = "tbHHPvY2YTDBabySvcsNew";
            this.tbHHPvY2YTDBabySvcsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDBabySvcsNew.TabIndex = 208;
            this.tbHHPvY2YTDBabySvcsNew.Tag = "HHRcvdBabyServicesNew";
            this.tbHHPvY2YTDBabySvcsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label113
            // 
            this.label113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.ForeColor = System.Drawing.Color.Black;
            this.label113.Location = new System.Drawing.Point(133, 18);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(60, 18);
            this.label113.TabIndex = 210;
            this.label113.Text = "Total";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvY2YTDParentMaleReturning
            // 
            this.tbHHPvY2YTDParentMaleReturning.AccessibleName = "";
            this.tbHHPvY2YTDParentMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDParentMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDParentMaleReturning.Location = new System.Drawing.Point(66, 378);
            this.tbHHPvY2YTDParentMaleReturning.Name = "tbHHPvY2YTDParentMaleReturning";
            this.tbHHPvY2YTDParentMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDParentMaleReturning.TabIndex = 201;
            this.tbHHPvY2YTDParentMaleReturning.Tag = "HHOneParentMaleReturning";
            this.tbHHPvY2YTDParentMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvY2YTDOneParentMaleNew
            // 
            this.tbHHPvY2YTDOneParentMaleNew.AccessibleName = "";
            this.tbHHPvY2YTDOneParentMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvY2YTDOneParentMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvY2YTDOneParentMaleNew.Location = new System.Drawing.Point(3, 377);
            this.tbHHPvY2YTDOneParentMaleNew.Name = "tbHHPvY2YTDOneParentMaleNew";
            this.tbHHPvY2YTDOneParentMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvY2YTDOneParentMaleNew.TabIndex = 200;
            this.tbHHPvY2YTDOneParentMaleNew.Tag = "HHOneParentMaleNew";
            this.tbHHPvY2YTDOneParentMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblHHPrev2YTD
            // 
            this.lblHHPrev2YTD.BackColor = System.Drawing.Color.Beige;
            this.lblHHPrev2YTD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHHPrev2YTD.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHHPrev2YTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHPrev2YTD.ForeColor = System.Drawing.Color.Firebrick;
            this.lblHHPrev2YTD.Location = new System.Drawing.Point(0, 0);
            this.lblHHPrev2YTD.Name = "lblHHPrev2YTD";
            this.lblHHPrev2YTD.Size = new System.Drawing.Size(200, 19);
            this.lblHHPrev2YTD.TabIndex = 191;
            this.lblHHPrev2YTD.Tag = "Previous Fiscal YTD - ";
            this.lblHHPrev2YTD.Text = "Previous Fiscal YTD - ";
            this.lblHHPrev2YTD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(66, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 15);
            this.label10.TabIndex = 262;
            this.label10.Text = "Total Served";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlHHYTDChange
            // 
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDInCityLimitsPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDHomeless);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDInCityLimits);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDHomelessPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDTransientPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDTotalServed);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDTransient);
            this.pnlHHYTDChange.Controls.Add(this.label22);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDTotalServedPercent);
            this.pnlHHYTDChange.Controls.Add(this.label23);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDSingleFemalePercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDOneParentFemalePercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDSingleFemale);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDSupplementalPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDOneParentOtherPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDOneParentFemale);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDSupplemental);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDCommodityPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDSingleOther);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDOneParentOther);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDCommodity);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDBabySvcsPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDSingleOtherPercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDSingleMalePercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDBabySvcs);
            this.pnlHHYTDChange.Controls.Add(this.tbHHCurYTDOneParentMalePercent);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDSingleMale);
            this.pnlHHYTDChange.Controls.Add(this.tbHHDifYTDOneParentMale);
            this.pnlHHYTDChange.Controls.Add(this.label60);
            this.pnlHHYTDChange.Location = new System.Drawing.Point(348, 99);
            this.pnlHHYTDChange.Name = "pnlHHYTDChange";
            this.pnlHHYTDChange.Size = new System.Drawing.Size(111, 427);
            this.pnlHHYTDChange.TabIndex = 277;
            // 
            // tbHHCurYTDInCityLimitsPercent
            // 
            this.tbHHCurYTDInCityLimitsPercent.AccessibleName = "";
            this.tbHHCurYTDInCityLimitsPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDInCityLimitsPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDInCityLimitsPercent.Location = new System.Drawing.Point(57, 206);
            this.tbHHCurYTDInCityLimitsPercent.Name = "tbHHCurYTDInCityLimitsPercent";
            this.tbHHCurYTDInCityLimitsPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDInCityLimitsPercent.TabIndex = 189;
            this.tbHHCurYTDInCityLimitsPercent.Tag = "HHInCityLimitsPercent";
            this.tbHHCurYTDInCityLimitsPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDHomeless
            // 
            this.tbHHDifYTDHomeless.AccessibleName = "";
            this.tbHHDifYTDHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDHomeless.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDHomeless.Location = new System.Drawing.Point(3, 152);
            this.tbHHDifYTDHomeless.Name = "tbHHDifYTDHomeless";
            this.tbHHDifYTDHomeless.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDHomeless.TabIndex = 223;
            this.tbHHDifYTDHomeless.Tag = "HHHomeless";
            this.tbHHDifYTDHomeless.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDInCityLimits
            // 
            this.tbHHDifYTDInCityLimits.AccessibleName = "";
            this.tbHHDifYTDInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDInCityLimits.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDInCityLimits.Location = new System.Drawing.Point(3, 206);
            this.tbHHDifYTDInCityLimits.Name = "tbHHDifYTDInCityLimits";
            this.tbHHDifYTDInCityLimits.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDInCityLimits.TabIndex = 188;
            this.tbHHDifYTDInCityLimits.Tag = "HHInCityLimits";
            this.tbHHDifYTDInCityLimits.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDHomelessPercent
            // 
            this.tbHHCurYTDHomelessPercent.AccessibleName = "";
            this.tbHHCurYTDHomelessPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDHomelessPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDHomelessPercent.Location = new System.Drawing.Point(57, 152);
            this.tbHHCurYTDHomelessPercent.Name = "tbHHCurYTDHomelessPercent";
            this.tbHHCurYTDHomelessPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDHomelessPercent.TabIndex = 222;
            this.tbHHCurYTDHomelessPercent.Tag = "HHHomelessPercent";
            this.tbHHCurYTDHomelessPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDTransientPercent
            // 
            this.tbHHCurYTDTransientPercent.AccessibleName = "";
            this.tbHHCurYTDTransientPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTransientPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDTransientPercent.Location = new System.Drawing.Point(57, 177);
            this.tbHHCurYTDTransientPercent.Name = "tbHHCurYTDTransientPercent";
            this.tbHHCurYTDTransientPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDTransientPercent.TabIndex = 186;
            this.tbHHCurYTDTransientPercent.Tag = "HHTransientPercent";
            this.tbHHCurYTDTransientPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDTotalServed
            // 
            this.tbHHDifYTDTotalServed.AccessibleName = "";
            this.tbHHDifYTDTotalServed.BackColor = System.Drawing.Color.White;
            this.tbHHDifYTDTotalServed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDTotalServed.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDTotalServed.Location = new System.Drawing.Point(3, 38);
            this.tbHHDifYTDTotalServed.Name = "tbHHDifYTDTotalServed";
            this.tbHHDifYTDTotalServed.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDTotalServed.TabIndex = 185;
            this.tbHHDifYTDTotalServed.Tag = "HHTotalServed";
            this.tbHHDifYTDTotalServed.Text = "500,569";
            this.tbHHDifYTDTotalServed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDTransient
            // 
            this.tbHHDifYTDTransient.AccessibleName = "";
            this.tbHHDifYTDTransient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDTransient.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDTransient.Location = new System.Drawing.Point(3, 178);
            this.tbHHDifYTDTransient.Name = "tbHHDifYTDTransient";
            this.tbHHDifYTDTransient.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDTransient.TabIndex = 187;
            this.tbHHDifYTDTransient.Tag = "HHTransient";
            this.tbHHDifYTDTransient.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(3, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 20);
            this.label22.TabIndex = 184;
            this.label22.Text = "Count";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHCurYTDTotalServedPercent
            // 
            this.tbHHCurYTDTotalServedPercent.AccessibleName = "";
            this.tbHHCurYTDTotalServedPercent.BackColor = System.Drawing.Color.White;
            this.tbHHCurYTDTotalServedPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTotalServedPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDTotalServedPercent.Location = new System.Drawing.Point(57, 38);
            this.tbHHCurYTDTotalServedPercent.Name = "tbHHCurYTDTotalServedPercent";
            this.tbHHCurYTDTotalServedPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDTotalServedPercent.TabIndex = 183;
            this.tbHHCurYTDTotalServedPercent.Tag = "HHTotalServedPercent";
            this.tbHHCurYTDTotalServedPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(57, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 20);
            this.label23.TabIndex = 182;
            this.label23.Text = "Percent";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHCurYTDSingleFemalePercent
            // 
            this.tbHHCurYTDSingleFemalePercent.AccessibleName = "";
            this.tbHHCurYTDSingleFemalePercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleFemalePercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDSingleFemalePercent.Location = new System.Drawing.Point(57, 255);
            this.tbHHCurYTDSingleFemalePercent.Name = "tbHHCurYTDSingleFemalePercent";
            this.tbHHCurYTDSingleFemalePercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDSingleFemalePercent.TabIndex = 193;
            this.tbHHCurYTDSingleFemalePercent.Tag = "HHSingleFemalePercent";
            this.tbHHCurYTDSingleFemalePercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDOneParentFemalePercent
            // 
            this.tbHHCurYTDOneParentFemalePercent.AccessibleName = "";
            this.tbHHCurYTDOneParentFemalePercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentFemalePercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDOneParentFemalePercent.Location = new System.Drawing.Point(57, 350);
            this.tbHHCurYTDOneParentFemalePercent.Name = "tbHHCurYTDOneParentFemalePercent";
            this.tbHHCurYTDOneParentFemalePercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDOneParentFemalePercent.TabIndex = 199;
            this.tbHHCurYTDOneParentFemalePercent.Tag = "HHOneParentFemalePercent";
            this.tbHHCurYTDOneParentFemalePercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDSingleFemale
            // 
            this.tbHHDifYTDSingleFemale.AccessibleName = "";
            this.tbHHDifYTDSingleFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDSingleFemale.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDSingleFemale.Location = new System.Drawing.Point(3, 255);
            this.tbHHDifYTDSingleFemale.Name = "tbHHDifYTDSingleFemale";
            this.tbHHDifYTDSingleFemale.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDSingleFemale.TabIndex = 192;
            this.tbHHDifYTDSingleFemale.Tag = "HHSingleFemale";
            this.tbHHDifYTDSingleFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDSupplementalPercent
            // 
            this.tbHHCurYTDSupplementalPercent.AccessibleName = "";
            this.tbHHCurYTDSupplementalPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSupplementalPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDSupplementalPercent.Location = new System.Drawing.Point(57, 98);
            this.tbHHCurYTDSupplementalPercent.Name = "tbHHCurYTDSupplementalPercent";
            this.tbHHCurYTDSupplementalPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDSupplementalPercent.TabIndex = 207;
            this.tbHHCurYTDSupplementalPercent.Tag = "HHRcvdSupplementalPercent";
            this.tbHHCurYTDSupplementalPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDOneParentOtherPercent
            // 
            this.tbHHCurYTDOneParentOtherPercent.AccessibleName = "";
            this.tbHHCurYTDOneParentOtherPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentOtherPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDOneParentOtherPercent.Location = new System.Drawing.Point(57, 405);
            this.tbHHCurYTDOneParentOtherPercent.Name = "tbHHCurYTDOneParentOtherPercent";
            this.tbHHCurYTDOneParentOtherPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDOneParentOtherPercent.TabIndex = 203;
            this.tbHHCurYTDOneParentOtherPercent.Tag = "HHOneParentOtherPercent";
            this.tbHHCurYTDOneParentOtherPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDOneParentFemale
            // 
            this.tbHHDifYTDOneParentFemale.AccessibleName = "";
            this.tbHHDifYTDOneParentFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDOneParentFemale.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDOneParentFemale.Location = new System.Drawing.Point(3, 350);
            this.tbHHDifYTDOneParentFemale.Name = "tbHHDifYTDOneParentFemale";
            this.tbHHDifYTDOneParentFemale.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDOneParentFemale.TabIndex = 198;
            this.tbHHDifYTDOneParentFemale.Tag = "HHOneParentFemale";
            this.tbHHDifYTDOneParentFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDSupplemental
            // 
            this.tbHHDifYTDSupplemental.AccessibleName = "";
            this.tbHHDifYTDSupplemental.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDSupplemental.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDSupplemental.Location = new System.Drawing.Point(3, 98);
            this.tbHHDifYTDSupplemental.Name = "tbHHDifYTDSupplemental";
            this.tbHHDifYTDSupplemental.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDSupplemental.TabIndex = 206;
            this.tbHHDifYTDSupplemental.Tag = "HHRcvdSupplemental";
            this.tbHHDifYTDSupplemental.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDCommodityPercent
            // 
            this.tbHHCurYTDCommodityPercent.AccessibleName = "";
            this.tbHHCurYTDCommodityPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDCommodityPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDCommodityPercent.Location = new System.Drawing.Point(57, 75);
            this.tbHHCurYTDCommodityPercent.Name = "tbHHCurYTDCommodityPercent";
            this.tbHHCurYTDCommodityPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDCommodityPercent.TabIndex = 204;
            this.tbHHCurYTDCommodityPercent.Tag = "HHRcvdCommodityPercent";
            this.tbHHCurYTDCommodityPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDSingleOther
            // 
            this.tbHHDifYTDSingleOther.AccessibleName = "";
            this.tbHHDifYTDSingleOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDSingleOther.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDSingleOther.Location = new System.Drawing.Point(3, 305);
            this.tbHHDifYTDSingleOther.Name = "tbHHDifYTDSingleOther";
            this.tbHHDifYTDSingleOther.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDSingleOther.TabIndex = 196;
            this.tbHHDifYTDSingleOther.Tag = "HHSingleOther";
            this.tbHHDifYTDSingleOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDOneParentOther
            // 
            this.tbHHDifYTDOneParentOther.AccessibleName = "";
            this.tbHHDifYTDOneParentOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDOneParentOther.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDOneParentOther.Location = new System.Drawing.Point(3, 404);
            this.tbHHDifYTDOneParentOther.Name = "tbHHDifYTDOneParentOther";
            this.tbHHDifYTDOneParentOther.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDOneParentOther.TabIndex = 202;
            this.tbHHDifYTDOneParentOther.Tag = "HHOneParentOther";
            this.tbHHDifYTDOneParentOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDCommodity
            // 
            this.tbHHDifYTDCommodity.AccessibleName = "";
            this.tbHHDifYTDCommodity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDCommodity.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDCommodity.Location = new System.Drawing.Point(3, 76);
            this.tbHHDifYTDCommodity.Name = "tbHHDifYTDCommodity";
            this.tbHHDifYTDCommodity.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDCommodity.TabIndex = 205;
            this.tbHHDifYTDCommodity.Tag = "HHRcvdCommodity";
            this.tbHHDifYTDCommodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDBabySvcsPercent
            // 
            this.tbHHCurYTDBabySvcsPercent.AccessibleName = "";
            this.tbHHCurYTDBabySvcsPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDBabySvcsPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDBabySvcsPercent.Location = new System.Drawing.Point(57, 125);
            this.tbHHCurYTDBabySvcsPercent.Name = "tbHHCurYTDBabySvcsPercent";
            this.tbHHCurYTDBabySvcsPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDBabySvcsPercent.TabIndex = 209;
            this.tbHHCurYTDBabySvcsPercent.Tag = "HHRcvdBabyServicesPercent";
            this.tbHHCurYTDBabySvcsPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDSingleOtherPercent
            // 
            this.tbHHCurYTDSingleOtherPercent.AccessibleName = "";
            this.tbHHCurYTDSingleOtherPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleOtherPercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDSingleOtherPercent.Location = new System.Drawing.Point(57, 305);
            this.tbHHCurYTDSingleOtherPercent.Name = "tbHHCurYTDSingleOtherPercent";
            this.tbHHCurYTDSingleOtherPercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDSingleOtherPercent.TabIndex = 197;
            this.tbHHCurYTDSingleOtherPercent.Tag = "HHSingleOtherPercent";
            this.tbHHCurYTDSingleOtherPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDSingleMalePercent
            // 
            this.tbHHCurYTDSingleMalePercent.AccessibleName = "";
            this.tbHHCurYTDSingleMalePercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleMalePercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDSingleMalePercent.Location = new System.Drawing.Point(57, 282);
            this.tbHHCurYTDSingleMalePercent.Name = "tbHHCurYTDSingleMalePercent";
            this.tbHHCurYTDSingleMalePercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDSingleMalePercent.TabIndex = 195;
            this.tbHHCurYTDSingleMalePercent.Tag = "HHSingleMalePercent";
            this.tbHHCurYTDSingleMalePercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDBabySvcs
            // 
            this.tbHHDifYTDBabySvcs.AccessibleName = "";
            this.tbHHDifYTDBabySvcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDBabySvcs.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDBabySvcs.Location = new System.Drawing.Point(3, 125);
            this.tbHHDifYTDBabySvcs.Name = "tbHHDifYTDBabySvcs";
            this.tbHHDifYTDBabySvcs.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDBabySvcs.TabIndex = 208;
            this.tbHHDifYTDBabySvcs.Tag = "HHRcvdBabyServices";
            this.tbHHDifYTDBabySvcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHCurYTDOneParentMalePercent
            // 
            this.tbHHCurYTDOneParentMalePercent.AccessibleName = "";
            this.tbHHCurYTDOneParentMalePercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentMalePercent.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHCurYTDOneParentMalePercent.Location = new System.Drawing.Point(57, 378);
            this.tbHHCurYTDOneParentMalePercent.Name = "tbHHCurYTDOneParentMalePercent";
            this.tbHHCurYTDOneParentMalePercent.Size = new System.Drawing.Size(50, 20);
            this.tbHHCurYTDOneParentMalePercent.TabIndex = 201;
            this.tbHHCurYTDOneParentMalePercent.Tag = "HHOneParentMalePercent";
            this.tbHHCurYTDOneParentMalePercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDSingleMale
            // 
            this.tbHHDifYTDSingleMale.AccessibleName = "";
            this.tbHHDifYTDSingleMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDSingleMale.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDSingleMale.Location = new System.Drawing.Point(3, 282);
            this.tbHHDifYTDSingleMale.Name = "tbHHDifYTDSingleMale";
            this.tbHHDifYTDSingleMale.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDSingleMale.TabIndex = 194;
            this.tbHHDifYTDSingleMale.Tag = "HHSingleMale";
            this.tbHHDifYTDSingleMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbHHDifYTDOneParentMale
            // 
            this.tbHHDifYTDOneParentMale.AccessibleName = "";
            this.tbHHDifYTDOneParentMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHDifYTDOneParentMale.ForeColor = System.Drawing.Color.DarkBlue;
            this.tbHHDifYTDOneParentMale.Location = new System.Drawing.Point(3, 377);
            this.tbHHDifYTDOneParentMale.Name = "tbHHDifYTDOneParentMale";
            this.tbHHDifYTDOneParentMale.Size = new System.Drawing.Size(50, 20);
            this.tbHHDifYTDOneParentMale.TabIndex = 200;
            this.tbHHDifYTDOneParentMale.Tag = "HHOneParentMale";
            this.tbHHDifYTDOneParentMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label60
            // 
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.Dock = System.Windows.Forms.DockStyle.Top;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(0, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(111, 19);
            this.label60.TabIndex = 191;
            this.label60.Text = "Change";
            this.label60.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(66, 280);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(75, 15);
            this.label61.TabIndex = 263;
            this.label61.Text = "Transient";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlHHCurYTD
            // 
            this.pnlHHCurYTD.BackColor = System.Drawing.Color.Beige;
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDInCityLimitsReturning);
            this.pnlHHCurYTD.Controls.Add(this.label79);
            this.pnlHHCurYTD.Controls.Add(this.label85);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDInCityLimitsNew);
            this.pnlHHCurYTD.Controls.Add(this.label90);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTransientReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTotalServedNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDHomeless);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTransientNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDHomelessNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTotalServed);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDHomelessReturning);
            this.pnlHHCurYTD.Controls.Add(this.label92);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTotalServedReturning);
            this.pnlHHCurYTD.Controls.Add(this.label93);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentFemaleReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSupplementalReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentFemaleNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSupplementalNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDCommodityReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleOtherNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDCommodityNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentOther);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDBabySvcsReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentMale);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleOtherReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentFemale);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDBabySvcsNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleOther);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDParentMaleReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleMale);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentMaleNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleFemale);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleMaleNew);
            this.pnlHHCurYTD.Controls.Add(this.label94);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleMaleReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDCommodity);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleFemaleReturning);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSupplemental);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentOtherNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDSingleFemaleNew);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDBabySvcs);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDTransient);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDInCityLimits);
            this.pnlHHCurYTD.Controls.Add(this.tbHHCurYTDOneParentOtherReturning);
            this.pnlHHCurYTD.Controls.Add(this.lblHHCurYTD);
            this.pnlHHCurYTD.Location = new System.Drawing.Point(143, 99);
            this.pnlHHCurYTD.Name = "pnlHHCurYTD";
            this.pnlHHCurYTD.Size = new System.Drawing.Size(200, 427);
            this.pnlHHCurYTD.TabIndex = 276;
            // 
            // tbHHCurYTDInCityLimitsReturning
            // 
            this.tbHHCurYTDInCityLimitsReturning.AccessibleName = "";
            this.tbHHCurYTDInCityLimitsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDInCityLimitsReturning.Location = new System.Drawing.Point(66, 207);
            this.tbHHCurYTDInCityLimitsReturning.Name = "tbHHCurYTDInCityLimitsReturning";
            this.tbHHCurYTDInCityLimitsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDInCityLimitsReturning.TabIndex = 84;
            this.tbHHCurYTDInCityLimitsReturning.Tag = "HHInCityLimitsReturning";
            this.tbHHCurYTDInCityLimitsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.Color.Maroon;
            this.label79.Location = new System.Drawing.Point(3, 330);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(93, 17);
            this.label79.TabIndex = 140;
            this.label79.Text = "Single Parent";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.Color.Maroon;
            this.label85.Location = new System.Drawing.Point(3, 57);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(134, 17);
            this.label85.TabIndex = 66;
            this.label85.Text = "Household Services";
            // 
            // tbHHCurYTDInCityLimitsNew
            // 
            this.tbHHCurYTDInCityLimitsNew.AccessibleName = "";
            this.tbHHCurYTDInCityLimitsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDInCityLimitsNew.Location = new System.Drawing.Point(3, 207);
            this.tbHHCurYTDInCityLimitsNew.Name = "tbHHCurYTDInCityLimitsNew";
            this.tbHHCurYTDInCityLimitsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDInCityLimitsNew.TabIndex = 83;
            this.tbHHCurYTDInCityLimitsNew.Tag = "HHInCityLimitsNew";
            this.tbHHCurYTDInCityLimitsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.ForeColor = System.Drawing.Color.Maroon;
            this.label90.Location = new System.Drawing.Point(3, 235);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(84, 17);
            this.label90.TabIndex = 139;
            this.label90.Text = "One Person";
            // 
            // tbHHCurYTDTransientReturning
            // 
            this.tbHHCurYTDTransientReturning.AccessibleName = "";
            this.tbHHCurYTDTransientReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTransientReturning.Location = new System.Drawing.Point(66, 178);
            this.tbHHCurYTDTransientReturning.Name = "tbHHCurYTDTransientReturning";
            this.tbHHCurYTDTransientReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDTransientReturning.TabIndex = 43;
            this.tbHHCurYTDTransientReturning.Tag = "HHTransientReturning";
            this.tbHHCurYTDTransientReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDTotalServedNew
            // 
            this.tbHHCurYTDTotalServedNew.AccessibleName = "";
            this.tbHHCurYTDTotalServedNew.BackColor = System.Drawing.Color.White;
            this.tbHHCurYTDTotalServedNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTotalServedNew.ForeColor = System.Drawing.Color.Black;
            this.tbHHCurYTDTotalServedNew.Location = new System.Drawing.Point(3, 39);
            this.tbHHCurYTDTotalServedNew.Name = "tbHHCurYTDTotalServedNew";
            this.tbHHCurYTDTotalServedNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDTotalServedNew.TabIndex = 26;
            this.tbHHCurYTDTotalServedNew.Tag = "HHTotalServedNew";
            this.tbHHCurYTDTotalServedNew.Text = "500,569";
            this.tbHHCurYTDTotalServedNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDHomeless
            // 
            this.tbHHCurYTDHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDHomeless.Location = new System.Drawing.Point(132, 152);
            this.tbHHCurYTDHomeless.Name = "tbHHCurYTDHomeless";
            this.tbHHCurYTDHomeless.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDHomeless.TabIndex = 178;
            this.tbHHCurYTDHomeless.Tag = "HHHomeless";
            this.tbHHCurYTDHomeless.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDTransientNew
            // 
            this.tbHHCurYTDTransientNew.AccessibleName = "";
            this.tbHHCurYTDTransientNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTransientNew.Location = new System.Drawing.Point(3, 179);
            this.tbHHCurYTDTransientNew.Name = "tbHHCurYTDTransientNew";
            this.tbHHCurYTDTransientNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDTransientNew.TabIndex = 44;
            this.tbHHCurYTDTransientNew.Tag = "HHTransientNew";
            this.tbHHCurYTDTransientNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDHomelessNew
            // 
            this.tbHHCurYTDHomelessNew.AccessibleName = "";
            this.tbHHCurYTDHomelessNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDHomelessNew.Location = new System.Drawing.Point(3, 153);
            this.tbHHCurYTDHomelessNew.Name = "tbHHCurYTDHomelessNew";
            this.tbHHCurYTDHomelessNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDHomelessNew.TabIndex = 176;
            this.tbHHCurYTDHomelessNew.Tag = "HHHomelessNew";
            this.tbHHCurYTDHomelessNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDTotalServed
            // 
            this.tbHHCurYTDTotalServed.BackColor = System.Drawing.Color.White;
            this.tbHHCurYTDTotalServed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTotalServed.Location = new System.Drawing.Point(132, 39);
            this.tbHHCurYTDTotalServed.Name = "tbHHCurYTDTotalServed";
            this.tbHHCurYTDTotalServed.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDTotalServed.TabIndex = 88;
            this.tbHHCurYTDTotalServed.Tag = "HHTotalServed";
            this.tbHHCurYTDTotalServed.Text = "356,987";
            this.tbHHCurYTDTotalServed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDHomelessReturning
            // 
            this.tbHHCurYTDHomelessReturning.AccessibleName = "";
            this.tbHHCurYTDHomelessReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDHomelessReturning.Location = new System.Drawing.Point(66, 152);
            this.tbHHCurYTDHomelessReturning.Name = "tbHHCurYTDHomelessReturning";
            this.tbHHCurYTDHomelessReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDHomelessReturning.TabIndex = 175;
            this.tbHHCurYTDHomelessReturning.Tag = "HHHomelessReturning";
            this.tbHHCurYTDHomelessReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label92
            // 
            this.label92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.Color.Black;
            this.label92.Location = new System.Drawing.Point(3, 19);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(60, 18);
            this.label92.TabIndex = 25;
            this.label92.Text = "New";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHCurYTDTotalServedReturning
            // 
            this.tbHHCurYTDTotalServedReturning.AccessibleName = "";
            this.tbHHCurYTDTotalServedReturning.BackColor = System.Drawing.Color.White;
            this.tbHHCurYTDTotalServedReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTotalServedReturning.ForeColor = System.Drawing.Color.Black;
            this.tbHHCurYTDTotalServedReturning.Location = new System.Drawing.Point(66, 39);
            this.tbHHCurYTDTotalServedReturning.Name = "tbHHCurYTDTotalServedReturning";
            this.tbHHCurYTDTotalServedReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDTotalServedReturning.TabIndex = 23;
            this.tbHHCurYTDTotalServedReturning.Tag = "HHTotalServedReturning";
            this.tbHHCurYTDTotalServedReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label93
            // 
            this.label93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.ForeColor = System.Drawing.Color.Black;
            this.label93.Location = new System.Drawing.Point(66, 19);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(60, 18);
            this.label93.TabIndex = 0;
            this.label93.Text = "Returning";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHCurYTDOneParentFemaleReturning
            // 
            this.tbHHCurYTDOneParentFemaleReturning.AccessibleName = "";
            this.tbHHCurYTDOneParentFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentFemaleReturning.Location = new System.Drawing.Point(66, 350);
            this.tbHHCurYTDOneParentFemaleReturning.Name = "tbHHCurYTDOneParentFemaleReturning";
            this.tbHHCurYTDOneParentFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDOneParentFemaleReturning.TabIndex = 110;
            this.tbHHCurYTDOneParentFemaleReturning.Tag = "HHOneParentFemaleReturning";
            this.tbHHCurYTDOneParentFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSupplementalReturning
            // 
            this.tbHHCurYTDSupplementalReturning.AccessibleName = "";
            this.tbHHCurYTDSupplementalReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSupplementalReturning.Location = new System.Drawing.Point(66, 99);
            this.tbHHCurYTDSupplementalReturning.Name = "tbHHCurYTDSupplementalReturning";
            this.tbHHCurYTDSupplementalReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSupplementalReturning.TabIndex = 130;
            this.tbHHCurYTDSupplementalReturning.Tag = "HHRcvdSupplementalReturning";
            this.tbHHCurYTDSupplementalReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentFemaleNew
            // 
            this.tbHHCurYTDOneParentFemaleNew.AccessibleName = "";
            this.tbHHCurYTDOneParentFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentFemaleNew.Location = new System.Drawing.Point(3, 350);
            this.tbHHCurYTDOneParentFemaleNew.Name = "tbHHCurYTDOneParentFemaleNew";
            this.tbHHCurYTDOneParentFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDOneParentFemaleNew.TabIndex = 109;
            this.tbHHCurYTDOneParentFemaleNew.Tag = "HHOneParentFemaleNew";
            this.tbHHCurYTDOneParentFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSupplementalNew
            // 
            this.tbHHCurYTDSupplementalNew.AccessibleName = "";
            this.tbHHCurYTDSupplementalNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSupplementalNew.Location = new System.Drawing.Point(3, 99);
            this.tbHHCurYTDSupplementalNew.Name = "tbHHCurYTDSupplementalNew";
            this.tbHHCurYTDSupplementalNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSupplementalNew.TabIndex = 129;
            this.tbHHCurYTDSupplementalNew.Tag = "HHRcvdSupplementalNew";
            this.tbHHCurYTDSupplementalNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDCommodityReturning
            // 
            this.tbHHCurYTDCommodityReturning.AccessibleName = "";
            this.tbHHCurYTDCommodityReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDCommodityReturning.Location = new System.Drawing.Point(66, 76);
            this.tbHHCurYTDCommodityReturning.Name = "tbHHCurYTDCommodityReturning";
            this.tbHHCurYTDCommodityReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDCommodityReturning.TabIndex = 124;
            this.tbHHCurYTDCommodityReturning.Tag = "HHRcvdCommodityReturning";
            this.tbHHCurYTDCommodityReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleOtherNew
            // 
            this.tbHHCurYTDSingleOtherNew.AccessibleName = "";
            this.tbHHCurYTDSingleOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleOtherNew.Location = new System.Drawing.Point(3, 304);
            this.tbHHCurYTDSingleOtherNew.Name = "tbHHCurYTDSingleOtherNew";
            this.tbHHCurYTDSingleOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleOtherNew.TabIndex = 104;
            this.tbHHCurYTDSingleOtherNew.Tag = "HHSingleOtherNew";
            this.tbHHCurYTDSingleOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDCommodityNew
            // 
            this.tbHHCurYTDCommodityNew.AccessibleName = "";
            this.tbHHCurYTDCommodityNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDCommodityNew.Location = new System.Drawing.Point(3, 77);
            this.tbHHCurYTDCommodityNew.Name = "tbHHCurYTDCommodityNew";
            this.tbHHCurYTDCommodityNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDCommodityNew.TabIndex = 125;
            this.tbHHCurYTDCommodityNew.Tag = "HHRcvdCommodityNew";
            this.tbHHCurYTDCommodityNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentOther
            // 
            this.tbHHCurYTDOneParentOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentOther.Location = new System.Drawing.Point(132, 403);
            this.tbHHCurYTDOneParentOther.Name = "tbHHCurYTDOneParentOther";
            this.tbHHCurYTDOneParentOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDOneParentOther.TabIndex = 166;
            this.tbHHCurYTDOneParentOther.Tag = "HHOneParentOther";
            this.tbHHCurYTDOneParentOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDBabySvcsReturning
            // 
            this.tbHHCurYTDBabySvcsReturning.AccessibleName = "";
            this.tbHHCurYTDBabySvcsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDBabySvcsReturning.Location = new System.Drawing.Point(66, 126);
            this.tbHHCurYTDBabySvcsReturning.Name = "tbHHCurYTDBabySvcsReturning";
            this.tbHHCurYTDBabySvcsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDBabySvcsReturning.TabIndex = 135;
            this.tbHHCurYTDBabySvcsReturning.Tag = "HHRcvdBabyServicesReturning";
            this.tbHHCurYTDBabySvcsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentMale
            // 
            this.tbHHCurYTDOneParentMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentMale.Location = new System.Drawing.Point(132, 378);
            this.tbHHCurYTDOneParentMale.Name = "tbHHCurYTDOneParentMale";
            this.tbHHCurYTDOneParentMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDOneParentMale.TabIndex = 165;
            this.tbHHCurYTDOneParentMale.Tag = "HHOneParentMale";
            this.tbHHCurYTDOneParentMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleOtherReturning
            // 
            this.tbHHCurYTDSingleOtherReturning.AccessibleName = "";
            this.tbHHCurYTDSingleOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleOtherReturning.Location = new System.Drawing.Point(66, 305);
            this.tbHHCurYTDSingleOtherReturning.Name = "tbHHCurYTDSingleOtherReturning";
            this.tbHHCurYTDSingleOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleOtherReturning.TabIndex = 105;
            this.tbHHCurYTDSingleOtherReturning.Tag = "HHSingleOtherReturning";
            this.tbHHCurYTDSingleOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentFemale
            // 
            this.tbHHCurYTDOneParentFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentFemale.Location = new System.Drawing.Point(132, 349);
            this.tbHHCurYTDOneParentFemale.Name = "tbHHCurYTDOneParentFemale";
            this.tbHHCurYTDOneParentFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDOneParentFemale.TabIndex = 164;
            this.tbHHCurYTDOneParentFemale.Tag = "HHOneParentFemale";
            this.tbHHCurYTDOneParentFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDBabySvcsNew
            // 
            this.tbHHCurYTDBabySvcsNew.AccessibleName = "";
            this.tbHHCurYTDBabySvcsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDBabySvcsNew.Location = new System.Drawing.Point(3, 126);
            this.tbHHCurYTDBabySvcsNew.Name = "tbHHCurYTDBabySvcsNew";
            this.tbHHCurYTDBabySvcsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDBabySvcsNew.TabIndex = 134;
            this.tbHHCurYTDBabySvcsNew.Tag = "HHRcvdBabyServicesNew";
            this.tbHHCurYTDBabySvcsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleOther
            // 
            this.tbHHCurYTDSingleOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleOther.Location = new System.Drawing.Point(132, 304);
            this.tbHHCurYTDSingleOther.Name = "tbHHCurYTDSingleOther";
            this.tbHHCurYTDSingleOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDSingleOther.TabIndex = 163;
            this.tbHHCurYTDSingleOther.Tag = "HHSingleOther";
            this.tbHHCurYTDSingleOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDParentMaleReturning
            // 
            this.tbHHCurYTDParentMaleReturning.AccessibleName = "";
            this.tbHHCurYTDParentMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDParentMaleReturning.Location = new System.Drawing.Point(66, 377);
            this.tbHHCurYTDParentMaleReturning.Name = "tbHHCurYTDParentMaleReturning";
            this.tbHHCurYTDParentMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDParentMaleReturning.TabIndex = 115;
            this.tbHHCurYTDParentMaleReturning.Tag = "HHOneParentMaleReturning";
            this.tbHHCurYTDParentMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleMale
            // 
            this.tbHHCurYTDSingleMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleMale.Location = new System.Drawing.Point(132, 280);
            this.tbHHCurYTDSingleMale.Name = "tbHHCurYTDSingleMale";
            this.tbHHCurYTDSingleMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDSingleMale.TabIndex = 162;
            this.tbHHCurYTDSingleMale.Tag = "HHSingleMale";
            this.tbHHCurYTDSingleMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentMaleNew
            // 
            this.tbHHCurYTDOneParentMaleNew.AccessibleName = "";
            this.tbHHCurYTDOneParentMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentMaleNew.Location = new System.Drawing.Point(3, 377);
            this.tbHHCurYTDOneParentMaleNew.Name = "tbHHCurYTDOneParentMaleNew";
            this.tbHHCurYTDOneParentMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDOneParentMaleNew.TabIndex = 114;
            this.tbHHCurYTDOneParentMaleNew.Tag = "HHOneParentMaleNew";
            this.tbHHCurYTDOneParentMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleFemale
            // 
            this.tbHHCurYTDSingleFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleFemale.Location = new System.Drawing.Point(132, 254);
            this.tbHHCurYTDSingleFemale.Name = "tbHHCurYTDSingleFemale";
            this.tbHHCurYTDSingleFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDSingleFemale.TabIndex = 161;
            this.tbHHCurYTDSingleFemale.Tag = "HHSingleFemale";
            this.tbHHCurYTDSingleFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleMaleNew
            // 
            this.tbHHCurYTDSingleMaleNew.AccessibleName = "";
            this.tbHHCurYTDSingleMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleMaleNew.Location = new System.Drawing.Point(3, 281);
            this.tbHHCurYTDSingleMaleNew.Name = "tbHHCurYTDSingleMaleNew";
            this.tbHHCurYTDSingleMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleMaleNew.TabIndex = 99;
            this.tbHHCurYTDSingleMaleNew.Tag = "HHSingleMaleNew";
            this.tbHHCurYTDSingleMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label94
            // 
            this.label94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.ForeColor = System.Drawing.Color.Black;
            this.label94.Location = new System.Drawing.Point(132, 19);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(60, 18);
            this.label94.TabIndex = 147;
            this.label94.Text = "Total";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHCurYTDSingleMaleReturning
            // 
            this.tbHHCurYTDSingleMaleReturning.AccessibleName = "";
            this.tbHHCurYTDSingleMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleMaleReturning.Location = new System.Drawing.Point(66, 282);
            this.tbHHCurYTDSingleMaleReturning.Name = "tbHHCurYTDSingleMaleReturning";
            this.tbHHCurYTDSingleMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleMaleReturning.TabIndex = 100;
            this.tbHHCurYTDSingleMaleReturning.Tag = "HHSingleMaleReturning";
            this.tbHHCurYTDSingleMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDCommodity
            // 
            this.tbHHCurYTDCommodity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDCommodity.Location = new System.Drawing.Point(132, 76);
            this.tbHHCurYTDCommodity.Name = "tbHHCurYTDCommodity";
            this.tbHHCurYTDCommodity.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDCommodity.TabIndex = 149;
            this.tbHHCurYTDCommodity.Tag = "HHRcvdCommodity";
            this.tbHHCurYTDCommodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleFemaleReturning
            // 
            this.tbHHCurYTDSingleFemaleReturning.AccessibleName = "";
            this.tbHHCurYTDSingleFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleFemaleReturning.Location = new System.Drawing.Point(66, 255);
            this.tbHHCurYTDSingleFemaleReturning.Name = "tbHHCurYTDSingleFemaleReturning";
            this.tbHHCurYTDSingleFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleFemaleReturning.TabIndex = 95;
            this.tbHHCurYTDSingleFemaleReturning.Tag = "HHSingleFemaleReturning";
            this.tbHHCurYTDSingleFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSupplemental
            // 
            this.tbHHCurYTDSupplemental.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSupplemental.Location = new System.Drawing.Point(132, 98);
            this.tbHHCurYTDSupplemental.Name = "tbHHCurYTDSupplemental";
            this.tbHHCurYTDSupplemental.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDSupplemental.TabIndex = 150;
            this.tbHHCurYTDSupplemental.Tag = "HHRcvdSupplemental";
            this.tbHHCurYTDSupplemental.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentOtherNew
            // 
            this.tbHHCurYTDOneParentOtherNew.AccessibleName = "";
            this.tbHHCurYTDOneParentOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentOtherNew.Location = new System.Drawing.Point(3, 404);
            this.tbHHCurYTDOneParentOtherNew.Name = "tbHHCurYTDOneParentOtherNew";
            this.tbHHCurYTDOneParentOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDOneParentOtherNew.TabIndex = 119;
            this.tbHHCurYTDOneParentOtherNew.Tag = "HHOneParentOtherNew";
            this.tbHHCurYTDOneParentOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDSingleFemaleNew
            // 
            this.tbHHCurYTDSingleFemaleNew.AccessibleName = "";
            this.tbHHCurYTDSingleFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDSingleFemaleNew.Location = new System.Drawing.Point(3, 254);
            this.tbHHCurYTDSingleFemaleNew.Name = "tbHHCurYTDSingleFemaleNew";
            this.tbHHCurYTDSingleFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDSingleFemaleNew.TabIndex = 94;
            this.tbHHCurYTDSingleFemaleNew.Tag = "HHSingleFemaleNew";
            this.tbHHCurYTDSingleFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDBabySvcs
            // 
            this.tbHHCurYTDBabySvcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDBabySvcs.Location = new System.Drawing.Point(132, 125);
            this.tbHHCurYTDBabySvcs.Name = "tbHHCurYTDBabySvcs";
            this.tbHHCurYTDBabySvcs.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDBabySvcs.TabIndex = 151;
            this.tbHHCurYTDBabySvcs.Tag = "HHRcvdBabyServices";
            this.tbHHCurYTDBabySvcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDTransient
            // 
            this.tbHHCurYTDTransient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDTransient.Location = new System.Drawing.Point(132, 178);
            this.tbHHCurYTDTransient.Name = "tbHHCurYTDTransient";
            this.tbHHCurYTDTransient.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDTransient.TabIndex = 153;
            this.tbHHCurYTDTransient.Tag = "HHTransient";
            this.tbHHCurYTDTransient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDInCityLimits
            // 
            this.tbHHCurYTDInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDInCityLimits.Location = new System.Drawing.Point(132, 206);
            this.tbHHCurYTDInCityLimits.Name = "tbHHCurYTDInCityLimits";
            this.tbHHCurYTDInCityLimits.Size = new System.Drawing.Size(62, 20);
            this.tbHHCurYTDInCityLimits.TabIndex = 154;
            this.tbHHCurYTDInCityLimits.Tag = "HHInCityLimits";
            this.tbHHCurYTDInCityLimits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHCurYTDOneParentOtherReturning
            // 
            this.tbHHCurYTDOneParentOtherReturning.AccessibleName = "";
            this.tbHHCurYTDOneParentOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHCurYTDOneParentOtherReturning.Location = new System.Drawing.Point(66, 404);
            this.tbHHCurYTDOneParentOtherReturning.Name = "tbHHCurYTDOneParentOtherReturning";
            this.tbHHCurYTDOneParentOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHCurYTDOneParentOtherReturning.TabIndex = 120;
            this.tbHHCurYTDOneParentOtherReturning.Tag = "HHOneParentOtherReturning";
            this.tbHHCurYTDOneParentOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblHHCurYTD
            // 
            this.lblHHCurYTD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHHCurYTD.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHHCurYTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHCurYTD.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lblHHCurYTD.Location = new System.Drawing.Point(0, 0);
            this.lblHHCurYTD.Name = "lblHHCurYTD";
            this.lblHHCurYTD.Size = new System.Drawing.Size(200, 19);
            this.lblHHCurYTD.TabIndex = 90;
            this.lblHHCurYTD.Tag = "Current Fiscal YTD - ";
            this.lblHHCurYTD.Text = "Current Fiscal YTD - ";
            this.lblHHCurYTD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label96
            // 
            this.label96.BackColor = System.Drawing.Color.Transparent;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.ForeColor = System.Drawing.Color.Black;
            this.label96.Location = new System.Drawing.Point(66, 307);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(75, 15);
            this.label96.TabIndex = 264;
            this.label96.Text = "In City Limits";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlHHPvYrYTD
            // 
            this.pnlHHPvYrYTD.BackColor = System.Drawing.Color.Cornsilk;
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDHomeless);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDInCityLimitsReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDHomelessNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDInCityLimitsNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDHomelessReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTransientReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentOther);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTotalServedNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentMale);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTransientNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentFemale);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTotalServed);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleOther);
            this.pnlHHPvYrYTD.Controls.Add(this.label97);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleMale);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTotalServedReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleFemale);
            this.pnlHHPvYrYTD.Controls.Add(this.label98);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleFemaleReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentFemaleReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleFemaleNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSupplementalReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentOtherReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentFemaleNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDInCityLimits);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSupplementalNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDTransient);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDCommodityReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDBabySvcs);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleOtherNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentOtherNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDCommodityNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSupplemental);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDBabySvcsReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDCommodity);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleOtherReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleMaleReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDBabySvcsNew);
            this.pnlHHPvYrYTD.Controls.Add(this.label99);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDParentMaleReturning);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDSingleMaleNew);
            this.pnlHHPvYrYTD.Controls.Add(this.tbHHPvYrYTDOneParentMaleNew);
            this.pnlHHPvYrYTD.Controls.Add(this.lblHHPrev1YTD);
            this.pnlHHPvYrYTD.Location = new System.Drawing.Point(462, 99);
            this.pnlHHPvYrYTD.Name = "pnlHHPvYrYTD";
            this.pnlHHPvYrYTD.Size = new System.Drawing.Size(200, 427);
            this.pnlHHPvYrYTD.TabIndex = 275;
            // 
            // tbHHPvYrYTDHomeless
            // 
            this.tbHHPvYrYTDHomeless.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDHomeless.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDHomeless.Location = new System.Drawing.Point(133, 151);
            this.tbHHPvYrYTDHomeless.Name = "tbHHPvYrYTDHomeless";
            this.tbHHPvYrYTDHomeless.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDHomeless.TabIndex = 224;
            this.tbHHPvYrYTDHomeless.Tag = "HHHomeless";
            this.tbHHPvYrYTDHomeless.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDInCityLimitsReturning
            // 
            this.tbHHPvYrYTDInCityLimitsReturning.AccessibleName = "";
            this.tbHHPvYrYTDInCityLimitsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDInCityLimitsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDInCityLimitsReturning.Location = new System.Drawing.Point(66, 206);
            this.tbHHPvYrYTDInCityLimitsReturning.Name = "tbHHPvYrYTDInCityLimitsReturning";
            this.tbHHPvYrYTDInCityLimitsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDInCityLimitsReturning.TabIndex = 189;
            this.tbHHPvYrYTDInCityLimitsReturning.Tag = "HHInCityLimitsReturning";
            this.tbHHPvYrYTDInCityLimitsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDHomelessNew
            // 
            this.tbHHPvYrYTDHomelessNew.AccessibleName = "";
            this.tbHHPvYrYTDHomelessNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDHomelessNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDHomelessNew.Location = new System.Drawing.Point(3, 152);
            this.tbHHPvYrYTDHomelessNew.Name = "tbHHPvYrYTDHomelessNew";
            this.tbHHPvYrYTDHomelessNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDHomelessNew.TabIndex = 223;
            this.tbHHPvYrYTDHomelessNew.Tag = "HHHomelessNew";
            this.tbHHPvYrYTDHomelessNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDInCityLimitsNew
            // 
            this.tbHHPvYrYTDInCityLimitsNew.AccessibleName = "";
            this.tbHHPvYrYTDInCityLimitsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDInCityLimitsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDInCityLimitsNew.Location = new System.Drawing.Point(3, 206);
            this.tbHHPvYrYTDInCityLimitsNew.Name = "tbHHPvYrYTDInCityLimitsNew";
            this.tbHHPvYrYTDInCityLimitsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDInCityLimitsNew.TabIndex = 188;
            this.tbHHPvYrYTDInCityLimitsNew.Tag = "HHInCityLimitsNew";
            this.tbHHPvYrYTDInCityLimitsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDHomelessReturning
            // 
            this.tbHHPvYrYTDHomelessReturning.AccessibleName = "";
            this.tbHHPvYrYTDHomelessReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDHomelessReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDHomelessReturning.Location = new System.Drawing.Point(66, 151);
            this.tbHHPvYrYTDHomelessReturning.Name = "tbHHPvYrYTDHomelessReturning";
            this.tbHHPvYrYTDHomelessReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDHomelessReturning.TabIndex = 222;
            this.tbHHPvYrYTDHomelessReturning.Tag = "HHHomelessReturning";
            this.tbHHPvYrYTDHomelessReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTransientReturning
            // 
            this.tbHHPvYrYTDTransientReturning.AccessibleName = "";
            this.tbHHPvYrYTDTransientReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTransientReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTransientReturning.Location = new System.Drawing.Point(66, 177);
            this.tbHHPvYrYTDTransientReturning.Name = "tbHHPvYrYTDTransientReturning";
            this.tbHHPvYrYTDTransientReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDTransientReturning.TabIndex = 186;
            this.tbHHPvYrYTDTransientReturning.Tag = "HHTransientReturning";
            this.tbHHPvYrYTDTransientReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentOther
            // 
            this.tbHHPvYrYTDOneParentOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentOther.Location = new System.Drawing.Point(133, 405);
            this.tbHHPvYrYTDOneParentOther.Name = "tbHHPvYrYTDOneParentOther";
            this.tbHHPvYrYTDOneParentOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDOneParentOther.TabIndex = 221;
            this.tbHHPvYrYTDOneParentOther.Tag = "HHOneParentOther";
            this.tbHHPvYrYTDOneParentOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTotalServedNew
            // 
            this.tbHHPvYrYTDTotalServedNew.AccessibleName = "";
            this.tbHHPvYrYTDTotalServedNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTotalServedNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTotalServedNew.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvYrYTDTotalServedNew.Location = new System.Drawing.Point(3, 38);
            this.tbHHPvYrYTDTotalServedNew.Name = "tbHHPvYrYTDTotalServedNew";
            this.tbHHPvYrYTDTotalServedNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDTotalServedNew.TabIndex = 185;
            this.tbHHPvYrYTDTotalServedNew.Tag = "HHTotalServedNew";
            this.tbHHPvYrYTDTotalServedNew.Text = "500,569";
            this.tbHHPvYrYTDTotalServedNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentMale
            // 
            this.tbHHPvYrYTDOneParentMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentMale.Location = new System.Drawing.Point(133, 380);
            this.tbHHPvYrYTDOneParentMale.Name = "tbHHPvYrYTDOneParentMale";
            this.tbHHPvYrYTDOneParentMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDOneParentMale.TabIndex = 220;
            this.tbHHPvYrYTDOneParentMale.Tag = "HHOneParentMale";
            this.tbHHPvYrYTDOneParentMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTransientNew
            // 
            this.tbHHPvYrYTDTransientNew.AccessibleName = "";
            this.tbHHPvYrYTDTransientNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTransientNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTransientNew.Location = new System.Drawing.Point(3, 178);
            this.tbHHPvYrYTDTransientNew.Name = "tbHHPvYrYTDTransientNew";
            this.tbHHPvYrYTDTransientNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDTransientNew.TabIndex = 187;
            this.tbHHPvYrYTDTransientNew.Tag = "HHTransientNew";
            this.tbHHPvYrYTDTransientNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentFemale
            // 
            this.tbHHPvYrYTDOneParentFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentFemale.Location = new System.Drawing.Point(133, 351);
            this.tbHHPvYrYTDOneParentFemale.Name = "tbHHPvYrYTDOneParentFemale";
            this.tbHHPvYrYTDOneParentFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDOneParentFemale.TabIndex = 219;
            this.tbHHPvYrYTDOneParentFemale.Tag = "HHOneParentFemale";
            this.tbHHPvYrYTDOneParentFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTotalServed
            // 
            this.tbHHPvYrYTDTotalServed.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTotalServed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTotalServed.Location = new System.Drawing.Point(133, 38);
            this.tbHHPvYrYTDTotalServed.Name = "tbHHPvYrYTDTotalServed";
            this.tbHHPvYrYTDTotalServed.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDTotalServed.TabIndex = 190;
            this.tbHHPvYrYTDTotalServed.Tag = "HHTotalServed";
            this.tbHHPvYrYTDTotalServed.Text = "356,987";
            this.tbHHPvYrYTDTotalServed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleOther
            // 
            this.tbHHPvYrYTDSingleOther.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleOther.Location = new System.Drawing.Point(133, 304);
            this.tbHHPvYrYTDSingleOther.Name = "tbHHPvYrYTDSingleOther";
            this.tbHHPvYrYTDSingleOther.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDSingleOther.TabIndex = 218;
            this.tbHHPvYrYTDSingleOther.Tag = "HHSingleOther";
            this.tbHHPvYrYTDSingleOther.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label97
            // 
            this.label97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.ForeColor = System.Drawing.Color.Black;
            this.label97.Location = new System.Drawing.Point(3, 18);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(60, 18);
            this.label97.TabIndex = 184;
            this.label97.Text = "New";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvYrYTDSingleMale
            // 
            this.tbHHPvYrYTDSingleMale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleMale.Location = new System.Drawing.Point(133, 280);
            this.tbHHPvYrYTDSingleMale.Name = "tbHHPvYrYTDSingleMale";
            this.tbHHPvYrYTDSingleMale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDSingleMale.TabIndex = 217;
            this.tbHHPvYrYTDSingleMale.Tag = "HHSingleMale";
            this.tbHHPvYrYTDSingleMale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTotalServedReturning
            // 
            this.tbHHPvYrYTDTotalServedReturning.AccessibleName = "";
            this.tbHHPvYrYTDTotalServedReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTotalServedReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTotalServedReturning.ForeColor = System.Drawing.Color.Black;
            this.tbHHPvYrYTDTotalServedReturning.Location = new System.Drawing.Point(66, 38);
            this.tbHHPvYrYTDTotalServedReturning.Name = "tbHHPvYrYTDTotalServedReturning";
            this.tbHHPvYrYTDTotalServedReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDTotalServedReturning.TabIndex = 183;
            this.tbHHPvYrYTDTotalServedReturning.Tag = "HHTotalServedReturning";
            this.tbHHPvYrYTDTotalServedReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleFemale
            // 
            this.tbHHPvYrYTDSingleFemale.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleFemale.Location = new System.Drawing.Point(133, 254);
            this.tbHHPvYrYTDSingleFemale.Name = "tbHHPvYrYTDSingleFemale";
            this.tbHHPvYrYTDSingleFemale.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDSingleFemale.TabIndex = 216;
            this.tbHHPvYrYTDSingleFemale.Tag = "HHSingleFemale";
            this.tbHHPvYrYTDSingleFemale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label98
            // 
            this.label98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.ForeColor = System.Drawing.Color.Black;
            this.label98.Location = new System.Drawing.Point(66, 18);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(60, 18);
            this.label98.TabIndex = 182;
            this.label98.Text = "Returning";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvYrYTDSingleFemaleReturning
            // 
            this.tbHHPvYrYTDSingleFemaleReturning.AccessibleName = "";
            this.tbHHPvYrYTDSingleFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleFemaleReturning.Location = new System.Drawing.Point(66, 255);
            this.tbHHPvYrYTDSingleFemaleReturning.Name = "tbHHPvYrYTDSingleFemaleReturning";
            this.tbHHPvYrYTDSingleFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleFemaleReturning.TabIndex = 193;
            this.tbHHPvYrYTDSingleFemaleReturning.Tag = "HHSingleFemaleReturning";
            this.tbHHPvYrYTDSingleFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentFemaleReturning
            // 
            this.tbHHPvYrYTDOneParentFemaleReturning.AccessibleName = "";
            this.tbHHPvYrYTDOneParentFemaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentFemaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentFemaleReturning.Location = new System.Drawing.Point(66, 351);
            this.tbHHPvYrYTDOneParentFemaleReturning.Name = "tbHHPvYrYTDOneParentFemaleReturning";
            this.tbHHPvYrYTDOneParentFemaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDOneParentFemaleReturning.TabIndex = 199;
            this.tbHHPvYrYTDOneParentFemaleReturning.Tag = "HHOneParentFemaleReturning";
            this.tbHHPvYrYTDOneParentFemaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleFemaleNew
            // 
            this.tbHHPvYrYTDSingleFemaleNew.AccessibleName = "";
            this.tbHHPvYrYTDSingleFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleFemaleNew.Location = new System.Drawing.Point(3, 255);
            this.tbHHPvYrYTDSingleFemaleNew.Name = "tbHHPvYrYTDSingleFemaleNew";
            this.tbHHPvYrYTDSingleFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleFemaleNew.TabIndex = 192;
            this.tbHHPvYrYTDSingleFemaleNew.Tag = "HHSingleFemaleNew";
            this.tbHHPvYrYTDSingleFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSupplementalReturning
            // 
            this.tbHHPvYrYTDSupplementalReturning.AccessibleName = "";
            this.tbHHPvYrYTDSupplementalReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSupplementalReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSupplementalReturning.Location = new System.Drawing.Point(66, 98);
            this.tbHHPvYrYTDSupplementalReturning.Name = "tbHHPvYrYTDSupplementalReturning";
            this.tbHHPvYrYTDSupplementalReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSupplementalReturning.TabIndex = 207;
            this.tbHHPvYrYTDSupplementalReturning.Tag = "HHRcvdSupplementalReturning";
            this.tbHHPvYrYTDSupplementalReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentOtherReturning
            // 
            this.tbHHPvYrYTDOneParentOtherReturning.AccessibleName = "";
            this.tbHHPvYrYTDOneParentOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentOtherReturning.Location = new System.Drawing.Point(66, 405);
            this.tbHHPvYrYTDOneParentOtherReturning.Name = "tbHHPvYrYTDOneParentOtherReturning";
            this.tbHHPvYrYTDOneParentOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDOneParentOtherReturning.TabIndex = 203;
            this.tbHHPvYrYTDOneParentOtherReturning.Tag = "HHOneParentOtherReturning";
            this.tbHHPvYrYTDOneParentOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentFemaleNew
            // 
            this.tbHHPvYrYTDOneParentFemaleNew.AccessibleName = "";
            this.tbHHPvYrYTDOneParentFemaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentFemaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentFemaleNew.Location = new System.Drawing.Point(3, 350);
            this.tbHHPvYrYTDOneParentFemaleNew.Name = "tbHHPvYrYTDOneParentFemaleNew";
            this.tbHHPvYrYTDOneParentFemaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDOneParentFemaleNew.TabIndex = 198;
            this.tbHHPvYrYTDOneParentFemaleNew.Tag = "HHOneParentFemaleNew";
            this.tbHHPvYrYTDOneParentFemaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDInCityLimits
            // 
            this.tbHHPvYrYTDInCityLimits.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDInCityLimits.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDInCityLimits.Location = new System.Drawing.Point(133, 205);
            this.tbHHPvYrYTDInCityLimits.Name = "tbHHPvYrYTDInCityLimits";
            this.tbHHPvYrYTDInCityLimits.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDInCityLimits.TabIndex = 215;
            this.tbHHPvYrYTDInCityLimits.Tag = "HHInCityLimits";
            this.tbHHPvYrYTDInCityLimits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSupplementalNew
            // 
            this.tbHHPvYrYTDSupplementalNew.AccessibleName = "";
            this.tbHHPvYrYTDSupplementalNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSupplementalNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSupplementalNew.Location = new System.Drawing.Point(3, 98);
            this.tbHHPvYrYTDSupplementalNew.Name = "tbHHPvYrYTDSupplementalNew";
            this.tbHHPvYrYTDSupplementalNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSupplementalNew.TabIndex = 206;
            this.tbHHPvYrYTDSupplementalNew.Tag = "HHRcvdSupplementalNew";
            this.tbHHPvYrYTDSupplementalNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDTransient
            // 
            this.tbHHPvYrYTDTransient.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDTransient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDTransient.Location = new System.Drawing.Point(133, 177);
            this.tbHHPvYrYTDTransient.Name = "tbHHPvYrYTDTransient";
            this.tbHHPvYrYTDTransient.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDTransient.TabIndex = 214;
            this.tbHHPvYrYTDTransient.Tag = "HHTransient";
            this.tbHHPvYrYTDTransient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDCommodityReturning
            // 
            this.tbHHPvYrYTDCommodityReturning.AccessibleName = "";
            this.tbHHPvYrYTDCommodityReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDCommodityReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDCommodityReturning.Location = new System.Drawing.Point(66, 75);
            this.tbHHPvYrYTDCommodityReturning.Name = "tbHHPvYrYTDCommodityReturning";
            this.tbHHPvYrYTDCommodityReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDCommodityReturning.TabIndex = 204;
            this.tbHHPvYrYTDCommodityReturning.Tag = "HHRcvdCommodityReturning";
            this.tbHHPvYrYTDCommodityReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDBabySvcs
            // 
            this.tbHHPvYrYTDBabySvcs.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDBabySvcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDBabySvcs.Location = new System.Drawing.Point(133, 124);
            this.tbHHPvYrYTDBabySvcs.Name = "tbHHPvYrYTDBabySvcs";
            this.tbHHPvYrYTDBabySvcs.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDBabySvcs.TabIndex = 213;
            this.tbHHPvYrYTDBabySvcs.Tag = "HHRcvdBabyServices";
            this.tbHHPvYrYTDBabySvcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleOtherNew
            // 
            this.tbHHPvYrYTDSingleOtherNew.AccessibleName = "";
            this.tbHHPvYrYTDSingleOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleOtherNew.Location = new System.Drawing.Point(3, 305);
            this.tbHHPvYrYTDSingleOtherNew.Name = "tbHHPvYrYTDSingleOtherNew";
            this.tbHHPvYrYTDSingleOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleOtherNew.TabIndex = 196;
            this.tbHHPvYrYTDSingleOtherNew.Tag = "HHSingleOtherNew";
            this.tbHHPvYrYTDSingleOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentOtherNew
            // 
            this.tbHHPvYrYTDOneParentOtherNew.AccessibleName = "";
            this.tbHHPvYrYTDOneParentOtherNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentOtherNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentOtherNew.Location = new System.Drawing.Point(3, 404);
            this.tbHHPvYrYTDOneParentOtherNew.Name = "tbHHPvYrYTDOneParentOtherNew";
            this.tbHHPvYrYTDOneParentOtherNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDOneParentOtherNew.TabIndex = 202;
            this.tbHHPvYrYTDOneParentOtherNew.Tag = "HHOneParentOtherNew";
            this.tbHHPvYrYTDOneParentOtherNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDCommodityNew
            // 
            this.tbHHPvYrYTDCommodityNew.AccessibleName = "";
            this.tbHHPvYrYTDCommodityNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDCommodityNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDCommodityNew.Location = new System.Drawing.Point(3, 76);
            this.tbHHPvYrYTDCommodityNew.Name = "tbHHPvYrYTDCommodityNew";
            this.tbHHPvYrYTDCommodityNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDCommodityNew.TabIndex = 205;
            this.tbHHPvYrYTDCommodityNew.Tag = "HHRcvdCommodityNew";
            this.tbHHPvYrYTDCommodityNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSupplemental
            // 
            this.tbHHPvYrYTDSupplemental.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSupplemental.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSupplemental.Location = new System.Drawing.Point(133, 97);
            this.tbHHPvYrYTDSupplemental.Name = "tbHHPvYrYTDSupplemental";
            this.tbHHPvYrYTDSupplemental.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDSupplemental.TabIndex = 212;
            this.tbHHPvYrYTDSupplemental.Tag = "HHRcvdSupplemental";
            this.tbHHPvYrYTDSupplemental.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDBabySvcsReturning
            // 
            this.tbHHPvYrYTDBabySvcsReturning.AccessibleName = "";
            this.tbHHPvYrYTDBabySvcsReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDBabySvcsReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDBabySvcsReturning.Location = new System.Drawing.Point(66, 125);
            this.tbHHPvYrYTDBabySvcsReturning.Name = "tbHHPvYrYTDBabySvcsReturning";
            this.tbHHPvYrYTDBabySvcsReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDBabySvcsReturning.TabIndex = 209;
            this.tbHHPvYrYTDBabySvcsReturning.Tag = "HHRcvdBabyServicesReturning";
            this.tbHHPvYrYTDBabySvcsReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDCommodity
            // 
            this.tbHHPvYrYTDCommodity.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDCommodity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDCommodity.Location = new System.Drawing.Point(133, 75);
            this.tbHHPvYrYTDCommodity.Name = "tbHHPvYrYTDCommodity";
            this.tbHHPvYrYTDCommodity.Size = new System.Drawing.Size(62, 20);
            this.tbHHPvYrYTDCommodity.TabIndex = 211;
            this.tbHHPvYrYTDCommodity.Tag = "HHRcvdCommodity";
            this.tbHHPvYrYTDCommodity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleOtherReturning
            // 
            this.tbHHPvYrYTDSingleOtherReturning.AccessibleName = "";
            this.tbHHPvYrYTDSingleOtherReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleOtherReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleOtherReturning.Location = new System.Drawing.Point(66, 305);
            this.tbHHPvYrYTDSingleOtherReturning.Name = "tbHHPvYrYTDSingleOtherReturning";
            this.tbHHPvYrYTDSingleOtherReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleOtherReturning.TabIndex = 197;
            this.tbHHPvYrYTDSingleOtherReturning.Tag = "HHSingleOtherReturning";
            this.tbHHPvYrYTDSingleOtherReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleMaleReturning
            // 
            this.tbHHPvYrYTDSingleMaleReturning.AccessibleName = "";
            this.tbHHPvYrYTDSingleMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleMaleReturning.Location = new System.Drawing.Point(66, 282);
            this.tbHHPvYrYTDSingleMaleReturning.Name = "tbHHPvYrYTDSingleMaleReturning";
            this.tbHHPvYrYTDSingleMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleMaleReturning.TabIndex = 195;
            this.tbHHPvYrYTDSingleMaleReturning.Tag = "HHSingleMaleReturning";
            this.tbHHPvYrYTDSingleMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDBabySvcsNew
            // 
            this.tbHHPvYrYTDBabySvcsNew.AccessibleName = "";
            this.tbHHPvYrYTDBabySvcsNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDBabySvcsNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDBabySvcsNew.Location = new System.Drawing.Point(3, 125);
            this.tbHHPvYrYTDBabySvcsNew.Name = "tbHHPvYrYTDBabySvcsNew";
            this.tbHHPvYrYTDBabySvcsNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDBabySvcsNew.TabIndex = 208;
            this.tbHHPvYrYTDBabySvcsNew.Tag = "HHRcvdBabyServicesNew";
            this.tbHHPvYrYTDBabySvcsNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label99
            // 
            this.label99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.ForeColor = System.Drawing.Color.Black;
            this.label99.Location = new System.Drawing.Point(133, 18);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(60, 18);
            this.label99.TabIndex = 210;
            this.label99.Text = "Total";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHHPvYrYTDParentMaleReturning
            // 
            this.tbHHPvYrYTDParentMaleReturning.AccessibleName = "";
            this.tbHHPvYrYTDParentMaleReturning.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDParentMaleReturning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDParentMaleReturning.Location = new System.Drawing.Point(66, 378);
            this.tbHHPvYrYTDParentMaleReturning.Name = "tbHHPvYrYTDParentMaleReturning";
            this.tbHHPvYrYTDParentMaleReturning.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDParentMaleReturning.TabIndex = 201;
            this.tbHHPvYrYTDParentMaleReturning.Tag = "HHOneParentMaleReturning";
            this.tbHHPvYrYTDParentMaleReturning.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDSingleMaleNew
            // 
            this.tbHHPvYrYTDSingleMaleNew.AccessibleName = "";
            this.tbHHPvYrYTDSingleMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDSingleMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDSingleMaleNew.Location = new System.Drawing.Point(3, 282);
            this.tbHHPvYrYTDSingleMaleNew.Name = "tbHHPvYrYTDSingleMaleNew";
            this.tbHHPvYrYTDSingleMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDSingleMaleNew.TabIndex = 194;
            this.tbHHPvYrYTDSingleMaleNew.Tag = "HHSingleMaleNew";
            this.tbHHPvYrYTDSingleMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHHPvYrYTDOneParentMaleNew
            // 
            this.tbHHPvYrYTDOneParentMaleNew.AccessibleName = "";
            this.tbHHPvYrYTDOneParentMaleNew.BackColor = System.Drawing.Color.Snow;
            this.tbHHPvYrYTDOneParentMaleNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHHPvYrYTDOneParentMaleNew.Location = new System.Drawing.Point(3, 377);
            this.tbHHPvYrYTDOneParentMaleNew.Name = "tbHHPvYrYTDOneParentMaleNew";
            this.tbHHPvYrYTDOneParentMaleNew.Size = new System.Drawing.Size(60, 20);
            this.tbHHPvYrYTDOneParentMaleNew.TabIndex = 200;
            this.tbHHPvYrYTDOneParentMaleNew.Tag = "HHOneParentMaleNew";
            this.tbHHPvYrYTDOneParentMaleNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblHHPrev1YTD
            // 
            this.lblHHPrev1YTD.BackColor = System.Drawing.Color.Beige;
            this.lblHHPrev1YTD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHHPrev1YTD.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHHPrev1YTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHHPrev1YTD.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblHHPrev1YTD.Location = new System.Drawing.Point(0, 0);
            this.lblHHPrev1YTD.Name = "lblHHPrev1YTD";
            this.lblHHPrev1YTD.Size = new System.Drawing.Size(200, 19);
            this.lblHHPrev1YTD.TabIndex = 191;
            this.lblHHPrev1YTD.Tag = "Previous Fiscal YTD - ";
            this.lblHHPrev1YTD.Text = "Previous Fiscal YTD - ";
            this.lblHHPrev1YTD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.Transparent;
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.ForeColor = System.Drawing.Color.Black;
            this.label101.Location = new System.Drawing.Point(66, 178);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(75, 15);
            this.label101.TabIndex = 271;
            this.label101.Text = "Commodities";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.Color.Transparent;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.ForeColor = System.Drawing.Color.Black;
            this.label102.Location = new System.Drawing.Point(66, 403);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(75, 15);
            this.label102.TabIndex = 267;
            this.label102.Text = "Other";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label103
            // 
            this.label103.BackColor = System.Drawing.Color.Transparent;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.ForeColor = System.Drawing.Color.Black;
            this.label103.Location = new System.Drawing.Point(66, 203);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(75, 15);
            this.label103.TabIndex = 272;
            this.label103.Text = "Supplemental";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.Color.Transparent;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.ForeColor = System.Drawing.Color.Black;
            this.label104.Location = new System.Drawing.Point(66, 449);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(75, 15);
            this.label104.TabIndex = 268;
            this.label104.Text = "Female";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.Transparent;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.ForeColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(66, 254);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(75, 15);
            this.label105.TabIndex = 274;
            this.label105.Text = "Homeless";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.Color.Transparent;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.ForeColor = System.Drawing.Color.Black;
            this.label106.Location = new System.Drawing.Point(66, 503);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(75, 15);
            this.label106.TabIndex = 270;
            this.label106.Text = "Other";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.Color.Transparent;
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.ForeColor = System.Drawing.Color.Black;
            this.label107.Location = new System.Drawing.Point(66, 380);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(75, 15);
            this.label107.TabIndex = 266;
            this.label107.Text = "Male";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.Transparent;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.ForeColor = System.Drawing.Color.Black;
            this.label108.Location = new System.Drawing.Point(66, 230);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(75, 15);
            this.label108.TabIndex = 273;
            this.label108.Text = "Baby Services";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label109
            // 
            this.label109.BackColor = System.Drawing.Color.Transparent;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.ForeColor = System.Drawing.Color.Black;
            this.label109.Location = new System.Drawing.Point(66, 353);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(75, 15);
            this.label109.TabIndex = 265;
            this.label109.Text = "Female";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label110
            // 
            this.label110.BackColor = System.Drawing.Color.Transparent;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.ForeColor = System.Drawing.Color.Black;
            this.label110.Location = new System.Drawing.Point(66, 476);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(75, 15);
            this.label110.TabIndex = 269;
            this.label110.Text = "Male";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 624);
            this.Controls.Add(this.pnlHHPvYr2YTD);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pnlHHYTDChange);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.pnlHHCurYTD);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.pnlHHPvYrYTD);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label106);
            this.Controls.Add(this.label107);
            this.Controls.Add(this.label108);
            this.Controls.Add(this.label109);
            this.Controls.Add(this.label110);
            this.Name = "Form4";
            this.Text = "Form4";
            this.pnlHHPvYr2YTD.ResumeLayout(false);
            this.pnlHHPvYr2YTD.PerformLayout();
            this.pnlHHYTDChange.ResumeLayout(false);
            this.pnlHHYTDChange.PerformLayout();
            this.pnlHHCurYTD.ResumeLayout(false);
            this.pnlHHCurYTD.PerformLayout();
            this.pnlHHPvYrYTD.ResumeLayout(false);
            this.pnlHHPvYrYTD.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHHPvYr2YTD;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomeless;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimitsReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomelessNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimitsNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDHomelessReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransientReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOther;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServedNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentMale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransientNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServed;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOther;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMale;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTotalServedReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemale;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplementalReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDInCityLimits;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplementalNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDTransient;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodityReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcs;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMaleNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOtherNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentOtherNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodityNew;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSupplemental;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcsReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDCommodity;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDSingleMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDBabySvcsNew;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox tbHHPvY2YTDParentMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvY2YTDOneParentMaleNew;
        private System.Windows.Forms.Label lblHHPrev2YTD;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel pnlHHYTDChange;
        private System.Windows.Forms.TextBox tbHHCurYTDInCityLimitsPercent;
        private System.Windows.Forms.TextBox tbHHDifYTDHomeless;
        private System.Windows.Forms.TextBox tbHHDifYTDInCityLimits;
        private System.Windows.Forms.TextBox tbHHCurYTDHomelessPercent;
        private System.Windows.Forms.TextBox tbHHCurYTDTransientPercent;
        private System.Windows.Forms.TextBox tbHHDifYTDTotalServed;
        private System.Windows.Forms.TextBox tbHHDifYTDTransient;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbHHCurYTDTotalServedPercent;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleFemalePercent;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentFemalePercent;
        private System.Windows.Forms.TextBox tbHHDifYTDSingleFemale;
        private System.Windows.Forms.TextBox tbHHCurYTDSupplementalPercent;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentOtherPercent;
        private System.Windows.Forms.TextBox tbHHDifYTDOneParentFemale;
        private System.Windows.Forms.TextBox tbHHDifYTDSupplemental;
        private System.Windows.Forms.TextBox tbHHCurYTDCommodityPercent;
        private System.Windows.Forms.TextBox tbHHDifYTDSingleOther;
        private System.Windows.Forms.TextBox tbHHDifYTDOneParentOther;
        private System.Windows.Forms.TextBox tbHHDifYTDCommodity;
        private System.Windows.Forms.TextBox tbHHCurYTDBabySvcsPercent;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleOtherPercent;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleMalePercent;
        private System.Windows.Forms.TextBox tbHHDifYTDBabySvcs;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentMalePercent;
        private System.Windows.Forms.TextBox tbHHDifYTDSingleMale;
        private System.Windows.Forms.TextBox tbHHDifYTDOneParentMale;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Panel pnlHHCurYTD;
        private System.Windows.Forms.TextBox tbHHCurYTDInCityLimitsReturning;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox tbHHCurYTDInCityLimitsNew;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox tbHHCurYTDTransientReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDTotalServedNew;
        private System.Windows.Forms.TextBox tbHHCurYTDHomeless;
        private System.Windows.Forms.TextBox tbHHCurYTDTransientNew;
        private System.Windows.Forms.TextBox tbHHCurYTDHomelessNew;
        private System.Windows.Forms.TextBox tbHHCurYTDTotalServed;
        private System.Windows.Forms.TextBox tbHHCurYTDHomelessReturning;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox tbHHCurYTDTotalServedReturning;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentFemaleReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDSupplementalReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentFemaleNew;
        private System.Windows.Forms.TextBox tbHHCurYTDSupplementalNew;
        private System.Windows.Forms.TextBox tbHHCurYTDCommodityReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleOtherNew;
        private System.Windows.Forms.TextBox tbHHCurYTDCommodityNew;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentOther;
        private System.Windows.Forms.TextBox tbHHCurYTDBabySvcsReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentMale;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleOtherReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentFemale;
        private System.Windows.Forms.TextBox tbHHCurYTDBabySvcsNew;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleOther;
        private System.Windows.Forms.TextBox tbHHCurYTDParentMaleReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleMale;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentMaleNew;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleFemale;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleMaleNew;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleMaleReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDCommodity;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleFemaleReturning;
        private System.Windows.Forms.TextBox tbHHCurYTDSupplemental;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentOtherNew;
        private System.Windows.Forms.TextBox tbHHCurYTDSingleFemaleNew;
        private System.Windows.Forms.TextBox tbHHCurYTDBabySvcs;
        private System.Windows.Forms.TextBox tbHHCurYTDTransient;
        private System.Windows.Forms.TextBox tbHHCurYTDInCityLimits;
        private System.Windows.Forms.TextBox tbHHCurYTDOneParentOtherReturning;
        private System.Windows.Forms.Label lblHHCurYTD;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Panel pnlHHPvYrYTD;
        private System.Windows.Forms.TextBox tbHHPvYrYTDHomeless;
        private System.Windows.Forms.TextBox tbHHPvYrYTDInCityLimitsReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDHomelessNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDInCityLimitsNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDHomelessReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTransientReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentOther;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTotalServedNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentMale;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTransientNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentFemale;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTotalServed;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleOther;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleMale;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTotalServedReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleFemale;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentFemaleReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSupplementalReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentFemaleNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDInCityLimits;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSupplementalNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDTransient;
        private System.Windows.Forms.TextBox tbHHPvYrYTDCommodityReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDBabySvcs;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleOtherNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentOtherNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDCommodityNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSupplemental;
        private System.Windows.Forms.TextBox tbHHPvYrYTDBabySvcsReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDCommodity;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleOtherReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDBabySvcsNew;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox tbHHPvYrYTDParentMaleReturning;
        private System.Windows.Forms.TextBox tbHHPvYrYTDSingleMaleNew;
        private System.Windows.Forms.TextBox tbHHPvYrYTDOneParentMaleNew;
        private System.Windows.Forms.Label lblHHPrev1YTD;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
    }
}